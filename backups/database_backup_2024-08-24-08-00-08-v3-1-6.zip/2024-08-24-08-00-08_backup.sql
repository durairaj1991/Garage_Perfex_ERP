#
# TABLE STRUCTURE FOR: tblacc_account_history
#

DROP TABLE IF EXISTS `tblacc_account_history`;

CREATE TABLE `tblacc_account_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `account` int NOT NULL,
  `debit` decimal(15,2) NOT NULL DEFAULT '0.00',
  `credit` decimal(15,2) NOT NULL DEFAULT '0.00',
  `description` text,
  `rel_id` int DEFAULT NULL,
  `rel_type` varchar(45) DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int DEFAULT NULL,
  `customer` int DEFAULT NULL,
  `reconcile` int NOT NULL DEFAULT '0',
  `split` int NOT NULL DEFAULT '0',
  `item` int DEFAULT NULL,
  `paid` int NOT NULL DEFAULT '0',
  `date` date DEFAULT NULL,
  `tax` int DEFAULT NULL,
  `payslip_type` varchar(45) DEFAULT NULL,
  `vendor` int DEFAULT NULL,
  `itemable_id` int DEFAULT NULL,
  `cleared` int NOT NULL DEFAULT '0',
  `sub_type` varchar(45) DEFAULT NULL,
  `bill_item` int NOT NULL DEFAULT '0',
  `number` varchar(100) DEFAULT NULL,
  `issue` int NOT NULL DEFAULT '0',
  `added_from_reconcile` int NOT NULL DEFAULT '0',
  `bank_reconcile` int NOT NULL DEFAULT '0',
  `currency_rate` decimal(15,6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `tblacc_account_history` (`id`, `account`, `debit`, `credit`, `description`, `rel_id`, `rel_type`, `datecreated`, `addedfrom`, `customer`, `reconcile`, `split`, `item`, `paid`, `date`, `tax`, `payslip_type`, `vendor`, `itemable_id`, `cleared`, `sub_type`, `bill_item`, `number`, `issue`, `added_from_reconcile`, `bank_reconcile`, `currency_rate`) VALUES (53, 13, '1000.00', '0.00', '', 2, 'payment', '2024-08-21 10:52:41', 1, 3, 0, 1, NULL, 0, '2024-08-21', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, 0, 0, 0, '0.000000');
INSERT INTO `tblacc_account_history` (`id`, `account`, `debit`, `credit`, `description`, `rel_id`, `rel_type`, `datecreated`, `addedfrom`, `customer`, `reconcile`, `split`, `item`, `paid`, `date`, `tax`, `payslip_type`, `vendor`, `itemable_id`, `cleared`, `sub_type`, `bill_item`, `number`, `issue`, `added_from_reconcile`, `bank_reconcile`, `currency_rate`) VALUES (54, 1, '0.00', '1000.00', '', 2, 'payment', '2024-08-21 10:52:41', 1, 3, 0, 13, NULL, 0, '2024-08-21', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, 0, 0, 0, '0.000000');
INSERT INTO `tblacc_account_history` (`id`, `account`, `debit`, `credit`, `description`, `rel_id`, `rel_type`, `datecreated`, `addedfrom`, `customer`, `reconcile`, `split`, `item`, `paid`, `date`, `tax`, `payslip_type`, `vendor`, `itemable_id`, `cleared`, `sub_type`, `bill_item`, `number`, `issue`, `added_from_reconcile`, `bank_reconcile`, `currency_rate`) VALUES (55, 1, '1000.00', '0.00', '', 2, 'invoice', '2024-08-21 12:22:40', 1, 3, 0, 66, 0, 0, '2024-08-21', 0, NULL, NULL, 17, 0, NULL, 0, NULL, 0, 0, 0, '0.000000');
INSERT INTO `tblacc_account_history` (`id`, `account`, `debit`, `credit`, `description`, `rel_id`, `rel_type`, `datecreated`, `addedfrom`, `customer`, `reconcile`, `split`, `item`, `paid`, `date`, `tax`, `payslip_type`, `vendor`, `itemable_id`, `cleared`, `sub_type`, `bill_item`, `number`, `issue`, `added_from_reconcile`, `bank_reconcile`, `currency_rate`) VALUES (56, 66, '0.00', '1000.00', '', 2, 'invoice', '2024-08-21 12:22:40', 1, 3, 0, 1, 0, 0, '2024-08-21', 0, NULL, NULL, 17, 0, NULL, 0, NULL, 0, 0, 0, '0.000000');
INSERT INTO `tblacc_account_history` (`id`, `account`, `debit`, `credit`, `description`, `rel_id`, `rel_type`, `datecreated`, `addedfrom`, `customer`, `reconcile`, `split`, `item`, `paid`, `date`, `tax`, `payslip_type`, `vendor`, `itemable_id`, `cleared`, `sub_type`, `bill_item`, `number`, `issue`, `added_from_reconcile`, `bank_reconcile`, `currency_rate`) VALUES (57, 1, '500.00', '0.00', '', 2, 'invoice', '2024-08-21 12:22:40', 1, 3, 0, 66, 0, 0, '2024-08-21', 0, NULL, NULL, 18, 0, NULL, 0, NULL, 0, 0, 0, '0.000000');
INSERT INTO `tblacc_account_history` (`id`, `account`, `debit`, `credit`, `description`, `rel_id`, `rel_type`, `datecreated`, `addedfrom`, `customer`, `reconcile`, `split`, `item`, `paid`, `date`, `tax`, `payslip_type`, `vendor`, `itemable_id`, `cleared`, `sub_type`, `bill_item`, `number`, `issue`, `added_from_reconcile`, `bank_reconcile`, `currency_rate`) VALUES (58, 66, '0.00', '500.00', '', 2, 'invoice', '2024-08-21 12:22:40', 1, 3, 0, 1, 0, 0, '2024-08-21', 0, NULL, NULL, 18, 0, NULL, 0, NULL, 0, 0, 0, '0.000000');
INSERT INTO `tblacc_account_history` (`id`, `account`, `debit`, `credit`, `description`, `rel_id`, `rel_type`, `datecreated`, `addedfrom`, `customer`, `reconcile`, `split`, `item`, `paid`, `date`, `tax`, `payslip_type`, `vendor`, `itemable_id`, `cleared`, `sub_type`, `bill_item`, `number`, `issue`, `added_from_reconcile`, `bank_reconcile`, `currency_rate`) VALUES (59, 1, '800.00', '0.00', '', 2, 'invoice', '2024-08-21 12:22:40', 1, 3, 0, 66, 0, 0, '2024-08-21', 0, NULL, NULL, 19, 0, NULL, 0, NULL, 0, 0, 0, '0.000000');
INSERT INTO `tblacc_account_history` (`id`, `account`, `debit`, `credit`, `description`, `rel_id`, `rel_type`, `datecreated`, `addedfrom`, `customer`, `reconcile`, `split`, `item`, `paid`, `date`, `tax`, `payslip_type`, `vendor`, `itemable_id`, `cleared`, `sub_type`, `bill_item`, `number`, `issue`, `added_from_reconcile`, `bank_reconcile`, `currency_rate`) VALUES (60, 66, '0.00', '800.00', '', 2, 'invoice', '2024-08-21 12:22:40', 1, 3, 0, 1, 0, 0, '2024-08-21', 0, NULL, NULL, 19, 0, NULL, 0, NULL, 0, 0, 0, '0.000000');
INSERT INTO `tblacc_account_history` (`id`, `account`, `debit`, `credit`, `description`, `rel_id`, `rel_type`, `datecreated`, `addedfrom`, `customer`, `reconcile`, `split`, `item`, `paid`, `date`, `tax`, `payslip_type`, `vendor`, `itemable_id`, `cleared`, `sub_type`, `bill_item`, `number`, `issue`, `added_from_reconcile`, `bank_reconcile`, `currency_rate`) VALUES (61, 1, '500.00', '0.00', '', 2, 'invoice', '2024-08-21 12:22:40', 1, 3, 0, 66, 0, 0, '2024-08-21', 0, NULL, NULL, 20, 0, NULL, 0, NULL, 0, 0, 0, '0.000000');
INSERT INTO `tblacc_account_history` (`id`, `account`, `debit`, `credit`, `description`, `rel_id`, `rel_type`, `datecreated`, `addedfrom`, `customer`, `reconcile`, `split`, `item`, `paid`, `date`, `tax`, `payslip_type`, `vendor`, `itemable_id`, `cleared`, `sub_type`, `bill_item`, `number`, `issue`, `added_from_reconcile`, `bank_reconcile`, `currency_rate`) VALUES (62, 66, '0.00', '500.00', '', 2, 'invoice', '2024-08-21 12:22:40', 1, 3, 0, 1, 0, 0, '2024-08-21', 0, NULL, NULL, 20, 0, NULL, 0, NULL, 0, 0, 0, '0.000000');
INSERT INTO `tblacc_account_history` (`id`, `account`, `debit`, `credit`, `description`, `rel_id`, `rel_type`, `datecreated`, `addedfrom`, `customer`, `reconcile`, `split`, `item`, `paid`, `date`, `tax`, `payslip_type`, `vendor`, `itemable_id`, `cleared`, `sub_type`, `bill_item`, `number`, `issue`, `added_from_reconcile`, `bank_reconcile`, `currency_rate`) VALUES (63, 19, '50.00', '0.00', '', 2, 'invoice', '2024-08-21 12:22:40', 1, 3, 0, 1, 0, 0, '2024-08-21', 0, NULL, NULL, 0, 0, NULL, 0, NULL, 0, 0, 0, '0.000000');
INSERT INTO `tblacc_account_history` (`id`, `account`, `debit`, `credit`, `description`, `rel_id`, `rel_type`, `datecreated`, `addedfrom`, `customer`, `reconcile`, `split`, `item`, `paid`, `date`, `tax`, `payslip_type`, `vendor`, `itemable_id`, `cleared`, `sub_type`, `bill_item`, `number`, `issue`, `added_from_reconcile`, `bank_reconcile`, `currency_rate`) VALUES (64, 1, '0.00', '50.00', '', 2, 'invoice', '2024-08-21 12:22:40', 1, 3, 0, 19, 0, 0, '2024-08-21', 0, NULL, NULL, 0, 0, NULL, 0, NULL, 0, 0, 0, '0.000000');
INSERT INTO `tblacc_account_history` (`id`, `account`, `debit`, `credit`, `description`, `rel_id`, `rel_type`, `datecreated`, `addedfrom`, `customer`, `reconcile`, `split`, `item`, `paid`, `date`, `tax`, `payslip_type`, `vendor`, `itemable_id`, `cleared`, `sub_type`, `bill_item`, `number`, `issue`, `added_from_reconcile`, `bank_reconcile`, `currency_rate`) VALUES (65, 13, '500.00', '0.00', '', 3, 'payment', '2024-08-21 12:22:40', 1, 3, 0, 1, NULL, 0, '2024-08-21', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, 0, 0, 0, '0.000000');
INSERT INTO `tblacc_account_history` (`id`, `account`, `debit`, `credit`, `description`, `rel_id`, `rel_type`, `datecreated`, `addedfrom`, `customer`, `reconcile`, `split`, `item`, `paid`, `date`, `tax`, `payslip_type`, `vendor`, `itemable_id`, `cleared`, `sub_type`, `bill_item`, `number`, `issue`, `added_from_reconcile`, `bank_reconcile`, `currency_rate`) VALUES (66, 1, '0.00', '500.00', '', 3, 'payment', '2024-08-21 12:22:40', 1, 3, 0, 13, NULL, 0, '2024-08-21', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, 0, 0, 0, '0.000000');


#
# TABLE STRUCTURE FOR: tblacc_account_type_details
#

DROP TABLE IF EXISTS `tblacc_account_type_details`;

CREATE TABLE `tblacc_account_type_details` (
  `id` int NOT NULL AUTO_INCREMENT,
  `account_type_id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `note` text,
  `statement_of_cash_flows` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=200 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

#
# TABLE STRUCTURE FOR: tblacc_accounts
#

DROP TABLE IF EXISTS `tblacc_accounts`;

CREATE TABLE `tblacc_accounts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `key_name` varchar(255) DEFAULT NULL,
  `number` varchar(45) DEFAULT NULL,
  `parent_account` int DEFAULT NULL,
  `account_type_id` int NOT NULL,
  `account_detail_type_id` int NOT NULL,
  `balance` decimal(15,2) DEFAULT NULL,
  `balance_as_of` date DEFAULT NULL,
  `description` text,
  `default_account` int NOT NULL DEFAULT '0',
  `active` int NOT NULL DEFAULT '1',
  `access_token` text,
  `account_id` varchar(255) DEFAULT NULL,
  `plaid_status` tinyint NOT NULL DEFAULT '0' COMMENT '1=>verified, 0=>not verified',
  `plaid_account_name` varchar(255) DEFAULT NULL,
  `bank_account` text,
  `bank_routing` text,
  `address_line_1` text,
  `address_line_2` text,
  `bank_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (1, '', 'acc_accounts_receivable', NULL, NULL, 1, 1, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (2, '', 'acc_accrued_holiday_payable', NULL, NULL, 9, 61, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (3, '', 'acc_accrued_liabilities', NULL, NULL, 8, 44, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (4, '', 'acc_accrued_non_current_liabilities', NULL, NULL, 9, 62, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (5, '', 'acc_accumulated_depreciation_on_property_plant_and_equipment', NULL, NULL, 4, 22, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (6, '', 'acc_allowance_for_bad_debts', NULL, NULL, 2, 2, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (7, '', 'acc_amortisation_expense', NULL, NULL, 14, 106, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (8, '', 'acc_assets_held_for_sale', NULL, NULL, 5, 32, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (9, '', 'acc_available_for_sale_assets_short_term', NULL, NULL, 2, 3, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (10, '', 'acc_bad_debts', NULL, NULL, 14, 108, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (11, '', 'acc_bank_charges', NULL, NULL, 14, 109, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (12, '', 'acc_billable_expense_income', NULL, NULL, 11, 89, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (13, '', 'acc_cash_and_cash_equivalents', NULL, NULL, 3, 15, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (14, '', 'acc_change_in_inventory_cos', NULL, NULL, 13, 100, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (15, '', 'acc_commissions_and_fees', NULL, NULL, 14, 111, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (16, '', 'acc_cost_of_sales', NULL, NULL, 13, 104, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (17, '', 'acc_deferred_tax_assets', NULL, NULL, 5, 33, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (18, '', 'acc_direct_labour_cos', NULL, NULL, 13, 100, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (19, '', 'acc_discounts_given_cos', NULL, NULL, 13, 100, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (20, '', 'acc_dividend_disbursed', NULL, NULL, 10, 69, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (21, '', 'acc_dividend_income', NULL, NULL, 12, 92, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (22, '', 'acc_dividends_payable', NULL, NULL, 8, 48, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (23, '', 'acc_dues_and_subscriptions', NULL, NULL, 14, 113, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (24, '', 'acc_equipment_rental', NULL, NULL, 14, 114, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (25, '', 'acc_equity_in_earnings_of_subsidiaries', NULL, NULL, 10, 70, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (26, '', 'acc_freight_and_delivery_cos', NULL, NULL, 13, 100, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (27, '', 'acc_goodwill', NULL, NULL, 5, 34, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (28, '', 'acc_income_tax_expense', NULL, NULL, 14, 116, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (29, '', 'acc_income_tax_payable', NULL, NULL, 8, 50, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (30, '', 'acc_insurance_disability', NULL, NULL, 14, 117, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (31, '', 'acc_insurance_general', NULL, NULL, 14, 117, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (32, '', 'acc_insurance_liability', NULL, NULL, 14, 117, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (33, '', 'acc_intangibles', NULL, NULL, 5, 35, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (34, '', 'acc_interest_expense', NULL, NULL, 14, 118, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (35, '', 'acc_interest_income', NULL, NULL, 12, 93, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (36, '', 'acc_inventory', NULL, NULL, 2, 5, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (37, '', 'acc_inventory_asset', NULL, NULL, 2, 5, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (38, '', 'acc_legal_and_professional_fees', NULL, NULL, 14, 119, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (39, '', 'acc_liabilities_related_to_assets_held_for_sale', NULL, NULL, 9, 63, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (40, '', 'acc_long_term_debt', NULL, NULL, 9, 64, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (41, '', 'acc_long_term_investments', NULL, NULL, 5, 38, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (42, '', 'acc_loss_on_discontinued_operations_net_of_tax', NULL, NULL, 14, 120, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (43, '', 'acc_loss_on_disposal_of_assets', NULL, NULL, 12, 94, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (44, '', 'acc_management_compensation', NULL, NULL, 14, 121, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (45, '', 'acc_materials_cos', NULL, NULL, 13, 100, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (46, '', 'acc_meals_and_entertainment', NULL, NULL, 14, 122, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (47, '', 'acc_office_expenses', NULL, NULL, 14, 123, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (48, '', 'acc_other_cos', NULL, NULL, 13, 100, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (49, '', 'acc_other_comprehensive_income', NULL, NULL, 10, 73, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (50, '', 'acc_other_general_and_administrative_expenses', NULL, NULL, 14, 123, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (51, '', 'acc_other_operating_income_expenses', NULL, NULL, 12, 97, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (52, '', 'acc_other_selling_expenses', NULL, NULL, 14, 125, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (53, '', 'acc_other_type_of_expenses_advertising_expenses', NULL, NULL, 14, 105, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (54, '', 'acc_overhead_cos', NULL, NULL, 13, 100, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (55, '', 'acc_payroll_clearing', NULL, NULL, 8, 55, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (56, '', 'acc_payroll_expenses', NULL, NULL, 14, 126, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (57, '', 'acc_payroll_liabilities', NULL, NULL, 8, 56, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (58, '', 'acc_prepaid_expenses', NULL, NULL, 2, 11, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (59, '', 'acc_property_plant_and_equipment', NULL, NULL, 4, 26, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (60, '', 'acc_purchases', NULL, NULL, 14, 130, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (61, '', 'acc_reconciliation_discrepancies', NULL, NULL, 15, 139, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (62, '', 'acc_rent_or_lease_payments', NULL, NULL, 14, 127, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (63, '', 'acc_repair_and_maintenance', NULL, NULL, 14, 128, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (64, '', 'acc_retained_earnings', NULL, NULL, 10, 80, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (65, '', 'acc_revenue_general', NULL, NULL, 11, 86, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (66, '', 'acc_sales', NULL, NULL, 11, 89, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (67, '', 'acc_sales_retail', NULL, NULL, 11, 87, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (68, '', 'acc_sales_wholesale', NULL, NULL, 11, 88, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (69, '', 'acc_sales_of_product_income', NULL, NULL, 11, 89, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (70, '', 'acc_share_capital', NULL, NULL, 10, 81, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (71, '', 'acc_shipping_and_delivery_expense', NULL, NULL, 14, 129, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (72, '', 'acc_short_term_debit', NULL, NULL, 8, 54, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (73, '', 'acc_stationery_and_printing', NULL, NULL, 14, 123, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (74, '', 'acc_subcontractors_cos', NULL, NULL, 13, 100, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (75, '', 'acc_supplies', NULL, NULL, 14, 130, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (76, '', 'acc_travel_expenses_general_and_admin_expenses', NULL, NULL, 14, 132, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (77, '', 'acc_travel_expenses_selling_expense', NULL, NULL, 14, 133, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (78, '', 'acc_unapplied_cash_payment_income', NULL, NULL, 11, 91, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (79, '', 'acc_uncategorised_asset', NULL, NULL, 2, 10, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (80, '', 'acc_uncategorised_expense', NULL, NULL, 14, 124, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (81, '', 'acc_uncategorised_income', NULL, NULL, 11, 89, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (82, '', 'acc_undeposited_funds', NULL, NULL, 2, 13, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (83, '', 'acc_unrealised_loss_on_securities_net_of_tax', NULL, NULL, 12, 99, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (84, '', 'acc_utilities', NULL, NULL, 14, 135, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (85, '', 'acc_wage_expenses', NULL, NULL, 14, 126, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (86, '', 'acc_credit_card', NULL, NULL, 7, 43, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (87, '', 'acc_accounts_payable', NULL, NULL, 6, 42, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblacc_accounts` (`id`, `name`, `key_name`, `number`, `parent_account`, `account_type_id`, `account_detail_type_id`, `balance`, `balance_as_of`, `description`, `default_account`, `active`, `access_token`, `account_id`, `plaid_status`, `plaid_account_name`, `bank_account`, `bank_routing`, `address_line_1`, `address_line_2`, `bank_name`) VALUES (88, '', 'acc_opening_balance_equity', NULL, NULL, 10, 71, NULL, NULL, NULL, 1, 1, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: tblacc_bank_reconciles
#

DROP TABLE IF EXISTS `tblacc_bank_reconciles`;

CREATE TABLE `tblacc_bank_reconciles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `account` int NOT NULL,
  `opening_balance` decimal(15,2) NOT NULL DEFAULT '0.00',
  `beginning_balance` decimal(15,2) NOT NULL,
  `ending_balance` decimal(15,2) NOT NULL,
  `ending_date` date NOT NULL,
  `finish` int NOT NULL DEFAULT '0',
  `debits_for_period` decimal(15,2) NOT NULL,
  `credits_for_period` decimal(15,2) NOT NULL,
  `dateadded` datetime DEFAULT NULL,
  `addedfrom` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

#
# TABLE STRUCTURE FOR: tblacc_banking_rule_details
#

DROP TABLE IF EXISTS `tblacc_banking_rule_details`;

CREATE TABLE `tblacc_banking_rule_details` (
  `id` int NOT NULL AUTO_INCREMENT,
  `rule_id` int NOT NULL,
  `type` varchar(45) DEFAULT NULL,
  `subtype` varchar(45) DEFAULT NULL,
  `text` varchar(255) DEFAULT NULL,
  `subtype_amount` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

#
# TABLE STRUCTURE FOR: tblacc_banking_rules
#

DROP TABLE IF EXISTS `tblacc_banking_rules`;

CREATE TABLE `tblacc_banking_rules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `transaction` varchar(45) DEFAULT NULL,
  `following` varchar(45) DEFAULT NULL,
  `then` varchar(45) DEFAULT NULL,
  `payment_account` int DEFAULT NULL,
  `deposit_to` int DEFAULT NULL,
  `auto_add` int NOT NULL DEFAULT '0',
  `mapping_type` varchar(25) DEFAULT NULL,
  `account` int DEFAULT NULL,
  `split_percentage` text,
  `split_amount` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

#
# TABLE STRUCTURE FOR: tblacc_bill_mappings
#

DROP TABLE IF EXISTS `tblacc_bill_mappings`;

CREATE TABLE `tblacc_bill_mappings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `bill_id` int DEFAULT NULL,
  `type` varchar(25) DEFAULT NULL,
  `account` int DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  `item_id` int NOT NULL DEFAULT '0',
  `qty` decimal(15,2) NOT NULL DEFAULT '0.00',
  `cost` decimal(15,2) NOT NULL DEFAULT '0.00',
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

#
# TABLE STRUCTURE FOR: tblacc_budget_details
#

DROP TABLE IF EXISTS `tblacc_budget_details`;

CREATE TABLE `tblacc_budget_details` (
  `id` int NOT NULL AUTO_INCREMENT,
  `budget_id` int NOT NULL,
  `month` int NOT NULL,
  `year` int NOT NULL,
  `account` int DEFAULT NULL,
  `amount` decimal(15,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

#
# TABLE STRUCTURE FOR: tblacc_budgets
#

DROP TABLE IF EXISTS `tblacc_budgets`;

CREATE TABLE `tblacc_budgets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `year` int NOT NULL,
  `name` varchar(200) DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `data_source` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

#
# TABLE STRUCTURE FOR: tblacc_check_details
#

DROP TABLE IF EXISTS `tblacc_check_details`;

CREATE TABLE `tblacc_check_details` (
  `id` int NOT NULL AUTO_INCREMENT,
  `check_id` int DEFAULT NULL,
  `bill` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

#
# TABLE STRUCTURE FOR: tblacc_checks
#

DROP TABLE IF EXISTS `tblacc_checks`;

CREATE TABLE `tblacc_checks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `rel_id` int DEFAULT NULL,
  `rel_type` varchar(25) DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `memo` varchar(255) DEFAULT NULL,
  `dateadded` datetime DEFAULT NULL,
  `addedfrom` int DEFAULT NULL,
  `address` text,
  `bank_account` int NOT NULL,
  `number` int NOT NULL,
  `signed` int NOT NULL DEFAULT '0',
  `include_company_name_address` int NOT NULL DEFAULT '1',
  `include_routing_account_numbers` int NOT NULL DEFAULT '1',
  `bill` int DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `zip` varchar(15) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `issue` int DEFAULT NULL,
  `include_check_number` int NOT NULL DEFAULT '1',
  `include_bank_name` int NOT NULL DEFAULT '1',
  `bank_name` varchar(255) DEFAULT NULL,
  `address_line_1` text,
  `address_line_2` text,
  `vendor_city` varchar(100) DEFAULT NULL,
  `vendor_zip` varchar(15) DEFAULT NULL,
  `vendor_state` varchar(50) DEFAULT NULL,
  `vendor_address` text,
  `reason_for_void` text,
  `bill_items` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

#
# TABLE STRUCTURE FOR: tblacc_checks_printed
#

DROP TABLE IF EXISTS `tblacc_checks_printed`;

CREATE TABLE `tblacc_checks_printed` (
  `id` int NOT NULL AUTO_INCREMENT,
  `check_id` int DEFAULT NULL,
  `bank_account` int DEFAULT NULL,
  `first_check_number` int DEFAULT NULL,
  `printed_at` datetime DEFAULT NULL,
  `printed_by` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

#
# TABLE STRUCTURE FOR: tblacc_expense_category_mapping_details
#

DROP TABLE IF EXISTS `tblacc_expense_category_mapping_details`;

CREATE TABLE `tblacc_expense_category_mapping_details` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category_mapping_id` int NOT NULL,
  `payment_mode_id` int NOT NULL,
  `payment_account` int NOT NULL DEFAULT '0',
  `deposit_to` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

#
# TABLE STRUCTURE FOR: tblacc_expense_category_mappings
#

DROP TABLE IF EXISTS `tblacc_expense_category_mappings`;

CREATE TABLE `tblacc_expense_category_mappings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category_id` int NOT NULL,
  `payment_account` int NOT NULL DEFAULT '0',
  `deposit_to` int NOT NULL DEFAULT '0',
  `preferred_payment_method` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

#
# TABLE STRUCTURE FOR: tblacc_income_statement_modifications
#

DROP TABLE IF EXISTS `tblacc_income_statement_modifications`;

CREATE TABLE `tblacc_income_statement_modifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `account` int DEFAULT NULL,
  `active` int NOT NULL DEFAULT '1',
  `account_type` int DEFAULT NULL,
  `options` text,
  `dateadded` datetime DEFAULT NULL,
  `addedfrom` int DEFAULT NULL,
  `type` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

#
# TABLE STRUCTURE FOR: tblacc_item_automatics
#

DROP TABLE IF EXISTS `tblacc_item_automatics`;

CREATE TABLE `tblacc_item_automatics` (
  `id` int NOT NULL AUTO_INCREMENT,
  `item_id` int NOT NULL,
  `inventory_asset_account` int NOT NULL DEFAULT '0',
  `income_account` int NOT NULL DEFAULT '0',
  `expense_account` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

#
# TABLE STRUCTURE FOR: tblacc_journal_entries
#

DROP TABLE IF EXISTS `tblacc_journal_entries`;

CREATE TABLE `tblacc_journal_entries` (
  `id` int NOT NULL AUTO_INCREMENT,
  `number` varchar(45) DEFAULT NULL,
  `description` text,
  `journal_date` date DEFAULT NULL,
  `amount` decimal(15,2) NOT NULL DEFAULT '0.00',
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int DEFAULT NULL,
  `reference` varchar(100) DEFAULT NULL,
  `recurring` int NOT NULL DEFAULT '0',
  `recurring_type` varchar(10) DEFAULT NULL,
  `custom_recurring` tinyint(1) NOT NULL DEFAULT '0',
  `cycles` int NOT NULL DEFAULT '0',
  `total_cycles` int NOT NULL DEFAULT '0',
  `is_recurring_from` int DEFAULT NULL,
  `last_recurring_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

#
# TABLE STRUCTURE FOR: tblacc_matched_transactions
#

DROP TABLE IF EXISTS `tblacc_matched_transactions`;

CREATE TABLE `tblacc_matched_transactions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `account_history_id` int DEFAULT NULL,
  `history_amount` decimal(15,2) NOT NULL DEFAULT '0.00',
  `rel_id` int DEFAULT NULL,
  `rel_type` varchar(255) DEFAULT NULL,
  `amount` decimal(15,2) NOT NULL DEFAULT '0.00',
  `company` int DEFAULT NULL,
  `reconcile` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

#
# TABLE STRUCTURE FOR: tblacc_pay_bill_details
#

DROP TABLE IF EXISTS `tblacc_pay_bill_details`;

CREATE TABLE `tblacc_pay_bill_details` (
  `id` int NOT NULL AUTO_INCREMENT,
  `pay_bill` int DEFAULT NULL,
  `bill_id` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

#
# TABLE STRUCTURE FOR: tblacc_pay_bill_item_paid
#

DROP TABLE IF EXISTS `tblacc_pay_bill_item_paid`;

CREATE TABLE `tblacc_pay_bill_item_paid` (
  `id` int NOT NULL AUTO_INCREMENT,
  `pay_bill_id` int NOT NULL DEFAULT '0',
  `item_id` int DEFAULT NULL,
  `item_name` varchar(255) DEFAULT NULL,
  `item_amount` decimal(15,2) NOT NULL DEFAULT '0.00',
  `amount_paid` decimal(15,2) NOT NULL DEFAULT '0.00',
  `check_id` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

#
# TABLE STRUCTURE FOR: tblacc_pay_bills
#

DROP TABLE IF EXISTS `tblacc_pay_bills`;

CREATE TABLE `tblacc_pay_bills` (
  `id` int NOT NULL AUTO_INCREMENT,
  `expense` int DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  `reference_no` varchar(100) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `dateadded` datetime DEFAULT NULL,
  `addedfrom` int DEFAULT NULL,
  `company` int DEFAULT NULL,
  `account_debit` int DEFAULT NULL,
  `account_credit` int DEFAULT NULL,
  `bill` int NOT NULL DEFAULT '0',
  `vendor` int NOT NULL DEFAULT '0',
  `pay_number` int DEFAULT NULL,
  `payment_method` varchar(255) DEFAULT NULL,
  `bill_items` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

#
# TABLE STRUCTURE FOR: tblacc_payment_mode_mappings
#

DROP TABLE IF EXISTS `tblacc_payment_mode_mappings`;

CREATE TABLE `tblacc_payment_mode_mappings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `payment_mode_id` int NOT NULL,
  `payment_account` int NOT NULL DEFAULT '0',
  `deposit_to` int NOT NULL DEFAULT '0',
  `expense_payment_account` int NOT NULL DEFAULT '0',
  `expense_deposit_to` int NOT NULL DEFAULT '0',
  `credit_note_refund_payment_account` int NOT NULL DEFAULT '0',
  `credit_note_refund_deposit_to` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

#
# TABLE STRUCTURE FOR: tblacc_plaid_transaction_logs
#

DROP TABLE IF EXISTS `tblacc_plaid_transaction_logs`;

CREATE TABLE `tblacc_plaid_transaction_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `bank_id` int DEFAULT NULL,
  `last_updated` date DEFAULT NULL,
  `transaction_count` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `addedFrom` int DEFAULT NULL,
  `company` int DEFAULT NULL,
  `status` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

#
# TABLE STRUCTURE FOR: tblacc_print_later
#

DROP TABLE IF EXISTS `tblacc_print_later`;

CREATE TABLE `tblacc_print_later` (
  `id` int NOT NULL AUTO_INCREMENT,
  `rel_id` int DEFAULT NULL,
  `rel_type` varchar(45) DEFAULT NULL,
  `account` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

#
# TABLE STRUCTURE FOR: tblacc_reconciles
#

DROP TABLE IF EXISTS `tblacc_reconciles`;

CREATE TABLE `tblacc_reconciles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `account` int NOT NULL,
  `beginning_balance` decimal(15,2) NOT NULL,
  `ending_balance` decimal(15,2) NOT NULL,
  `ending_date` date NOT NULL,
  `expense_date` date DEFAULT NULL,
  `service_charge` decimal(15,2) DEFAULT NULL,
  `expense_account` int DEFAULT NULL,
  `income_date` date DEFAULT NULL,
  `interest_earned` decimal(15,2) DEFAULT NULL,
  `income_account` int DEFAULT NULL,
  `finish` int NOT NULL DEFAULT '0',
  `opening_balance` int NOT NULL DEFAULT '0',
  `debits_for_period` decimal(15,2) DEFAULT NULL,
  `credits_for_period` decimal(15,2) DEFAULT NULL,
  `dateadded` datetime DEFAULT NULL,
  `addedfrom` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

#
# TABLE STRUCTURE FOR: tblacc_tax_mappings
#

DROP TABLE IF EXISTS `tblacc_tax_mappings`;

CREATE TABLE `tblacc_tax_mappings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tax_id` int NOT NULL,
  `payment_account` int NOT NULL DEFAULT '0',
  `deposit_to` int NOT NULL DEFAULT '0',
  `expense_payment_account` int NOT NULL DEFAULT '0',
  `expense_deposit_to` int NOT NULL DEFAULT '0',
  `purchase_payment_account` int NOT NULL DEFAULT '0',
  `purchase_deposit_to` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

#
# TABLE STRUCTURE FOR: tblacc_transaction_bankings
#

DROP TABLE IF EXISTS `tblacc_transaction_bankings`;

CREATE TABLE `tblacc_transaction_bankings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `withdrawals` decimal(15,2) NOT NULL DEFAULT '0.00',
  `deposits` decimal(15,2) NOT NULL DEFAULT '0.00',
  `payee` varchar(255) DEFAULT NULL,
  `description` text,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int DEFAULT NULL,
  `transaction_id` varchar(150) DEFAULT NULL,
  `bank_id` int DEFAULT NULL,
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '1=>posted, 2=>pending',
  `matched` int NOT NULL DEFAULT '0',
  `reconcile` int NOT NULL DEFAULT '0',
  `adjusted` int NOT NULL DEFAULT '0',
  `is_imported` int NOT NULL DEFAULT '0',
  `banking_rule` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

#
# TABLE STRUCTURE FOR: tblacc_transfers
#

DROP TABLE IF EXISTS `tblacc_transfers`;

CREATE TABLE `tblacc_transfers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `transfer_funds_from` int NOT NULL,
  `transfer_funds_to` int NOT NULL,
  `transfer_amount` decimal(15,2) DEFAULT NULL,
  `date` varchar(45) DEFAULT NULL,
  `description` text,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

#
# TABLE STRUCTURE FOR: tblactivity_log
#

DROP TABLE IF EXISTS `tblactivity_log`;

CREATE TABLE `tblactivity_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` datetime NOT NULL,
  `staffid` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `staffid` (`staffid`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (1, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 212.70.108.7]', '2024-08-20 10:43:35', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (2, 'Database Backup [database_backup_2024-08-20-10-50-15-v3-1-6.zip]', '2024-08-20 10:50:15', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (3, 'Non Existing User Tried to Login [Email: alraedautomobile@dotswebsolution.com, Is Staff Member: No, IP: 212.70.108.7]', '2024-08-20 11:25:36', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (4, 'Database Backup [database_backup_2024-08-20-14-18-54-v3-1-6.zip]', '2024-08-20 14:18:54', '[CRON]');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (5, 'Non Existing User Tried to Login [Email: alraedautomobile@dotswebsolution.com, Is Staff Member: No, IP: 176.202.10.165]', '2024-08-20 14:21:18', NULL);
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (6, 'Failed Login Attempt [Email: alraedautomobile@dotswebsolution.com, Is Staff Member: Yes, IP: 176.202.10.165]', '2024-08-20 14:21:51', NULL);
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (7, 'Non Existing User Tried to Login [Email: alraedautomobile@dotswebsolution.com, Is Staff Member: No, IP: 176.202.10.165]', '2024-08-20 14:28:43', NULL);
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (8, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 176.202.10.165]', '2024-08-20 14:29:13', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (9, 'Failed Login Attempt [Email: alraedautomobile@dotswebsolution.com, Is Staff Member: Yes, IP: 176.202.10.165]', '2024-08-20 15:40:31', NULL);
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (10, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 176.202.10.165]', '2024-08-20 15:41:31', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (11, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 176.202.10.165]', '2024-08-20 15:41:50', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (12, 'New Lead Added [ID: 1]', '2024-08-20 16:16:14', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (13, 'New Invoice Item Added [ID:1, Computer]', '2024-08-20 16:17:47', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (14, 'New Invoice Item Added [ID:2, Laptop]', '2024-08-20 16:19:14', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (15, 'New Invoice Item Added [ID:3, Laptop]', '2024-08-20 16:19:36', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (16, 'New Proposal Created [ID: 1]', '2024-08-20 16:20:30', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (17, 'Proposal Status Changes [ProposalID:1, Status:Accepted,Client Action: 1]', '2024-08-20 16:21:53', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (18, 'Contact Created [ID: 1]', '2024-08-20 16:24:21', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (19, 'New Client Created [ID: 1, From Staff: 1]', '2024-08-20 16:24:21', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (20, 'Created Lead Client Profile [LeadID: 1, ClientID: 1]', '2024-08-20 16:24:21', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (21, 'Proposal Converted to Estimate [EstimateID: 1, ProposalID: 1]', '2024-08-20 16:25:11', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (22, 'Invoice Status Updated [Invoice Number: INV-000001, From: Unpaid To: Paid]', '2024-08-20 16:28:05', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (23, 'Payment Recorded [ID:1, Invoice Number: INV-000001, Total: $4,761.00]', '2024-08-20 16:28:05', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (24, 'Payment Updated [Number:1]', '2024-08-20 16:28:36', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (25, 'New Estimate Request Form Added [Mohammed ]', '2024-08-20 16:53:12', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (26, 'New Customer Group Created [ID:1, Name:Walk-in Customer]', '2024-08-20 16:56:13', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (27, 'New Customer Group Created [ID:2, Name:Insurance Customer]', '2024-08-20 16:56:42', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (28, 'New Currency Added [ID: QAR]', '2024-08-20 16:59:31', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (29, 'Currency Updated [QAR]', '2024-08-20 17:00:11', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (30, 'Currency Deleted [2]', '2024-08-20 17:00:21', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (31, 'Invoice Deleted [INV-000001]', '2024-08-20 17:01:54', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (32, 'Estimates Deleted [Number: EST-000001]', '2024-08-20 17:02:21', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (33, 'Proposal Deleted [ProposalID:1]', '2024-08-20 17:02:50', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (34, 'New Payment Mode Added [ID: 2, Name:Cash]', '2024-08-20 17:04:35', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (35, 'New Payment Mode Added [ID: 3, Name:Debit / Credit Card]', '2024-08-20 17:05:34', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (36, 'New Expense Category Added [ID: 1]', '2024-08-20 17:11:36', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (37, 'New Expense Category Added [ID: 2]', '2024-08-20 17:11:57', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (38, 'New Expense Category Added [ID: 3]', '2024-08-20 17:12:15', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (39, 'New Expense Category Added [ID: 4]', '2024-08-20 17:12:30', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (40, 'New Expense Category Added [ID: 5]', '2024-08-20 17:12:50', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (41, 'New Expense Category Added [ID: 6]', '2024-08-20 17:13:31', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (42, 'New Expense Category Added [ID: 7]', '2024-08-20 17:13:42', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (43, 'New Expense Category Added [ID: 8]', '2024-08-20 17:13:51', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (44, 'New Expense Category Added [ID: 9]', '2024-08-20 17:13:59', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (45, 'New Expense Category Added [ID: 10]', '2024-08-20 17:14:11', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (46, 'New Expense Category Added [ID: 11]', '2024-08-20 17:14:24', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (47, 'New Expense Category Added [ID: 12]', '2024-08-20 17:14:34', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (48, 'New Role Added [ID: 2.Manager]', '2024-08-20 17:29:05', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (49, 'Currency Deleted [1]', '2024-08-20 17:47:42', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (50, 'Client Deleted [ID: 1]', '2024-08-20 18:01:03', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (51, 'New Client Created [ID: 2, From Staff: 1]', '2024-08-20 18:02:45', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (52, 'New Client Created [ID: 3, From Staff: 1]', '2024-08-20 18:03:56', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (53, 'Customer Info Updated [ID: 2]', '2024-08-20 18:04:21', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (54, 'New Custom Field Added [Insurance Number]', '2024-08-20 19:00:27', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (55, 'New Custom Field Added [Vehicle Number]', '2024-08-20 19:01:05', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (56, 'New Custom Field Added [Vehicle Model / Year]', '2024-08-20 19:02:10', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (57, 'New Custom Field Added [Brand Name]', '2024-08-20 19:02:38', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (58, 'New Custom Field Added [Insurance Number]', '2024-08-20 19:03:01', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (59, 'New Custom Field Added [Vehicle Number]', '2024-08-20 19:03:19', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (60, 'New Custom Field Added [Vehicle Model / Year]', '2024-08-20 19:03:40', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (61, 'New Custom Field Added [Brand Name]', '2024-08-20 19:04:01', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (62, 'Lead Deleted [Deleted by: Alraed Automobile, ID: 1]', '2024-08-20 19:06:29', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (63, 'Custom Field Updated [Insurance Number]', '2024-08-20 19:33:28', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (64, 'Custom Field Updated [Vehicle Number]', '2024-08-20 19:34:16', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (65, 'Custom Field Updated [Vehicle Model / Year]', '2024-08-20 19:34:34', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (66, 'Custom Field Updated [Brand Name]', '2024-08-20 19:34:47', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (67, 'Custom Field Updated [Insurance Number]', '2024-08-20 19:35:05', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (68, 'Custom Field Updated [Vehicle Number]', '2024-08-20 19:35:21', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (69, 'Custom Field Updated [Vehicle Model / Year]', '2024-08-20 19:35:35', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (70, 'Custom Field Updated [Brand Name]', '2024-08-20 19:35:51', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (71, 'Non Existing User Tried to Login [Email: alraedautomobile@dotswebsolution.com, Is Staff Member: No, IP: 176.202.10.165]', '2024-08-21 10:26:21', NULL);
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (72, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 176.202.10.165]', '2024-08-21 10:26:34', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (73, 'Payment Mode Updated [ID: 2, Name:Cash]', '2024-08-21 10:50:38', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (74, 'Payment Mode Updated [ID: 1, Name:Bank]', '2024-08-21 10:50:45', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (75, 'Payment Mode Updated [ID: 1, Name:Bank]', '2024-08-21 10:50:56', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (76, 'Payment Mode Updated [ID: 3, Name:Debit / Credit Card]', '2024-08-21 10:51:00', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (77, 'Invoice Status Updated [Invoice Number: INV-2024/000001, From: Unpaid To: Partially Paid]', '2024-08-21 10:52:41', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (78, 'Payment Recorded [ID:2, Invoice Number: INV-2024/000001, Total: 1,000.00QAR]', '2024-08-21 10:52:41', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (79, 'Payment Recorded [ID:3, Invoice Number: INV-2024/000001, Total: 500.00QAR]', '2024-08-21 12:22:40', 'Alraed Automobile');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (80, 'Database Backup [database_backup_2024-08-22-08-00-06-v3-1-6.zip]', '2024-08-22 08:00:06', '[CRON]');


#
# TABLE STRUCTURE FOR: tblannouncements
#

DROP TABLE IF EXISTS `tblannouncements`;

CREATE TABLE `tblannouncements` (
  `announcementid` int NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `showtousers` int NOT NULL,
  `showtostaff` int NOT NULL,
  `showname` int NOT NULL,
  `dateadded` datetime NOT NULL,
  `userid` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`announcementid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblclients
#

DROP TABLE IF EXISTS `tblclients`;

CREATE TABLE `tblclients` (
  `userid` int NOT NULL AUTO_INCREMENT,
  `company` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vat` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phonenumber` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` int NOT NULL DEFAULT '0',
  `city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zip` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `active` int NOT NULL DEFAULT '1',
  `leadid` int DEFAULT NULL,
  `billing_street` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_state` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_zip` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_country` int DEFAULT '0',
  `shipping_street` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_state` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_zip` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_country` int DEFAULT '0',
  `longitude` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `latitude` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `default_language` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `default_currency` int NOT NULL DEFAULT '0',
  `show_primary_contact` int NOT NULL DEFAULT '0',
  `stripe_id` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `registration_confirmed` int NOT NULL DEFAULT '1',
  `addedfrom` int NOT NULL DEFAULT '0',
  `balance` decimal(15,2) DEFAULT NULL,
  `balance_as_of` date DEFAULT NULL,
  PRIMARY KEY (`userid`),
  KEY `country` (`country`),
  KEY `leadid` (`leadid`),
  KEY `company` (`company`),
  KEY `active` (`active`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tblclients` (`userid`, `company`, `vat`, `phonenumber`, `country`, `city`, `zip`, `state`, `address`, `website`, `datecreated`, `active`, `leadid`, `billing_street`, `billing_city`, `billing_state`, `billing_zip`, `billing_country`, `shipping_street`, `shipping_city`, `shipping_state`, `shipping_zip`, `shipping_country`, `longitude`, `latitude`, `default_language`, `default_currency`, `show_primary_contact`, `stripe_id`, `registration_confirmed`, `addedfrom`, `balance`, `balance_as_of`) VALUES (2, 'Walk-in Customer', NULL, '', 179, 'Doha', '', '', '', '', '2024-08-20 18:02:45', 1, NULL, '', '', '', '', 0, '', '', '', '', 0, NULL, NULL, '', 3, 0, NULL, 1, 1, NULL, NULL);
INSERT INTO `tblclients` (`userid`, `company`, `vat`, `phonenumber`, `country`, `city`, `zip`, `state`, `address`, `website`, `datecreated`, `active`, `leadid`, `billing_street`, `billing_city`, `billing_state`, `billing_zip`, `billing_country`, `shipping_street`, `shipping_city`, `shipping_state`, `shipping_zip`, `shipping_country`, `longitude`, `latitude`, `default_language`, `default_currency`, `show_primary_contact`, `stripe_id`, `registration_confirmed`, `addedfrom`, `balance`, `balance_as_of`) VALUES (3, 'Insurance Customer', NULL, '', 179, 'Doha', '', '', '', '', '2024-08-20 18:03:55', 1, NULL, '', '', '', '', 0, '', '', '', '', 0, NULL, NULL, '', 3, 0, NULL, 1, 1, NULL, NULL);


#
# TABLE STRUCTURE FOR: tblconsent_purposes
#

DROP TABLE IF EXISTS `tblconsent_purposes`;

CREATE TABLE `tblconsent_purposes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `date_created` datetime NOT NULL,
  `last_updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblconsents
#

DROP TABLE IF EXISTS `tblconsents`;

CREATE TABLE `tblconsents` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` datetime NOT NULL,
  `ip` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_id` int NOT NULL DEFAULT '0',
  `lead_id` int NOT NULL DEFAULT '0',
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `opt_in_purpose_description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `purpose_id` int NOT NULL,
  `staff_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `purpose_id` (`purpose_id`),
  KEY `contact_id` (`contact_id`),
  KEY `lead_id` (`lead_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblcontact_permissions
#

DROP TABLE IF EXISTS `tblcontact_permissions`;

CREATE TABLE `tblcontact_permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permission_id` int NOT NULL,
  `userid` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblcontacts
#

DROP TABLE IF EXISTS `tblcontacts`;

CREATE TABLE `tblcontacts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userid` int NOT NULL,
  `is_primary` int NOT NULL DEFAULT '1',
  `firstname` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastname` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phonenumber` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `new_pass_key` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `new_pass_key_requested` datetime DEFAULT NULL,
  `email_verified_at` datetime DEFAULT NULL,
  `email_verification_key` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verification_sent_at` datetime DEFAULT NULL,
  `last_ip` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_password_change` datetime DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `profile_image` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `direction` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_emails` tinyint(1) NOT NULL DEFAULT '1',
  `estimate_emails` tinyint(1) NOT NULL DEFAULT '1',
  `credit_note_emails` tinyint(1) NOT NULL DEFAULT '1',
  `contract_emails` tinyint(1) NOT NULL DEFAULT '1',
  `task_emails` tinyint(1) NOT NULL DEFAULT '1',
  `project_emails` tinyint(1) NOT NULL DEFAULT '1',
  `ticket_emails` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `firstname` (`firstname`),
  KEY `lastname` (`lastname`),
  KEY `email` (`email`),
  KEY `is_primary` (`is_primary`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblcontract_comments
#

DROP TABLE IF EXISTS `tblcontract_comments`;

CREATE TABLE `tblcontract_comments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `contract_id` int NOT NULL,
  `staffid` int NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblcontract_renewals
#

DROP TABLE IF EXISTS `tblcontract_renewals`;

CREATE TABLE `tblcontract_renewals` (
  `id` int NOT NULL AUTO_INCREMENT,
  `contractid` int NOT NULL,
  `old_start_date` date NOT NULL,
  `new_start_date` date NOT NULL,
  `old_end_date` date DEFAULT NULL,
  `new_end_date` date DEFAULT NULL,
  `old_value` decimal(15,2) DEFAULT NULL,
  `new_value` decimal(15,2) DEFAULT NULL,
  `date_renewed` datetime NOT NULL,
  `renewed_by` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `renewed_by_staff_id` int NOT NULL DEFAULT '0',
  `is_on_old_expiry_notified` int DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblcontracts
#

DROP TABLE IF EXISTS `tblcontracts`;

CREATE TABLE `tblcontracts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `subject` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `client` int NOT NULL,
  `datestart` date DEFAULT NULL,
  `dateend` date DEFAULT NULL,
  `contract_type` int DEFAULT NULL,
  `project_id` int DEFAULT NULL,
  `addedfrom` int NOT NULL,
  `dateadded` datetime NOT NULL,
  `isexpirynotified` int NOT NULL DEFAULT '0',
  `contract_value` decimal(15,2) DEFAULT NULL,
  `trash` tinyint(1) DEFAULT '0',
  `not_visible_to_client` tinyint(1) NOT NULL DEFAULT '0',
  `hash` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `signed` tinyint(1) NOT NULL DEFAULT '0',
  `signature` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `marked_as_signed` tinyint(1) NOT NULL DEFAULT '0',
  `acceptance_firstname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `acceptance_lastname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `acceptance_email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_ip` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `short_link` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_sent_at` datetime DEFAULT NULL,
  `contacts_sent_to` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `last_sign_reminder_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `client` (`client`),
  KEY `contract_type` (`contract_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblcontracts_types
#

DROP TABLE IF EXISTS `tblcontracts_types`;

CREATE TABLE `tblcontracts_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblcountries
#

DROP TABLE IF EXISTS `tblcountries`;

CREATE TABLE `tblcountries` (
  `country_id` int NOT NULL AUTO_INCREMENT,
  `iso2` char(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `short_name` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `long_name` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `iso3` char(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numcode` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `un_member` varchar(12) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `calling_code` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cctld` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`country_id`)
) ENGINE=InnoDB AUTO_INCREMENT=251 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (1, 'AF', 'Afghanistan', 'Islamic Republic of Afghanistan', 'AFG', '004', 'yes', '93', '.af');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (2, 'AX', 'Aland Islands', '&Aring;land Islands', 'ALA', '248', 'no', '358', '.ax');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (3, 'AL', 'Albania', 'Republic of Albania', 'ALB', '008', 'yes', '355', '.al');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (4, 'DZ', 'Algeria', 'People\'s Democratic Republic of Algeria', 'DZA', '012', 'yes', '213', '.dz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (5, 'AS', 'American Samoa', 'American Samoa', 'ASM', '016', 'no', '1+684', '.as');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (6, 'AD', 'Andorra', 'Principality of Andorra', 'AND', '020', 'yes', '376', '.ad');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (7, 'AO', 'Angola', 'Republic of Angola', 'AGO', '024', 'yes', '244', '.ao');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (8, 'AI', 'Anguilla', 'Anguilla', 'AIA', '660', 'no', '1+264', '.ai');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (9, 'AQ', 'Antarctica', 'Antarctica', 'ATA', '010', 'no', '672', '.aq');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (10, 'AG', 'Antigua and Barbuda', 'Antigua and Barbuda', 'ATG', '028', 'yes', '1+268', '.ag');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (11, 'AR', 'Argentina', 'Argentine Republic', 'ARG', '032', 'yes', '54', '.ar');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (12, 'AM', 'Armenia', 'Republic of Armenia', 'ARM', '051', 'yes', '374', '.am');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (13, 'AW', 'Aruba', 'Aruba', 'ABW', '533', 'no', '297', '.aw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (14, 'AU', 'Australia', 'Commonwealth of Australia', 'AUS', '036', 'yes', '61', '.au');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (15, 'AT', 'Austria', 'Republic of Austria', 'AUT', '040', 'yes', '43', '.at');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (16, 'AZ', 'Azerbaijan', 'Republic of Azerbaijan', 'AZE', '031', 'yes', '994', '.az');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (17, 'BS', 'Bahamas', 'Commonwealth of The Bahamas', 'BHS', '044', 'yes', '1+242', '.bs');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (18, 'BH', 'Bahrain', 'Kingdom of Bahrain', 'BHR', '048', 'yes', '973', '.bh');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (19, 'BD', 'Bangladesh', 'People\'s Republic of Bangladesh', 'BGD', '050', 'yes', '880', '.bd');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (20, 'BB', 'Barbados', 'Barbados', 'BRB', '052', 'yes', '1+246', '.bb');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (21, 'BY', 'Belarus', 'Republic of Belarus', 'BLR', '112', 'yes', '375', '.by');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (22, 'BE', 'Belgium', 'Kingdom of Belgium', 'BEL', '056', 'yes', '32', '.be');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (23, 'BZ', 'Belize', 'Belize', 'BLZ', '084', 'yes', '501', '.bz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (24, 'BJ', 'Benin', 'Republic of Benin', 'BEN', '204', 'yes', '229', '.bj');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (25, 'BM', 'Bermuda', 'Bermuda Islands', 'BMU', '060', 'no', '1+441', '.bm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (26, 'BT', 'Bhutan', 'Kingdom of Bhutan', 'BTN', '064', 'yes', '975', '.bt');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (27, 'BO', 'Bolivia', 'Plurinational State of Bolivia', 'BOL', '068', 'yes', '591', '.bo');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (28, 'BQ', 'Bonaire, Sint Eustatius and Saba', 'Bonaire, Sint Eustatius and Saba', 'BES', '535', 'no', '599', '.bq');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (29, 'BA', 'Bosnia and Herzegovina', 'Bosnia and Herzegovina', 'BIH', '070', 'yes', '387', '.ba');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (30, 'BW', 'Botswana', 'Republic of Botswana', 'BWA', '072', 'yes', '267', '.bw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (31, 'BV', 'Bouvet Island', 'Bouvet Island', 'BVT', '074', 'no', 'NONE', '.bv');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (32, 'BR', 'Brazil', 'Federative Republic of Brazil', 'BRA', '076', 'yes', '55', '.br');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (33, 'IO', 'British Indian Ocean Territory', 'British Indian Ocean Territory', 'IOT', '086', 'no', '246', '.io');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (34, 'BN', 'Brunei', 'Brunei Darussalam', 'BRN', '096', 'yes', '673', '.bn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (35, 'BG', 'Bulgaria', 'Republic of Bulgaria', 'BGR', '100', 'yes', '359', '.bg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (36, 'BF', 'Burkina Faso', 'Burkina Faso', 'BFA', '854', 'yes', '226', '.bf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (37, 'BI', 'Burundi', 'Republic of Burundi', 'BDI', '108', 'yes', '257', '.bi');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (38, 'KH', 'Cambodia', 'Kingdom of Cambodia', 'KHM', '116', 'yes', '855', '.kh');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (39, 'CM', 'Cameroon', 'Republic of Cameroon', 'CMR', '120', 'yes', '237', '.cm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (40, 'CA', 'Canada', 'Canada', 'CAN', '124', 'yes', '1', '.ca');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (41, 'CV', 'Cape Verde', 'Republic of Cape Verde', 'CPV', '132', 'yes', '238', '.cv');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (42, 'KY', 'Cayman Islands', 'The Cayman Islands', 'CYM', '136', 'no', '1+345', '.ky');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (43, 'CF', 'Central African Republic', 'Central African Republic', 'CAF', '140', 'yes', '236', '.cf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (44, 'TD', 'Chad', 'Republic of Chad', 'TCD', '148', 'yes', '235', '.td');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (45, 'CL', 'Chile', 'Republic of Chile', 'CHL', '152', 'yes', '56', '.cl');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (46, 'CN', 'China', 'People\'s Republic of China', 'CHN', '156', 'yes', '86', '.cn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (47, 'CX', 'Christmas Island', 'Christmas Island', 'CXR', '162', 'no', '61', '.cx');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (48, 'CC', 'Cocos (Keeling) Islands', 'Cocos (Keeling) Islands', 'CCK', '166', 'no', '61', '.cc');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (49, 'CO', 'Colombia', 'Republic of Colombia', 'COL', '170', 'yes', '57', '.co');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (50, 'KM', 'Comoros', 'Union of the Comoros', 'COM', '174', 'yes', '269', '.km');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (51, 'CG', 'Congo', 'Republic of the Congo', 'COG', '178', 'yes', '242', '.cg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (52, 'CK', 'Cook Islands', 'Cook Islands', 'COK', '184', 'some', '682', '.ck');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (53, 'CR', 'Costa Rica', 'Republic of Costa Rica', 'CRI', '188', 'yes', '506', '.cr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (54, 'CI', 'Cote d\'ivoire (Ivory Coast)', 'Republic of C&ocirc;te D\'Ivoire (Ivory Coast)', 'CIV', '384', 'yes', '225', '.ci');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (55, 'HR', 'Croatia', 'Republic of Croatia', 'HRV', '191', 'yes', '385', '.hr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (56, 'CU', 'Cuba', 'Republic of Cuba', 'CUB', '192', 'yes', '53', '.cu');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (57, 'CW', 'Curacao', 'Cura&ccedil;ao', 'CUW', '531', 'no', '599', '.cw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (58, 'CY', 'Cyprus', 'Republic of Cyprus', 'CYP', '196', 'yes', '357', '.cy');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (59, 'CZ', 'Czech Republic', 'Czech Republic', 'CZE', '203', 'yes', '420', '.cz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (60, 'CD', 'Democratic Republic of the Congo', 'Democratic Republic of the Congo', 'COD', '180', 'yes', '243', '.cd');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (61, 'DK', 'Denmark', 'Kingdom of Denmark', 'DNK', '208', 'yes', '45', '.dk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (62, 'DJ', 'Djibouti', 'Republic of Djibouti', 'DJI', '262', 'yes', '253', '.dj');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (63, 'DM', 'Dominica', 'Commonwealth of Dominica', 'DMA', '212', 'yes', '1+767', '.dm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (64, 'DO', 'Dominican Republic', 'Dominican Republic', 'DOM', '214', 'yes', '1+809, 8', '.do');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (65, 'EC', 'Ecuador', 'Republic of Ecuador', 'ECU', '218', 'yes', '593', '.ec');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (66, 'EG', 'Egypt', 'Arab Republic of Egypt', 'EGY', '818', 'yes', '20', '.eg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (67, 'SV', 'El Salvador', 'Republic of El Salvador', 'SLV', '222', 'yes', '503', '.sv');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (68, 'GQ', 'Equatorial Guinea', 'Republic of Equatorial Guinea', 'GNQ', '226', 'yes', '240', '.gq');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (69, 'ER', 'Eritrea', 'State of Eritrea', 'ERI', '232', 'yes', '291', '.er');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (70, 'EE', 'Estonia', 'Republic of Estonia', 'EST', '233', 'yes', '372', '.ee');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (71, 'ET', 'Ethiopia', 'Federal Democratic Republic of Ethiopia', 'ETH', '231', 'yes', '251', '.et');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (72, 'FK', 'Falkland Islands (Malvinas)', 'The Falkland Islands (Malvinas)', 'FLK', '238', 'no', '500', '.fk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (73, 'FO', 'Faroe Islands', 'The Faroe Islands', 'FRO', '234', 'no', '298', '.fo');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (74, 'FJ', 'Fiji', 'Republic of Fiji', 'FJI', '242', 'yes', '679', '.fj');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (75, 'FI', 'Finland', 'Republic of Finland', 'FIN', '246', 'yes', '358', '.fi');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (76, 'FR', 'France', 'French Republic', 'FRA', '250', 'yes', '33', '.fr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (77, 'GF', 'French Guiana', 'French Guiana', 'GUF', '254', 'no', '594', '.gf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (78, 'PF', 'French Polynesia', 'French Polynesia', 'PYF', '258', 'no', '689', '.pf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (79, 'TF', 'French Southern Territories', 'French Southern Territories', 'ATF', '260', 'no', NULL, '.tf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (80, 'GA', 'Gabon', 'Gabonese Republic', 'GAB', '266', 'yes', '241', '.ga');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (81, 'GM', 'Gambia', 'Republic of The Gambia', 'GMB', '270', 'yes', '220', '.gm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (82, 'GE', 'Georgia', 'Georgia', 'GEO', '268', 'yes', '995', '.ge');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (83, 'DE', 'Germany', 'Federal Republic of Germany', 'DEU', '276', 'yes', '49', '.de');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (84, 'GH', 'Ghana', 'Republic of Ghana', 'GHA', '288', 'yes', '233', '.gh');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (85, 'GI', 'Gibraltar', 'Gibraltar', 'GIB', '292', 'no', '350', '.gi');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (86, 'GR', 'Greece', 'Hellenic Republic', 'GRC', '300', 'yes', '30', '.gr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (87, 'GL', 'Greenland', 'Greenland', 'GRL', '304', 'no', '299', '.gl');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (88, 'GD', 'Grenada', 'Grenada', 'GRD', '308', 'yes', '1+473', '.gd');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (89, 'GP', 'Guadaloupe', 'Guadeloupe', 'GLP', '312', 'no', '590', '.gp');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (90, 'GU', 'Guam', 'Guam', 'GUM', '316', 'no', '1+671', '.gu');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (91, 'GT', 'Guatemala', 'Republic of Guatemala', 'GTM', '320', 'yes', '502', '.gt');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (92, 'GG', 'Guernsey', 'Guernsey', 'GGY', '831', 'no', '44', '.gg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (93, 'GN', 'Guinea', 'Republic of Guinea', 'GIN', '324', 'yes', '224', '.gn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (94, 'GW', 'Guinea-Bissau', 'Republic of Guinea-Bissau', 'GNB', '624', 'yes', '245', '.gw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (95, 'GY', 'Guyana', 'Co-operative Republic of Guyana', 'GUY', '328', 'yes', '592', '.gy');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (96, 'HT', 'Haiti', 'Republic of Haiti', 'HTI', '332', 'yes', '509', '.ht');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (97, 'HM', 'Heard Island and McDonald Islands', 'Heard Island and McDonald Islands', 'HMD', '334', 'no', 'NONE', '.hm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (98, 'HN', 'Honduras', 'Republic of Honduras', 'HND', '340', 'yes', '504', '.hn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (99, 'HK', 'Hong Kong', 'Hong Kong', 'HKG', '344', 'no', '852', '.hk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (100, 'HU', 'Hungary', 'Hungary', 'HUN', '348', 'yes', '36', '.hu');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (101, 'IS', 'Iceland', 'Republic of Iceland', 'ISL', '352', 'yes', '354', '.is');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (102, 'IN', 'India', 'Republic of India', 'IND', '356', 'yes', '91', '.in');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (103, 'ID', 'Indonesia', 'Republic of Indonesia', 'IDN', '360', 'yes', '62', '.id');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (104, 'IR', 'Iran', 'Islamic Republic of Iran', 'IRN', '364', 'yes', '98', '.ir');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (105, 'IQ', 'Iraq', 'Republic of Iraq', 'IRQ', '368', 'yes', '964', '.iq');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (106, 'IE', 'Ireland', 'Ireland', 'IRL', '372', 'yes', '353', '.ie');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (107, 'IM', 'Isle of Man', 'Isle of Man', 'IMN', '833', 'no', '44', '.im');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (108, 'IL', 'Israel', 'State of Israel', 'ISR', '376', 'yes', '972', '.il');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (109, 'IT', 'Italy', 'Italian Republic', 'ITA', '380', 'yes', '39', '.jm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (110, 'JM', 'Jamaica', 'Jamaica', 'JAM', '388', 'yes', '1+876', '.jm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (111, 'JP', 'Japan', 'Japan', 'JPN', '392', 'yes', '81', '.jp');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (112, 'JE', 'Jersey', 'The Bailiwick of Jersey', 'JEY', '832', 'no', '44', '.je');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (113, 'JO', 'Jordan', 'Hashemite Kingdom of Jordan', 'JOR', '400', 'yes', '962', '.jo');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (114, 'KZ', 'Kazakhstan', 'Republic of Kazakhstan', 'KAZ', '398', 'yes', '7', '.kz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (115, 'KE', 'Kenya', 'Republic of Kenya', 'KEN', '404', 'yes', '254', '.ke');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (116, 'KI', 'Kiribati', 'Republic of Kiribati', 'KIR', '296', 'yes', '686', '.ki');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (117, 'XK', 'Kosovo', 'Republic of Kosovo', '---', '---', 'some', '381', '');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (118, 'KW', 'Kuwait', 'State of Kuwait', 'KWT', '414', 'yes', '965', '.kw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (119, 'KG', 'Kyrgyzstan', 'Kyrgyz Republic', 'KGZ', '417', 'yes', '996', '.kg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (120, 'LA', 'Laos', 'Lao People\'s Democratic Republic', 'LAO', '418', 'yes', '856', '.la');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (121, 'LV', 'Latvia', 'Republic of Latvia', 'LVA', '428', 'yes', '371', '.lv');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (122, 'LB', 'Lebanon', 'Republic of Lebanon', 'LBN', '422', 'yes', '961', '.lb');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (123, 'LS', 'Lesotho', 'Kingdom of Lesotho', 'LSO', '426', 'yes', '266', '.ls');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (124, 'LR', 'Liberia', 'Republic of Liberia', 'LBR', '430', 'yes', '231', '.lr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (125, 'LY', 'Libya', 'Libya', 'LBY', '434', 'yes', '218', '.ly');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (126, 'LI', 'Liechtenstein', 'Principality of Liechtenstein', 'LIE', '438', 'yes', '423', '.li');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (127, 'LT', 'Lithuania', 'Republic of Lithuania', 'LTU', '440', 'yes', '370', '.lt');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (128, 'LU', 'Luxembourg', 'Grand Duchy of Luxembourg', 'LUX', '442', 'yes', '352', '.lu');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (129, 'MO', 'Macao', 'The Macao Special Administrative Region', 'MAC', '446', 'no', '853', '.mo');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (130, 'MK', 'North Macedonia', 'Republic of North Macedonia', 'MKD', '807', 'yes', '389', '.mk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (131, 'MG', 'Madagascar', 'Republic of Madagascar', 'MDG', '450', 'yes', '261', '.mg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (132, 'MW', 'Malawi', 'Republic of Malawi', 'MWI', '454', 'yes', '265', '.mw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (133, 'MY', 'Malaysia', 'Malaysia', 'MYS', '458', 'yes', '60', '.my');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (134, 'MV', 'Maldives', 'Republic of Maldives', 'MDV', '462', 'yes', '960', '.mv');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (135, 'ML', 'Mali', 'Republic of Mali', 'MLI', '466', 'yes', '223', '.ml');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (136, 'MT', 'Malta', 'Republic of Malta', 'MLT', '470', 'yes', '356', '.mt');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (137, 'MH', 'Marshall Islands', 'Republic of the Marshall Islands', 'MHL', '584', 'yes', '692', '.mh');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (138, 'MQ', 'Martinique', 'Martinique', 'MTQ', '474', 'no', '596', '.mq');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (139, 'MR', 'Mauritania', 'Islamic Republic of Mauritania', 'MRT', '478', 'yes', '222', '.mr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (140, 'MU', 'Mauritius', 'Republic of Mauritius', 'MUS', '480', 'yes', '230', '.mu');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (141, 'YT', 'Mayotte', 'Mayotte', 'MYT', '175', 'no', '262', '.yt');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (142, 'MX', 'Mexico', 'United Mexican States', 'MEX', '484', 'yes', '52', '.mx');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (143, 'FM', 'Micronesia', 'Federated States of Micronesia', 'FSM', '583', 'yes', '691', '.fm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (144, 'MD', 'Moldava', 'Republic of Moldova', 'MDA', '498', 'yes', '373', '.md');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (145, 'MC', 'Monaco', 'Principality of Monaco', 'MCO', '492', 'yes', '377', '.mc');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (146, 'MN', 'Mongolia', 'Mongolia', 'MNG', '496', 'yes', '976', '.mn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (147, 'ME', 'Montenegro', 'Montenegro', 'MNE', '499', 'yes', '382', '.me');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (148, 'MS', 'Montserrat', 'Montserrat', 'MSR', '500', 'no', '1+664', '.ms');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (149, 'MA', 'Morocco', 'Kingdom of Morocco', 'MAR', '504', 'yes', '212', '.ma');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (150, 'MZ', 'Mozambique', 'Republic of Mozambique', 'MOZ', '508', 'yes', '258', '.mz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (151, 'MM', 'Myanmar (Burma)', 'Republic of the Union of Myanmar', 'MMR', '104', 'yes', '95', '.mm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (152, 'NA', 'Namibia', 'Republic of Namibia', 'NAM', '516', 'yes', '264', '.na');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (153, 'NR', 'Nauru', 'Republic of Nauru', 'NRU', '520', 'yes', '674', '.nr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (154, 'NP', 'Nepal', 'Federal Democratic Republic of Nepal', 'NPL', '524', 'yes', '977', '.np');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (155, 'NL', 'Netherlands', 'Kingdom of the Netherlands', 'NLD', '528', 'yes', '31', '.nl');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (156, 'NC', 'New Caledonia', 'New Caledonia', 'NCL', '540', 'no', '687', '.nc');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (157, 'NZ', 'New Zealand', 'New Zealand', 'NZL', '554', 'yes', '64', '.nz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (158, 'NI', 'Nicaragua', 'Republic of Nicaragua', 'NIC', '558', 'yes', '505', '.ni');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (159, 'NE', 'Niger', 'Republic of Niger', 'NER', '562', 'yes', '227', '.ne');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (160, 'NG', 'Nigeria', 'Federal Republic of Nigeria', 'NGA', '566', 'yes', '234', '.ng');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (161, 'NU', 'Niue', 'Niue', 'NIU', '570', 'some', '683', '.nu');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (162, 'NF', 'Norfolk Island', 'Norfolk Island', 'NFK', '574', 'no', '672', '.nf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (163, 'KP', 'North Korea', 'Democratic People\'s Republic of Korea', 'PRK', '408', 'yes', '850', '.kp');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (164, 'MP', 'Northern Mariana Islands', 'Northern Mariana Islands', 'MNP', '580', 'no', '1+670', '.mp');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (165, 'NO', 'Norway', 'Kingdom of Norway', 'NOR', '578', 'yes', '47', '.no');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (166, 'OM', 'Oman', 'Sultanate of Oman', 'OMN', '512', 'yes', '968', '.om');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (167, 'PK', 'Pakistan', 'Islamic Republic of Pakistan', 'PAK', '586', 'yes', '92', '.pk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (168, 'PW', 'Palau', 'Republic of Palau', 'PLW', '585', 'yes', '680', '.pw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (169, 'PS', 'Palestine', 'State of Palestine (or Occupied Palestinian Territory)', 'PSE', '275', 'some', '970', '.ps');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (170, 'PA', 'Panama', 'Republic of Panama', 'PAN', '591', 'yes', '507', '.pa');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (171, 'PG', 'Papua New Guinea', 'Independent State of Papua New Guinea', 'PNG', '598', 'yes', '675', '.pg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (172, 'PY', 'Paraguay', 'Republic of Paraguay', 'PRY', '600', 'yes', '595', '.py');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (173, 'PE', 'Peru', 'Republic of Peru', 'PER', '604', 'yes', '51', '.pe');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (174, 'PH', 'Philippines', 'Republic of the Philippines', 'PHL', '608', 'yes', '63', '.ph');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (175, 'PN', 'Pitcairn', 'Pitcairn', 'PCN', '612', 'no', 'NONE', '.pn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (176, 'PL', 'Poland', 'Republic of Poland', 'POL', '616', 'yes', '48', '.pl');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (177, 'PT', 'Portugal', 'Portuguese Republic', 'PRT', '620', 'yes', '351', '.pt');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (178, 'PR', 'Puerto Rico', 'Commonwealth of Puerto Rico', 'PRI', '630', 'no', '1+939', '.pr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (179, 'QA', 'Qatar', 'State of Qatar', 'QAT', '634', 'yes', '974', '.qa');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (180, 'RE', 'Reunion', 'R&eacute;union', 'REU', '638', 'no', '262', '.re');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (181, 'RO', 'Romania', 'Romania', 'ROU', '642', 'yes', '40', '.ro');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (182, 'RU', 'Russia', 'Russian Federation', 'RUS', '643', 'yes', '7', '.ru');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (183, 'RW', 'Rwanda', 'Republic of Rwanda', 'RWA', '646', 'yes', '250', '.rw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (184, 'BL', 'Saint Barthelemy', 'Saint Barth&eacute;lemy', 'BLM', '652', 'no', '590', '.bl');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (185, 'SH', 'Saint Helena', 'Saint Helena, Ascension and Tristan da Cunha', 'SHN', '654', 'no', '290', '.sh');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (186, 'KN', 'Saint Kitts and Nevis', 'Federation of Saint Christopher and Nevis', 'KNA', '659', 'yes', '1+869', '.kn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (187, 'LC', 'Saint Lucia', 'Saint Lucia', 'LCA', '662', 'yes', '1+758', '.lc');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (188, 'MF', 'Saint Martin', 'Saint Martin', 'MAF', '663', 'no', '590', '.mf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (189, 'PM', 'Saint Pierre and Miquelon', 'Saint Pierre and Miquelon', 'SPM', '666', 'no', '508', '.pm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (190, 'VC', 'Saint Vincent and the Grenadines', 'Saint Vincent and the Grenadines', 'VCT', '670', 'yes', '1+784', '.vc');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (191, 'WS', 'Samoa', 'Independent State of Samoa', 'WSM', '882', 'yes', '685', '.ws');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (192, 'SM', 'San Marino', 'Republic of San Marino', 'SMR', '674', 'yes', '378', '.sm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (193, 'ST', 'Sao Tome and Principe', 'Democratic Republic of S&atilde;o Tom&eacute; and Pr&iacute;ncipe', 'STP', '678', 'yes', '239', '.st');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (194, 'SA', 'Saudi Arabia', 'Kingdom of Saudi Arabia', 'SAU', '682', 'yes', '966', '.sa');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (195, 'SN', 'Senegal', 'Republic of Senegal', 'SEN', '686', 'yes', '221', '.sn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (196, 'RS', 'Serbia', 'Republic of Serbia', 'SRB', '688', 'yes', '381', '.rs');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (197, 'SC', 'Seychelles', 'Republic of Seychelles', 'SYC', '690', 'yes', '248', '.sc');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (198, 'SL', 'Sierra Leone', 'Republic of Sierra Leone', 'SLE', '694', 'yes', '232', '.sl');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (199, 'SG', 'Singapore', 'Republic of Singapore', 'SGP', '702', 'yes', '65', '.sg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (200, 'SX', 'Sint Maarten', 'Sint Maarten', 'SXM', '534', 'no', '1+721', '.sx');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (201, 'SK', 'Slovakia', 'Slovak Republic', 'SVK', '703', 'yes', '421', '.sk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (202, 'SI', 'Slovenia', 'Republic of Slovenia', 'SVN', '705', 'yes', '386', '.si');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (203, 'SB', 'Solomon Islands', 'Solomon Islands', 'SLB', '090', 'yes', '677', '.sb');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (204, 'SO', 'Somalia', 'Somali Republic', 'SOM', '706', 'yes', '252', '.so');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (205, 'ZA', 'South Africa', 'Republic of South Africa', 'ZAF', '710', 'yes', '27', '.za');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (206, 'GS', 'South Georgia and the South Sandwich Islands', 'South Georgia and the South Sandwich Islands', 'SGS', '239', 'no', '500', '.gs');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (207, 'KR', 'South Korea', 'Republic of Korea', 'KOR', '410', 'yes', '82', '.kr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (208, 'SS', 'South Sudan', 'Republic of South Sudan', 'SSD', '728', 'yes', '211', '.ss');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (209, 'ES', 'Spain', 'Kingdom of Spain', 'ESP', '724', 'yes', '34', '.es');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (210, 'LK', 'Sri Lanka', 'Democratic Socialist Republic of Sri Lanka', 'LKA', '144', 'yes', '94', '.lk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (211, 'SD', 'Sudan', 'Republic of the Sudan', 'SDN', '729', 'yes', '249', '.sd');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (212, 'SR', 'Suriname', 'Republic of Suriname', 'SUR', '740', 'yes', '597', '.sr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (213, 'SJ', 'Svalbard and Jan Mayen', 'Svalbard and Jan Mayen', 'SJM', '744', 'no', '47', '.sj');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (214, 'SZ', 'Swaziland', 'Kingdom of Swaziland', 'SWZ', '748', 'yes', '268', '.sz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (215, 'SE', 'Sweden', 'Kingdom of Sweden', 'SWE', '752', 'yes', '46', '.se');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (216, 'CH', 'Switzerland', 'Swiss Confederation', 'CHE', '756', 'yes', '41', '.ch');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (217, 'SY', 'Syria', 'Syrian Arab Republic', 'SYR', '760', 'yes', '963', '.sy');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (218, 'TW', 'Taiwan', 'Republic of China (Taiwan)', 'TWN', '158', 'former', '886', '.tw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (219, 'TJ', 'Tajikistan', 'Republic of Tajikistan', 'TJK', '762', 'yes', '992', '.tj');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (220, 'TZ', 'Tanzania', 'United Republic of Tanzania', 'TZA', '834', 'yes', '255', '.tz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (221, 'TH', 'Thailand', 'Kingdom of Thailand', 'THA', '764', 'yes', '66', '.th');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (222, 'TL', 'Timor-Leste (East Timor)', 'Democratic Republic of Timor-Leste', 'TLS', '626', 'yes', '670', '.tl');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (223, 'TG', 'Togo', 'Togolese Republic', 'TGO', '768', 'yes', '228', '.tg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (224, 'TK', 'Tokelau', 'Tokelau', 'TKL', '772', 'no', '690', '.tk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (225, 'TO', 'Tonga', 'Kingdom of Tonga', 'TON', '776', 'yes', '676', '.to');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (226, 'TT', 'Trinidad and Tobago', 'Republic of Trinidad and Tobago', 'TTO', '780', 'yes', '1+868', '.tt');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (227, 'TN', 'Tunisia', 'Republic of Tunisia', 'TUN', '788', 'yes', '216', '.tn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (228, 'TR', 'Turkey', 'Republic of Turkey', 'TUR', '792', 'yes', '90', '.tr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (229, 'TM', 'Turkmenistan', 'Turkmenistan', 'TKM', '795', 'yes', '993', '.tm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (230, 'TC', 'Turks and Caicos Islands', 'Turks and Caicos Islands', 'TCA', '796', 'no', '1+649', '.tc');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (231, 'TV', 'Tuvalu', 'Tuvalu', 'TUV', '798', 'yes', '688', '.tv');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (232, 'UG', 'Uganda', 'Republic of Uganda', 'UGA', '800', 'yes', '256', '.ug');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (233, 'UA', 'Ukraine', 'Ukraine', 'UKR', '804', 'yes', '380', '.ua');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (234, 'AE', 'United Arab Emirates', 'United Arab Emirates', 'ARE', '784', 'yes', '971', '.ae');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (235, 'GB', 'United Kingdom', 'United Kingdom of Great Britain and Nothern Ireland', 'GBR', '826', 'yes', '44', '.uk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (236, 'US', 'United States', 'United States of America', 'USA', '840', 'yes', '1', '.us');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (237, 'UM', 'United States Minor Outlying Islands', 'United States Minor Outlying Islands', 'UMI', '581', 'no', 'NONE', 'NONE');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (238, 'UY', 'Uruguay', 'Eastern Republic of Uruguay', 'URY', '858', 'yes', '598', '.uy');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (239, 'UZ', 'Uzbekistan', 'Republic of Uzbekistan', 'UZB', '860', 'yes', '998', '.uz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (240, 'VU', 'Vanuatu', 'Republic of Vanuatu', 'VUT', '548', 'yes', '678', '.vu');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (241, 'VA', 'Vatican City', 'State of the Vatican City', 'VAT', '336', 'no', '39', '.va');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (242, 'VE', 'Venezuela', 'Bolivarian Republic of Venezuela', 'VEN', '862', 'yes', '58', '.ve');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (243, 'VN', 'Vietnam', 'Socialist Republic of Vietnam', 'VNM', '704', 'yes', '84', '.vn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (244, 'VG', 'Virgin Islands, British', 'British Virgin Islands', 'VGB', '092', 'no', '1+284', '.vg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (245, 'VI', 'Virgin Islands, US', 'Virgin Islands of the United States', 'VIR', '850', 'no', '1+340', '.vi');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (246, 'WF', 'Wallis and Futuna', 'Wallis and Futuna', 'WLF', '876', 'no', '681', '.wf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (247, 'EH', 'Western Sahara', 'Western Sahara', 'ESH', '732', 'no', '212', '.eh');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (248, 'YE', 'Yemen', 'Republic of Yemen', 'YEM', '887', 'yes', '967', '.ye');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (249, 'ZM', 'Zambia', 'Republic of Zambia', 'ZMB', '894', 'yes', '260', '.zm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (250, 'ZW', 'Zimbabwe', 'Republic of Zimbabwe', 'ZWE', '716', 'yes', '263', '.zw');


#
# TABLE STRUCTURE FOR: tblcreditnote_refunds
#

DROP TABLE IF EXISTS `tblcreditnote_refunds`;

CREATE TABLE `tblcreditnote_refunds` (
  `id` int NOT NULL AUTO_INCREMENT,
  `credit_note_id` int NOT NULL,
  `staff_id` int NOT NULL,
  `refunded_on` date NOT NULL,
  `payment_mode` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `amount` decimal(15,2) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblcreditnotes
#

DROP TABLE IF EXISTS `tblcreditnotes`;

CREATE TABLE `tblcreditnotes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `clientid` int NOT NULL,
  `deleted_customer_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `number` int NOT NULL,
  `prefix` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `number_format` int NOT NULL DEFAULT '1',
  `datecreated` datetime NOT NULL,
  `date` date NOT NULL,
  `adminnote` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `terms` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `clientnote` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `currency` int NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT '0.00',
  `total` decimal(15,2) NOT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `addedfrom` int DEFAULT NULL,
  `status` int DEFAULT '1',
  `project_id` int NOT NULL DEFAULT '0',
  `discount_percent` decimal(15,2) DEFAULT '0.00',
  `discount_total` decimal(15,2) DEFAULT '0.00',
  `discount_type` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `billing_street` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_state` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_zip` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_country` int DEFAULT NULL,
  `shipping_street` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_state` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_zip` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_country` int DEFAULT NULL,
  `include_shipping` tinyint(1) NOT NULL,
  `show_shipping_on_credit_note` tinyint(1) NOT NULL DEFAULT '1',
  `show_quantity_as` int NOT NULL DEFAULT '1',
  `reference_no` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `currency` (`currency`),
  KEY `clientid` (`clientid`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblcredits
#

DROP TABLE IF EXISTS `tblcredits`;

CREATE TABLE `tblcredits` (
  `id` int NOT NULL AUTO_INCREMENT,
  `invoice_id` int NOT NULL,
  `credit_id` int NOT NULL,
  `staff_id` int NOT NULL,
  `date` date NOT NULL,
  `date_applied` datetime NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblcurrencies
#

DROP TABLE IF EXISTS `tblcurrencies`;

CREATE TABLE `tblcurrencies` (
  `id` int NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `decimal_separator` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `thousand_separator` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `placement` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isdefault` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tblcurrencies` (`id`, `symbol`, `name`, `decimal_separator`, `thousand_separator`, `placement`, `isdefault`) VALUES (3, 'QAR', 'QAR', '.', ',', 'after', 1);


#
# TABLE STRUCTURE FOR: tblcurrency_rate_logs
#

DROP TABLE IF EXISTS `tblcurrency_rate_logs`;

CREATE TABLE `tblcurrency_rate_logs` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `from_currency_id` int DEFAULT NULL,
  `from_currency_name` varchar(100) DEFAULT NULL,
  `from_currency_rate` decimal(15,6) NOT NULL DEFAULT '0.000000',
  `to_currency_id` int DEFAULT NULL,
  `to_currency_name` varchar(100) DEFAULT NULL,
  `to_currency_rate` decimal(15,6) NOT NULL DEFAULT '0.000000',
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `tblcurrency_rate_logs` (`id`, `from_currency_id`, `from_currency_name`, `from_currency_rate`, `to_currency_id`, `to_currency_name`, `to_currency_rate`, `date`) VALUES (1, 1, 'USD', '0.000000', 3, 'QAR', '3.637300', '2024-08-20');
INSERT INTO `tblcurrency_rate_logs` (`id`, `from_currency_id`, `from_currency_name`, `from_currency_rate`, `to_currency_id`, `to_currency_name`, `to_currency_rate`, `date`) VALUES (2, 3, 'QAR', '0.000000', 1, 'USD', '0.274900', '2024-08-20');
INSERT INTO `tblcurrency_rate_logs` (`id`, `from_currency_id`, `from_currency_name`, `from_currency_rate`, `to_currency_id`, `to_currency_name`, `to_currency_rate`, `date`) VALUES (3, 1, 'USD', '0.000000', 3, 'QAR', '3.637300', '2024-08-20');
INSERT INTO `tblcurrency_rate_logs` (`id`, `from_currency_id`, `from_currency_name`, `from_currency_rate`, `to_currency_id`, `to_currency_name`, `to_currency_rate`, `date`) VALUES (4, 3, 'QAR', '0.000000', 1, 'USD', '0.274900', '2024-08-20');
INSERT INTO `tblcurrency_rate_logs` (`id`, `from_currency_id`, `from_currency_name`, `from_currency_rate`, `to_currency_id`, `to_currency_name`, `to_currency_rate`, `date`) VALUES (5, 1, 'USD', '0.000000', 3, 'QAR', '3.637300', '2024-08-20');
INSERT INTO `tblcurrency_rate_logs` (`id`, `from_currency_id`, `from_currency_name`, `from_currency_rate`, `to_currency_id`, `to_currency_name`, `to_currency_rate`, `date`) VALUES (6, 3, 'QAR', '0.000000', 1, 'USD', '0.274900', '2024-08-20');


#
# TABLE STRUCTURE FOR: tblcurrency_rates
#

DROP TABLE IF EXISTS `tblcurrency_rates`;

CREATE TABLE `tblcurrency_rates` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `from_currency_id` int DEFAULT NULL,
  `from_currency_name` varchar(100) DEFAULT NULL,
  `from_currency_rate` decimal(15,6) NOT NULL DEFAULT '0.000000',
  `to_currency_id` int DEFAULT NULL,
  `to_currency_name` varchar(100) DEFAULT NULL,
  `to_currency_rate` decimal(15,6) NOT NULL DEFAULT '0.000000',
  `date_updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `tblcurrency_rates` (`id`, `from_currency_id`, `from_currency_name`, `from_currency_rate`, `to_currency_id`, `to_currency_name`, `to_currency_rate`, `date_updated`) VALUES (1, 1, 'USD', '1.000000', 3, 'QAR', '3.637300', '2024-08-20 17:44:32');
INSERT INTO `tblcurrency_rates` (`id`, `from_currency_id`, `from_currency_name`, `from_currency_rate`, `to_currency_id`, `to_currency_name`, `to_currency_rate`, `date_updated`) VALUES (2, 3, 'QAR', '1.000000', 1, 'USD', '0.274900', '2024-08-20 17:44:33');


#
# TABLE STRUCTURE FOR: tblcustomer_admins
#

DROP TABLE IF EXISTS `tblcustomer_admins`;

CREATE TABLE `tblcustomer_admins` (
  `staff_id` int NOT NULL,
  `customer_id` int NOT NULL,
  `date_assigned` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  KEY `customer_id` (`customer_id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblcustomer_groups
#

DROP TABLE IF EXISTS `tblcustomer_groups`;

CREATE TABLE `tblcustomer_groups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupid` int NOT NULL,
  `customer_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `groupid` (`groupid`),
  KEY `customer_id` (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tblcustomer_groups` (`id`, `groupid`, `customer_id`) VALUES (1, 2, 3);
INSERT INTO `tblcustomer_groups` (`id`, `groupid`, `customer_id`) VALUES (2, 1, 2);


#
# TABLE STRUCTURE FOR: tblcustomers_groups
#

DROP TABLE IF EXISTS `tblcustomers_groups`;

CREATE TABLE `tblcustomers_groups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tblcustomers_groups` (`id`, `name`) VALUES (2, 'Insurance Customer');
INSERT INTO `tblcustomers_groups` (`id`, `name`) VALUES (1, 'Walk-in Customer');


#
# TABLE STRUCTURE FOR: tblcustomfields
#

DROP TABLE IF EXISTS `tblcustomfields`;

CREATE TABLE `tblcustomfields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldto` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `display_inline` tinyint(1) NOT NULL DEFAULT '0',
  `field_order` int DEFAULT '0',
  `active` int NOT NULL DEFAULT '1',
  `show_on_pdf` int NOT NULL DEFAULT '0',
  `show_on_ticket_form` tinyint(1) NOT NULL DEFAULT '0',
  `only_admin` tinyint(1) NOT NULL DEFAULT '0',
  `show_on_table` tinyint(1) NOT NULL DEFAULT '0',
  `show_on_client_portal` int NOT NULL DEFAULT '0',
  `disalow_client_to_edit` int NOT NULL DEFAULT '0',
  `bs_column` int NOT NULL DEFAULT '12',
  `default_value` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tblcustomfields` (`id`, `fieldto`, `name`, `slug`, `required`, `type`, `options`, `display_inline`, `field_order`, `active`, `show_on_pdf`, `show_on_ticket_form`, `only_admin`, `show_on_table`, `show_on_client_portal`, `disalow_client_to_edit`, `bs_column`, `default_value`) VALUES (1, 'estimate', 'Insurance Number', 'estimate_insurance_number', 1, 'input', '', 0, 0, 1, 1, 0, 0, 1, 0, 0, 12, '');
INSERT INTO `tblcustomfields` (`id`, `fieldto`, `name`, `slug`, `required`, `type`, `options`, `display_inline`, `field_order`, `active`, `show_on_pdf`, `show_on_ticket_form`, `only_admin`, `show_on_table`, `show_on_client_portal`, `disalow_client_to_edit`, `bs_column`, `default_value`) VALUES (2, 'estimate', 'Vehicle Number', 'estimate_vehicle_number', 1, 'number', '', 0, 0, 1, 1, 0, 0, 1, 0, 0, 12, '');
INSERT INTO `tblcustomfields` (`id`, `fieldto`, `name`, `slug`, `required`, `type`, `options`, `display_inline`, `field_order`, `active`, `show_on_pdf`, `show_on_ticket_form`, `only_admin`, `show_on_table`, `show_on_client_portal`, `disalow_client_to_edit`, `bs_column`, `default_value`) VALUES (3, 'estimate', 'Vehicle Model / Year', 'estimate_vehicle_model_year', 0, 'input', '', 0, 0, 1, 1, 0, 0, 1, 0, 0, 12, '');
INSERT INTO `tblcustomfields` (`id`, `fieldto`, `name`, `slug`, `required`, `type`, `options`, `display_inline`, `field_order`, `active`, `show_on_pdf`, `show_on_ticket_form`, `only_admin`, `show_on_table`, `show_on_client_portal`, `disalow_client_to_edit`, `bs_column`, `default_value`) VALUES (4, 'estimate', 'Brand Name', 'estimate_brand_name', 0, 'input', '', 0, 0, 1, 1, 0, 0, 1, 0, 0, 12, '');
INSERT INTO `tblcustomfields` (`id`, `fieldto`, `name`, `slug`, `required`, `type`, `options`, `display_inline`, `field_order`, `active`, `show_on_pdf`, `show_on_ticket_form`, `only_admin`, `show_on_table`, `show_on_client_portal`, `disalow_client_to_edit`, `bs_column`, `default_value`) VALUES (5, 'invoice', 'Insurance Number', 'invoice_insurance_number', 1, 'input', '', 0, 0, 1, 1, 0, 0, 1, 0, 0, 12, '');
INSERT INTO `tblcustomfields` (`id`, `fieldto`, `name`, `slug`, `required`, `type`, `options`, `display_inline`, `field_order`, `active`, `show_on_pdf`, `show_on_ticket_form`, `only_admin`, `show_on_table`, `show_on_client_portal`, `disalow_client_to_edit`, `bs_column`, `default_value`) VALUES (6, 'invoice', 'Vehicle Number', 'invoice_vehicle_number', 1, 'number', '', 0, 0, 1, 1, 0, 0, 1, 0, 0, 12, '');
INSERT INTO `tblcustomfields` (`id`, `fieldto`, `name`, `slug`, `required`, `type`, `options`, `display_inline`, `field_order`, `active`, `show_on_pdf`, `show_on_ticket_form`, `only_admin`, `show_on_table`, `show_on_client_portal`, `disalow_client_to_edit`, `bs_column`, `default_value`) VALUES (7, 'invoice', 'Vehicle Model / Year', 'invoice_vehicle_model_year', 0, 'input', '', 0, 0, 1, 1, 0, 0, 1, 0, 0, 12, '');
INSERT INTO `tblcustomfields` (`id`, `fieldto`, `name`, `slug`, `required`, `type`, `options`, `display_inline`, `field_order`, `active`, `show_on_pdf`, `show_on_ticket_form`, `only_admin`, `show_on_table`, `show_on_client_portal`, `disalow_client_to_edit`, `bs_column`, `default_value`) VALUES (8, 'invoice', 'Brand Name', 'invoice_brand_name', 0, 'input', '', 0, 0, 1, 1, 0, 0, 1, 0, 0, 12, '');


#
# TABLE STRUCTURE FOR: tblcustomfieldsvalues
#

DROP TABLE IF EXISTS `tblcustomfieldsvalues`;

CREATE TABLE `tblcustomfieldsvalues` (
  `id` int NOT NULL AUTO_INCREMENT,
  `relid` int NOT NULL,
  `fieldid` int NOT NULL,
  `fieldto` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `relid` (`relid`),
  KEY `fieldto` (`fieldto`),
  KEY `fieldid` (`fieldid`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tblcustomfieldsvalues` (`id`, `relid`, `fieldid`, `fieldto`, `value`) VALUES (1, 2, 1, 'estimate', '148236');
INSERT INTO `tblcustomfieldsvalues` (`id`, `relid`, `fieldid`, `fieldto`, `value`) VALUES (2, 2, 2, 'estimate', '507573');
INSERT INTO `tblcustomfieldsvalues` (`id`, `relid`, `fieldid`, `fieldto`, `value`) VALUES (3, 2, 3, 'estimate', 'Sunny / 2023');
INSERT INTO `tblcustomfieldsvalues` (`id`, `relid`, `fieldid`, `fieldto`, `value`) VALUES (4, 2, 4, 'estimate', 'Nissan');
INSERT INTO `tblcustomfieldsvalues` (`id`, `relid`, `fieldid`, `fieldto`, `value`) VALUES (5, 3, 1, 'estimate', '456321');
INSERT INTO `tblcustomfieldsvalues` (`id`, `relid`, `fieldid`, `fieldto`, `value`) VALUES (6, 3, 2, 'estimate', '78945');
INSERT INTO `tblcustomfieldsvalues` (`id`, `relid`, `fieldid`, `fieldto`, `value`) VALUES (7, 3, 3, 'estimate', 'Sunny / 2023');
INSERT INTO `tblcustomfieldsvalues` (`id`, `relid`, `fieldid`, `fieldto`, `value`) VALUES (8, 3, 4, 'estimate', 'Nissan');
INSERT INTO `tblcustomfieldsvalues` (`id`, `relid`, `fieldid`, `fieldto`, `value`) VALUES (9, 2, 5, 'invoice', '456321');
INSERT INTO `tblcustomfieldsvalues` (`id`, `relid`, `fieldid`, `fieldto`, `value`) VALUES (10, 2, 6, 'invoice', '78945');
INSERT INTO `tblcustomfieldsvalues` (`id`, `relid`, `fieldid`, `fieldto`, `value`) VALUES (11, 2, 7, 'invoice', 'Sunny / 2023');
INSERT INTO `tblcustomfieldsvalues` (`id`, `relid`, `fieldid`, `fieldto`, `value`) VALUES (12, 2, 8, 'invoice', 'Nissan');
INSERT INTO `tblcustomfieldsvalues` (`id`, `relid`, `fieldid`, `fieldto`, `value`) VALUES (13, 4, 1, 'estimate', '125698');
INSERT INTO `tblcustomfieldsvalues` (`id`, `relid`, `fieldid`, `fieldto`, `value`) VALUES (14, 4, 2, 'estimate', '45689');
INSERT INTO `tblcustomfieldsvalues` (`id`, `relid`, `fieldid`, `fieldto`, `value`) VALUES (15, 4, 3, 'estimate', 'Sunny / 2022');
INSERT INTO `tblcustomfieldsvalues` (`id`, `relid`, `fieldid`, `fieldto`, `value`) VALUES (16, 4, 4, 'estimate', 'Nissan');
INSERT INTO `tblcustomfieldsvalues` (`id`, `relid`, `fieldid`, `fieldto`, `value`) VALUES (17, 5, 1, 'estimate', '12536');
INSERT INTO `tblcustomfieldsvalues` (`id`, `relid`, `fieldid`, `fieldto`, `value`) VALUES (18, 5, 2, 'estimate', '415632');
INSERT INTO `tblcustomfieldsvalues` (`id`, `relid`, `fieldid`, `fieldto`, `value`) VALUES (19, 5, 3, 'estimate', 'Sunny / 2022');
INSERT INTO `tblcustomfieldsvalues` (`id`, `relid`, `fieldid`, `fieldto`, `value`) VALUES (20, 5, 4, 'estimate', 'Nissan');


#
# TABLE STRUCTURE FOR: tbldepartments
#

DROP TABLE IF EXISTS `tbldepartments`;

CREATE TABLE `tbldepartments` (
  `departmentid` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `imap_username` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_from_header` tinyint(1) NOT NULL DEFAULT '0',
  `host` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `encryption` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `folder` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'INBOX',
  `delete_after_import` int NOT NULL DEFAULT '0',
  `calendar_id` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `hidefromclient` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`departmentid`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tbldismissed_announcements
#

DROP TABLE IF EXISTS `tbldismissed_announcements`;

CREATE TABLE `tbldismissed_announcements` (
  `dismissedannouncementid` int NOT NULL AUTO_INCREMENT,
  `announcementid` int NOT NULL,
  `staff` int NOT NULL,
  `userid` int NOT NULL,
  PRIMARY KEY (`dismissedannouncementid`),
  KEY `announcementid` (`announcementid`),
  KEY `staff` (`staff`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblemailtemplates
#

DROP TABLE IF EXISTS `tblemailtemplates`;

CREATE TABLE `tblemailtemplates` (
  `emailtemplateid` int NOT NULL AUTO_INCREMENT,
  `type` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `language` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fromname` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fromemail` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `plaintext` int NOT NULL DEFAULT '0',
  `active` tinyint NOT NULL DEFAULT '0',
  `order` int NOT NULL,
  PRIMARY KEY (`emailtemplateid`)
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (1, 'client', 'new-client-created', 'english', 'New Contact Added/Registered (Welcome Email)', 'Welcome aboard', 'Dear {contact_firstname} {contact_lastname}<br /><br />Thank you for registering on the <strong>{companyname}</strong> CRM System.<br /><br />We just wanted to say welcome.<br /><br />Please contact us if you need any help.<br /><br />Click here to view your profile: <a href=\"{crm_url}\">{crm_url}</a><br /><br />Kind Regards, <br />{email_signature}<br /><br />(This is an automated email, so please don\'t reply to this email address)', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (2, 'invoice', 'invoice-send-to-client', 'english', 'Send Invoice to Customer', 'Invoice with number {invoice_number} created', '<span style=\"font-size: 12pt;\">Dear {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">We have prepared the following invoice for you: <strong># {invoice_number}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Invoice status</strong>: {invoice_status}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (3, 'ticket', 'new-ticket-opened-admin', 'english', 'New Ticket Opened (Opened by Staff, Sent to Customer)', 'New Support Ticket Opened', '<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">New support ticket has been opened.</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject:</strong> {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department:</strong> {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority:</strong> {ticket_priority}<br /></span><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_public_url}\">#{ticket_id}</a><br /><br />Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (4, 'ticket', 'ticket-reply', 'english', 'Ticket Reply (Sent to Customer)', 'New Ticket Reply', '<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">You have a new ticket reply to ticket <a href=\"{ticket_public_url}\">#{ticket_id}</a></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket Subject:</strong> {ticket_subject}<br /></span><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_public_url}\">#{ticket_id}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (5, 'ticket', 'ticket-autoresponse', 'english', 'New Ticket Opened - Autoresponse', 'New Support Ticket Opened', '<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">Thank you for contacting our support team. A support ticket has now been opened for your request. You will be notified when a response is made by email.</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject:</strong> {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority:</strong> {ticket_priority}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_public_url}\">#{ticket_id}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (6, 'invoice', 'invoice-payment-recorded', 'english', 'Invoice Payment Recorded (Sent to Customer)', 'Invoice Payment Recorded', '<span style=\"font-size: 12pt;\">Hello {contact_firstname}&nbsp;{contact_lastname}<br /><br /></span>Thank you for the payment. Find the payment details below:<br /><br />-------------------------------------------------<br /><br />Amount:&nbsp;<strong>{payment_total}<br /></strong>Date:&nbsp;<strong>{payment_date}</strong><br />Invoice number:&nbsp;<span style=\"font-size: 12pt;\"><strong># {invoice_number}<br /><br /></strong></span>-------------------------------------------------<br /><br />You can always view the invoice for this payment at the following link:&nbsp;<a href=\"{invoice_link}\"><span style=\"font-size: 12pt;\">{invoice_number}</span></a><br /><br />We are looking forward working with you.<br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (7, 'invoice', 'invoice-overdue-notice', 'english', 'Invoice Overdue Notice', 'Invoice Overdue Notice - {invoice_number}', '<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">This is an overdue notice for invoice <strong># {invoice_number}</strong></span><br /><br /><span style=\"font-size: 12pt;\">This invoice was due: {invoice_duedate}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (8, 'invoice', 'invoice-already-send', 'english', 'Invoice Already Sent to Customer', 'Invoice # {invoice_number} ', '<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">At your request, here is the invoice with number <strong># {invoice_number}</strong></span><br /><br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (9, 'ticket', 'new-ticket-created-staff', 'english', 'New Ticket Created (Opened by Customer, Sent to Staff Members)', 'New Ticket Created', '<p><span style=\"font-size: 12pt;\">A new support ticket has been opened.</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject</strong>: {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority</strong>: {ticket_priority}<br /></span><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_url}\">#{ticket_id}</a></span><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (10, 'estimate', 'estimate-send-to-client', 'english', 'Send Estimate to Customer', 'Estimate # {estimate_number} created', '<span style=\"font-size: 12pt;\">Dear {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">Please find the attached estimate <strong># {estimate_number}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Estimate status:</strong> {estimate_status}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">We look forward to your communication.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}<br /></span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (11, 'ticket', 'ticket-reply-to-admin', 'english', 'Ticket Reply (Sent to Staff)', 'New Support Ticket Reply', '<span style=\"font-size: 12pt;\">A new support ticket reply from {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject</strong>: {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority</strong>: {ticket_priority}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_url}\">#{ticket_id}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (12, 'estimate', 'estimate-already-send', 'english', 'Estimate Already Sent to Customer', 'Estimate # {estimate_number} ', '<span style=\"font-size: 12pt;\">Dear {contact_firstname} {contact_lastname}</span><br /> <br /><span style=\"font-size: 12pt;\">Thank you for your estimate request.</span><br /> <br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /> <br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /> <br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (13, 'contract', 'contract-expiration', 'english', 'Contract Expiration Reminder (Sent to Customer Contacts)', 'Contract Expiration Reminder', '<span style=\"font-size: 12pt;\">Dear {client_company}</span><br /><br /><span style=\"font-size: 12pt;\">This is a reminder that the following contract will expire soon:</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject:</strong> {contract_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Description:</strong> {contract_description}</span><br /><span style=\"font-size: 12pt;\"><strong>Date Start:</strong> {contract_datestart}</span><br /><span style=\"font-size: 12pt;\"><strong>Date End:</strong> {contract_dateend}</span><br /><br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (14, 'tasks', 'task-assigned', 'english', 'New Task Assigned (Sent to Staff)', 'New Task Assigned to You - {task_name}', '<span style=\"font-size: 12pt;\">Dear {staff_firstname}</span><br /><br /><span style=\"font-size: 12pt;\">You have been assigned to a new task:</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Name:</strong> {task_name}<br /></span><strong>Start Date:</strong> {task_startdate}<br /><span style=\"font-size: 12pt;\"><strong>Due date:</strong> {task_duedate}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority:</strong> {task_priority}<br /><br /></span><span style=\"font-size: 12pt;\"><span>You can view the task on the following link</span>: <a href=\"{task_link}\">{task_name}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (15, 'tasks', 'task-added-as-follower', 'english', 'Staff Member Added as Follower on Task (Sent to Staff)', 'You are added as follower on task - {task_name}', '<span style=\"font-size: 12pt;\">Hi {staff_firstname}<br /></span><br /><span style=\"font-size: 12pt;\">You have been added as follower on the following task:</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Name:</strong> {task_name}</span><br /><span style=\"font-size: 12pt;\"><strong>Start date:</strong> {task_startdate}</span><br /><br /><span>You can view the task on the following link</span><span>: </span><a href=\"{task_link}\">{task_name}</a><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (16, 'tasks', 'task-commented', 'english', 'New Comment on Task (Sent to Staff)', 'New Comment on Task - {task_name}', 'Dear {staff_firstname}<br /><br />A comment has been made on the following task:<br /><br /><strong>Name:</strong> {task_name}<br /><strong>Comment:</strong> {task_comment}<br /><br />You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a><br /><br />Kind Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (17, 'tasks', 'task-added-attachment', 'english', 'New Attachment(s) on Task (Sent to Staff)', 'New Attachment on Task - {task_name}', 'Hi {staff_firstname}<br /><br /><strong>{task_user_take_action}</strong> added an attachment on the following task:<br /><br /><strong>Name:</strong> {task_name}<br /><br />You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a><br /><br />Kind Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (18, 'estimate', 'estimate-declined-to-staff', 'english', 'Estimate Declined (Sent to Staff)', 'Customer Declined Estimate', '<span style=\"font-size: 12pt;\">Hi</span><br /> <br /><span style=\"font-size: 12pt;\">Customer ({client_company}) declined estimate with number <strong># {estimate_number}</strong></span><br /> <br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /> <br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (19, 'estimate', 'estimate-accepted-to-staff', 'english', 'Estimate Accepted (Sent to Staff)', 'Customer Accepted Estimate', '<span style=\"font-size: 12pt;\">Hi</span><br /> <br /><span style=\"font-size: 12pt;\">Customer ({client_company}) accepted estimate with number <strong># {estimate_number}</strong></span><br /> <br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /> <br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (20, 'proposals', 'proposal-client-accepted', 'english', 'Customer Action - Accepted (Sent to Staff)', 'Customer Accepted Proposal', '<div>Hi<br /> <br />Client <strong>{proposal_proposal_to}</strong> accepted the following proposal:<br /> <br /><strong>Number:</strong> {proposal_number}<br /><strong>Subject</strong>: {proposal_subject}<br /><strong>Total</strong>: {proposal_total}<br /> <br />View the proposal on the following link: <a href=\"{proposal_link}\">{proposal_number}</a><br /> <br />Kind Regards,<br />{email_signature}</div>\r\n<div>&nbsp;</div>\r\n<div>&nbsp;</div>\r\n<div>&nbsp;</div>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (21, 'proposals', 'proposal-send-to-customer', 'english', 'Send Proposal to Customer', 'Proposal With Number {proposal_number} Created', 'Dear {proposal_proposal_to}<br /><br />Please find our attached proposal.<br /><br />This proposal is valid until: {proposal_open_till}<br />You can view the proposal on the following link: <a href=\"{proposal_link}\">{proposal_number}</a><br /><br />Please don\'t hesitate to comment online if you have any questions.<br /><br />We look forward to your communication.<br /><br />Kind Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (22, 'proposals', 'proposal-client-declined', 'english', 'Customer Action - Declined (Sent to Staff)', 'Client Declined Proposal', 'Hi<br /> <br />Customer <strong>{proposal_proposal_to}</strong> declined the proposal <strong>{proposal_subject}</strong><br /> <br />View the proposal on the following link <a href=\"{proposal_link}\">{proposal_number}</a>&nbsp;or from the admin area.<br /> <br />Kind Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (23, 'proposals', 'proposal-client-thank-you', 'english', 'Thank You Email (Sent to Customer After Accept)', 'Thank for you accepting proposal', 'Dear {proposal_proposal_to}<br /> <br />Thank for for accepting the proposal.<br /> <br />We look forward to doing business with you.<br /> <br />We will contact you as soon as possible<br /> <br />Kind Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (24, 'proposals', 'proposal-comment-to-client', 'english', 'New Comment  (Sent to Customer/Lead)', 'New Proposal Comment', 'Dear {proposal_proposal_to}<br /> <br />A new comment has been made on the following proposal: <strong>{proposal_number}</strong><br /> <br />You can view and reply to the comment on the following link: <a href=\"{proposal_link}\">{proposal_number}</a><br /> <br />Kind Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (25, 'proposals', 'proposal-comment-to-admin', 'english', 'New Comment (Sent to Staff) ', 'New Proposal Comment', 'Hi<br /> <br />A new comment has been made to the proposal <strong>{proposal_subject}</strong><br /> <br />You can view and reply to the comment on the following link: <a href=\"{proposal_link}\">{proposal_number}</a>&nbsp;or from the admin area.<br /> <br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (26, 'estimate', 'estimate-thank-you-to-customer', 'english', 'Thank You Email (Sent to Customer After Accept)', 'Thank for you accepting estimate', '<span style=\"font-size: 12pt;\">Dear {contact_firstname} {contact_lastname}</span><br /> <br /><span style=\"font-size: 12pt;\">Thank for for accepting the estimate.</span><br /> <br /><span style=\"font-size: 12pt;\">We look forward to doing business with you.</span><br /> <br /><span style=\"font-size: 12pt;\">We will contact you as soon as possible.</span><br /> <br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (27, 'tasks', 'task-deadline-notification', 'english', 'Task Deadline Reminder - Sent to Assigned Members', 'Task Deadline Reminder', 'Hi {staff_firstname}&nbsp;{staff_lastname}<br /><br />This is an automated email from {companyname}.<br /><br />The task <strong>{task_name}</strong> deadline is on <strong>{task_duedate}</strong>. <br />This task is still not finished.<br /><br />You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a><br /><br />Kind Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (28, 'contract', 'send-contract', 'english', 'Send Contract to Customer', 'Contract - {contract_subject}', '<p><span style=\"font-size: 12pt;\">Hi&nbsp;{contact_firstname}&nbsp;{contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">Please find the <a href=\"{contract_link}\">{contract_subject}</a> attached.<br /><br />Description: {contract_description}<br /><br /></span><span style=\"font-size: 12pt;\">Looking forward to hear from you.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (29, 'invoice', 'invoice-payment-recorded-to-staff', 'english', 'Invoice Payment Recorded (Sent to Staff)', 'New Invoice Payment', '<span style=\"font-size: 12pt;\">Hi</span><br /><br /><span style=\"font-size: 12pt;\">Customer recorded payment for invoice <strong># {invoice_number}</strong></span><br /> <br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /> <br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (30, 'ticket', 'auto-close-ticket', 'english', 'Auto Close Ticket', 'Ticket Auto Closed', '<p><span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">Ticket {ticket_subject} has been auto close due to inactivity.</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket #</strong>: <a href=\"{ticket_public_url}\">{ticket_id}</a></span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority:</strong> {ticket_priority}</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (31, 'project', 'new-project-discussion-created-to-staff', 'english', 'New Project Discussion (Sent to Project Members)', 'New Project Discussion Created - {project_name}', '<p>Hi {staff_firstname}<br /><br />New project discussion created from <strong>{discussion_creator}</strong><br /><br /><strong>Subject:</strong> {discussion_subject}<br /><strong>Description:</strong> {discussion_description}<br /><br />You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a><br /><br />Kind Regards,<br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (32, 'project', 'new-project-discussion-created-to-customer', 'english', 'New Project Discussion (Sent to Customer Contacts)', 'New Project Discussion Created - {project_name}', '<p>Hello {contact_firstname} {contact_lastname}<br /><br />New project discussion created from <strong>{discussion_creator}</strong><br /><br /><strong>Subject:</strong> {discussion_subject}<br /><strong>Description:</strong> {discussion_description}<br /><br />You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a><br /><br />Kind Regards,<br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (33, 'project', 'new-project-file-uploaded-to-customer', 'english', 'New Project File(s) Uploaded (Sent to Customer Contacts)', 'New Project File(s) Uploaded - {project_name}', '<p>Hello {contact_firstname} {contact_lastname}<br /><br />New project file is uploaded on <strong>{project_name}</strong> from <strong>{file_creator}</strong><br /><br />You can view the project on the following link: <a href=\"{project_link}\">{project_name}</a><br /><br />To view the file in our CRM you can click on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a><br /><br />Kind Regards,<br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (34, 'project', 'new-project-file-uploaded-to-staff', 'english', 'New Project File(s) Uploaded (Sent to Project Members)', 'New Project File(s) Uploaded - {project_name}', '<p>Hello&nbsp;{staff_firstname}</p>\r\n<p>New project&nbsp;file is uploaded on&nbsp;<strong>{project_name}</strong> from&nbsp;<strong>{file_creator}</strong></p>\r\n<p>You can view the project on the following link: <a href=\"{project_link}\">{project_name}<br /></a><br />To view&nbsp;the file you can click on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a></p>\r\n<p>Kind Regards,<br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (35, 'project', 'new-project-discussion-comment-to-customer', 'english', 'New Discussion Comment  (Sent to Customer Contacts)', 'New Discussion Comment', '<p><span style=\"font-size: 12pt;\">Hello {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">New discussion comment has been made on <strong>{discussion_subject}</strong> from <strong>{comment_creator}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Discussion subject:</strong> {discussion_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Comment</strong>: {discussion_comment}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (36, 'project', 'new-project-discussion-comment-to-staff', 'english', 'New Discussion Comment (Sent to Project Members)', 'New Discussion Comment', '<p>Hi {staff_firstname}<br /><br />New discussion comment has been made on <strong>{discussion_subject}</strong> from <strong>{comment_creator}</strong><br /><br /><strong>Discussion subject:</strong> {discussion_subject}<br /><strong>Comment:</strong> {discussion_comment}<br /><br />You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a><br /><br />Kind Regards,<br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (37, 'project', 'staff-added-as-project-member', 'english', 'Staff Added as Project Member', 'New project assigned to you', '<p>Hi {staff_firstname}<br /><br />New project has been assigned to you.<br /><br />You can view the project on the following link <a href=\"{project_link}\">{project_name}</a><br /><br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (38, 'estimate', 'estimate-expiry-reminder', 'english', 'Estimate Expiration Reminder', 'Estimate Expiration Reminder', '<p><span style=\"font-size: 12pt;\">Hello {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">The estimate with <strong># {estimate_number}</strong> will expire on <strong>{estimate_expirydate}</strong></span><br /><br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (39, 'proposals', 'proposal-expiry-reminder', 'english', 'Proposal Expiration Reminder', 'Proposal Expiration Reminder', '<p>Hello {proposal_proposal_to}<br /><br />The proposal {proposal_number}&nbsp;will expire on <strong>{proposal_open_till}</strong><br /><br />You can view the proposal on the following link: <a href=\"{proposal_link}\">{proposal_number}</a><br /><br />Kind Regards,<br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (40, 'staff', 'new-staff-created', 'english', 'New Staff Created (Welcome Email)', 'You are added as staff member', 'Hi {staff_firstname}<br /><br />You are added as member on our CRM.<br /><br />Please use the following logic credentials:<br /><br /><strong>Email:</strong> {staff_email}<br /><strong>Password:</strong> {password}<br /><br />Click <a href=\"{admin_url}\">here </a>to login in the dashboard.<br /><br />Best Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (41, 'client', 'contact-forgot-password', 'english', 'Forgot Password', 'Create New Password', '<h2>Create a new password</h2>\r\nForgot your password?<br /> To create a new password, just follow this link:<br /> <br /><a href=\"{reset_password_url}\">Reset Password</a><br /> <br /> You received this email, because it was requested by a {companyname}&nbsp;user. This is part of the procedure to create a new password on the system. If you DID NOT request a new password then please ignore this email and your password will remain the same. <br /><br /> {email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (42, 'client', 'contact-password-reseted', 'english', 'Password Reset - Confirmation', 'Your password has been changed', '<strong><span style=\"font-size: 14pt;\">You have changed your password.</span><br /></strong><br /> Please, keep it in your records so you don\'t forget it.<br /> <br /> Your email address for login is: {contact_email}<br /><br />If this wasnt you, please contact us.<br /><br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (43, 'client', 'contact-set-password', 'english', 'Set New Password', 'Set new password on {companyname} ', '<h2><span style=\"font-size: 14pt;\">Setup your new password on {companyname}</span></h2>\r\nPlease use the following link to set up your new password:<br /><br /><a href=\"{set_password_url}\">Set new password</a><br /><br />Keep it in your records so you don\'t forget it.<br /><br />Please set your new password in <strong>48 hours</strong>. After that, you won\'t be able to set your password because this link will expire.<br /><br />You can login at: <a href=\"{crm_url}\">{crm_url}</a><br />Your email address for login: {contact_email}<br /><br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (44, 'staff', 'staff-forgot-password', 'english', 'Forgot Password', 'Create New Password', '<h2><span style=\"font-size: 14pt;\">Create a new password</span></h2>\r\nForgot your password?<br /> To create a new password, just follow this link:<br /> <br /><a href=\"{reset_password_url}\">Reset Password</a><br /> <br /> You received this email, because it was requested by a <strong>{companyname}</strong>&nbsp;user. This is part of the procedure to create a new password on the system. If you DID NOT request a new password then please ignore this email and your password will remain the same. <br /><br /> {email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (45, 'staff', 'staff-password-reseted', 'english', 'Password Reset - Confirmation', 'Your password has been changed', '<span style=\"font-size: 14pt;\"><strong>You have changed your password.<br /></strong></span><br /> Please, keep it in your records so you don\'t forget it.<br /> <br /> Your email address for login is: {staff_email}<br /><br /> If this wasnt you, please contact us.<br /><br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (46, 'project', 'assigned-to-project', 'english', 'New Project Created (Sent to Customer Contacts)', 'New Project Created', '<p>Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}</p>\r\n<p>New project is assigned to your company.<br /><br /><strong>Project Name:</strong>&nbsp;{project_name}<br /><strong>Project Start Date:</strong>&nbsp;{project_start_date}</p>\r\n<p>You can view the project on the following link:&nbsp;<a href=\"{project_link}\">{project_name}</a></p>\r\n<p>We are looking forward hearing from you.<br /><br />Kind Regards,<br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (47, 'tasks', 'task-added-attachment-to-contacts', 'english', 'New Attachment(s) on Task (Sent to Customer Contacts)', 'New Attachment on Task - {task_name}', '<span>Hi {contact_firstname} {contact_lastname}</span><br /><br /><strong>{task_user_take_action}</strong><span> added an attachment on the following task:</span><br /><br /><strong>Name:</strong><span> {task_name}</span><br /><br /><span>You can view the task on the following link: </span><a href=\"{task_link}\">{task_name}</a><br /><br /><span>Kind Regards,</span><br /><span>{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (48, 'tasks', 'task-commented-to-contacts', 'english', 'New Comment on Task (Sent to Customer Contacts)', 'New Comment on Task - {task_name}', '<span>Dear {contact_firstname} {contact_lastname}</span><br /><br /><span>A comment has been made on the following task:</span><br /><br /><strong>Name:</strong><span> {task_name}</span><br /><strong>Comment:</strong><span> {task_comment}</span><br /><br /><span>You can view the task on the following link: </span><a href=\"{task_link}\">{task_name}</a><br /><br /><span>Kind Regards,</span><br /><span>{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (49, 'leads', 'new-lead-assigned', 'english', 'New Lead Assigned to Staff Member', 'New lead assigned to you', '<p>Hello {lead_assigned}<br /><br />New lead is assigned to you.<br /><br /><strong>Lead Name:</strong>&nbsp;{lead_name}<br /><strong>Lead Email:</strong>&nbsp;{lead_email}<br /><br />You can view the lead on the following link: <a href=\"{lead_link}\">{lead_name}</a><br /><br />Kind Regards,<br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (50, 'client', 'client-statement', 'english', 'Statement - Account Summary', 'Account Statement from {statement_from} to {statement_to}', 'Dear {contact_firstname} {contact_lastname}, <br /><br />Its been a great experience working with you.<br /><br />Attached with this email is a list of all transactions for the period between {statement_from} to {statement_to}<br /><br />For your information your account balance due is total:&nbsp;{statement_balance_due}<br /><br />Please contact us if you need more information.<br /> <br />Kind Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (51, 'ticket', 'ticket-assigned-to-admin', 'english', 'New Ticket Assigned (Sent to Staff)', 'New support ticket has been assigned to you', '<p><span style=\"font-size: 12pt;\">Hi</span></p>\r\n<p><span style=\"font-size: 12pt;\">A new support ticket&nbsp;has been assigned to you.</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject</strong>: {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority</strong>: {ticket_priority}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_url}\">#{ticket_id}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (52, 'client', 'new-client-registered-to-admin', 'english', 'New Customer Registration (Sent to admins)', 'New Customer Registration', 'Hello.<br /><br />New customer registration on your customer portal:<br /><br /><strong>Firstname:</strong>&nbsp;{contact_firstname}<br /><strong>Lastname:</strong>&nbsp;{contact_lastname}<br /><strong>Company:</strong>&nbsp;{client_company}<br /><strong>Email:</strong>&nbsp;{contact_email}<br /><br />Best Regards', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (53, 'leads', 'new-web-to-lead-form-submitted', 'english', 'Web to lead form submitted - Sent to lead', '{lead_name} - We Received Your Request', 'Hello {lead_name}.<br /><br /><strong>Your request has been received.</strong><br /><br />This email is to let you know that we received your request and we will get back to you as soon as possible with more information.<br /><br />Best Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 0, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (54, 'staff', 'two-factor-authentication', 'english', 'Two Factor Authentication', 'Confirm Your Login', '<p>Hi {staff_firstname}</p>\r\n<p style=\"text-align: left;\">You received this email because you have enabled two factor authentication in your account.<br />Use the following code to confirm your login:</p>\r\n<p style=\"text-align: left;\"><span style=\"font-size: 18pt;\"><strong>{two_factor_auth_code}<br /><br /></strong><span style=\"font-size: 12pt;\">{email_signature}</span><strong><br /><br /><br /><br /></strong></span></p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (55, 'project', 'project-finished-to-customer', 'english', 'Project Marked as Finished (Sent to Customer Contacts)', 'Project Marked as Finished', '<p>Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}</p>\r\n<p>You are receiving this email because project&nbsp;<strong>{project_name}</strong> has been marked as finished. This project is assigned under your company and we just wanted to keep you up to date.<br /><br />You can view the project on the following link:&nbsp;<a href=\"{project_link}\">{project_name}</a></p>\r\n<p>If you have any questions don\'t hesitate to contact us.<br /><br />Kind Regards,<br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (56, 'credit_note', 'credit-note-send-to-client', 'english', 'Send Credit Note To Email', 'Credit Note With Number #{credit_note_number} Created', 'Dear&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br />We have attached the credit note with number <strong>#{credit_note_number} </strong>for your reference.<br /><br /><strong>Date:</strong>&nbsp;{credit_note_date}<br /><strong>Total Amount:</strong>&nbsp;{credit_note_total}<br /><br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /> <br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (57, 'tasks', 'task-status-change-to-staff', 'english', 'Task Status Changed (Sent to Staff)', 'Task Status Changed', '<span style=\"font-size: 12pt;\">Hi {staff_firstname}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>{task_user_take_action}</strong> marked task as <strong>{task_status}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Name:</strong> {task_name}</span><br /><span style=\"font-size: 12pt;\"><strong>Due date:</strong> {task_duedate}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (58, 'tasks', 'task-status-change-to-contacts', 'english', 'Task Status Changed (Sent to Customer Contacts)', 'Task Status Changed', '<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>{task_user_take_action}</strong> marked task as <strong>{task_status}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Name:</strong> {task_name}</span><br /><span style=\"font-size: 12pt;\"><strong>Due date:</strong> {task_duedate}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (59, 'staff', 'reminder-email-staff', 'english', 'Staff Reminder Email', 'You Have a New Reminder!', '<p>Hello&nbsp;{staff_firstname}<br /><br /><strong>You have a new reminder&nbsp;linked to&nbsp;{staff_reminder_relation_name}!<br /><br />Reminder description:</strong><br />{staff_reminder_description}<br /><br />Click <a href=\"{staff_reminder_relation_link}\">here</a> to view&nbsp;<a href=\"{staff_reminder_relation_link}\">{staff_reminder_relation_name}</a><br /><br />Best Regards<br /><br /></p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (60, 'contract', 'contract-comment-to-client', 'english', 'New Comment  (Sent to Customer Contacts)', 'New Contract Comment', 'Dear {contact_firstname} {contact_lastname}<br /> <br />A new comment has been made on the following contract: <strong>{contract_subject}</strong><br /> <br />You can view and reply to the comment on the following link: <a href=\"{contract_link}\">{contract_subject}</a><br /> <br />Kind Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (61, 'contract', 'contract-comment-to-admin', 'english', 'New Comment (Sent to Staff) ', 'New Contract Comment', 'Hi {staff_firstname}<br /><br />A new comment has been made to the contract&nbsp;<strong>{contract_subject}</strong><br /><br />You can view and reply to the comment on the following link: <a href=\"{contract_link}\">{contract_subject}</a>&nbsp;or from the admin area.<br /><br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (62, 'subscriptions', 'send-subscription', 'english', 'Send Subscription to Customer', 'Subscription Created', 'Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br />We have prepared the subscription&nbsp;<strong>{subscription_name}</strong> for your company.<br /><br />Click <a href=\"{subscription_link}\">here</a> to review the subscription and subscribe.<br /><br />Best Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (63, 'subscriptions', 'subscription-payment-failed', 'english', 'Subscription Payment Failed', 'Your most recent invoice payment failed', 'Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br br=\"\" />Unfortunately, your most recent invoice payment for&nbsp;<strong>{subscription_name}</strong> was declined.<br /><br />This could be due to a change in your card number, your card expiring,<br />cancellation of your credit card, or the card issuer not recognizing the<br />payment and therefore taking action to prevent it.<br /><br />Please update your payment information as soon as possible by logging in here:<br /><a href=\"{crm_url}/login\">{crm_url}/login</a><br /><br />Best Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (64, 'subscriptions', 'subscription-canceled', 'english', 'Subscription Canceled (Sent to customer primary contact)', 'Your subscription has been canceled', 'Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br />Your subscription&nbsp;<strong>{subscription_name} </strong>has been canceled, if you have any questions don\'t hesitate to contact us.<br /><br />It was a pleasure doing business with you.<br /><br />Best Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (65, 'subscriptions', 'subscription-payment-succeeded', 'english', 'Subscription Payment Succeeded (Sent to customer primary contact)', 'Subscription  Payment Receipt - {subscription_name}', 'Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br />This email is to let you know that we received your payment for subscription&nbsp;<strong>{subscription_name}&nbsp;</strong>of&nbsp;<strong><span>{payment_total}<br /><br /></span></strong>The invoice associated with it is now with status&nbsp;<strong>{invoice_status}<br /></strong><br />Thank you for your confidence.<br /><br />Best Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (66, 'contract', 'contract-expiration-to-staff', 'english', 'Contract Expiration Reminder (Sent to Staff)', 'Contract Expiration Reminder', 'Hi {staff_firstname}<br /><br /><span style=\"font-size: 12pt;\">This is a reminder that the following contract will expire soon:</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject:</strong> {contract_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Description:</strong> {contract_description}</span><br /><span style=\"font-size: 12pt;\"><strong>Date Start:</strong> {contract_datestart}</span><br /><span style=\"font-size: 12pt;\"><strong>Date End:</strong> {contract_dateend}</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (67, 'gdpr', 'gdpr-removal-request', 'english', 'Removal Request From Contact (Sent to administrators)', 'Data Removal Request Received', 'Hello&nbsp;{staff_firstname}&nbsp;{staff_lastname}<br /><br />Data removal has been requested by&nbsp;{contact_firstname} {contact_lastname}<br /><br />You can review this request and take proper actions directly from the admin area.', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (68, 'gdpr', 'gdpr-removal-request-lead', 'english', 'Removal Request From Lead (Sent to administrators)', 'Data Removal Request Received', 'Hello&nbsp;{staff_firstname}&nbsp;{staff_lastname}<br /><br />Data removal has been requested by {lead_name}<br /><br />You can review this request and take proper actions directly from the admin area.<br /><br />To view the lead inside the admin area click here:&nbsp;<a href=\"{lead_link}\">{lead_link}</a>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (69, 'client', 'client-registration-confirmed', 'english', 'Customer Registration Confirmed', 'Your registration is confirmed', '<p>Dear {contact_firstname} {contact_lastname}<br /><br />We just wanted to let you know that your registration at&nbsp;{companyname} is successfully confirmed and your account is now active.<br /><br />You can login at&nbsp;<a href=\"{crm_url}\">{crm_url}</a> with the email and password you provided during registration.<br /><br />Please contact us if you need any help.<br /><br />Kind Regards, <br />{email_signature}</p>\r\n<p><br />(This is an automated email, so please don\'t reply to this email address)</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (70, 'contract', 'contract-signed-to-staff', 'english', 'Contract Signed (Sent to Staff)', 'Customer Signed a Contract', 'Hi {staff_firstname}<br /><br />A contract with subject&nbsp;<strong>{contract_subject} </strong>has been successfully signed by the customer.<br /><br />You can view the contract at the following link: <a href=\"{contract_link}\">{contract_subject}</a>&nbsp;or from the admin area.<br /><br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (71, 'subscriptions', 'customer-subscribed-to-staff', 'english', 'Customer Subscribed to a Subscription (Sent to administrators and subscription creator)', 'Customer Subscribed to a Subscription', 'The customer <strong>{client_company}</strong> subscribed to a subscription with name&nbsp;<strong>{subscription_name}</strong><br /><br /><strong>ID</strong>:&nbsp;{subscription_id}<br /><strong>Subscription name</strong>:&nbsp;{subscription_name}<br /><strong>Subscription description</strong>:&nbsp;{subscription_description}<br /><br />You can view the subscription by clicking <a href=\"{subscription_link}\">here</a><br />\r\n<div style=\"text-align: center;\"><span style=\"font-size: 10pt;\">&nbsp;</span></div>\r\nBest Regards,<br />{email_signature}<br /><br /><span style=\"font-size: 10pt;\"><span style=\"color: #999999;\">You are receiving this email because you are either administrator or you are creator of the subscription.</span></span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (72, 'client', 'contact-verification-email', 'english', 'Email Verification (Sent to Contact After Registration)', 'Verify Email Address', '<p>Hello&nbsp;{contact_firstname}<br /><br />Please click the button below to verify your email address.<br /><br /><a href=\"{email_verification_url}\">Verify Email Address</a><br /><br />If you did not create an account, no further action is required</p>\r\n<p><br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (73, 'client', 'new-customer-profile-file-uploaded-to-staff', 'english', 'New Customer Profile File(s) Uploaded (Sent to Staff)', 'Customer Uploaded New File(s) in Profile', 'Hi!<br /><br />New file(s) is uploaded into the customer ({client_company}) profile by&nbsp;{contact_firstname}<br /><br />You can check the uploaded files into the admin area by clicking <a href=\"{customer_profile_files_admin_link}\">here</a> or at the following link:&nbsp;{customer_profile_files_admin_link}<br /><br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (74, 'staff', 'event-notification-to-staff', 'english', 'Event Notification (Calendar)', 'Upcoming Event - {event_title}', 'Hi {staff_firstname}! <br /><br />This is a reminder for event <a href=\\\"{event_link}\\\">{event_title}</a> scheduled at {event_start_date}. <br /><br />Regards.', '', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (75, 'subscriptions', 'subscription-payment-requires-action', 'english', 'Credit Card Authorization Required - SCA', 'Important: Confirm your subscription {subscription_name} payment', '<p>Hello {contact_firstname}</p>\r\n<p><strong>Your bank sometimes requires an additional step to make sure an online transaction was authorized.</strong><br /><br />Because of European regulation to protect consumers, many online payments now require two-factor authentication. Your bank ultimately decides when authentication is required to confirm a payment, but you may notice this step when you start paying for a service or when the cost changes.<br /><br />In order to pay the subscription <strong>{subscription_name}</strong>, you will need to&nbsp;confirm your payment by clicking on the follow link: <strong><a href=\"{subscription_authorize_payment_link}\">{subscription_authorize_payment_link}</a></strong><br /><br />To view the subscription, please click at the following link: <a href=\"{subscription_link}\"><span>{subscription_link}</span></a><br />or you can login in our dedicated area here: <a href=\"{crm_url}/login\">{crm_url}/login</a> in case you want to update your credit card or view the subscriptions you are subscribed.<br /><br />Best Regards,<br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (76, 'invoice', 'invoice-due-notice', 'english', 'Invoice Due Notice', 'Your {invoice_number} will be due soon', '<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}<br /><br /></span>You invoice <span style=\"font-size: 12pt;\"><strong># {invoice_number} </strong>will be due on <strong>{invoice_duedate}</strong></span><br /><br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (77, 'estimate_request', 'estimate-request-submitted-to-staff', 'english', 'Estimate Request Submitted (Sent to Staff)', 'New Estimate Request Submitted', '<span> Hello,&nbsp;</span><br /><br />{estimate_request_email} submitted an estimate request via the {estimate_request_form_name} form.<br /><br />You can view the request at the following link: <a href=\"{estimate_request_link}\">{estimate_request_link}</a><br /><br />==<br /><br />{estimate_request_submitted_data}<br /><br />Kind Regards,<br /><span>{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (78, 'estimate_request', 'estimate-request-assigned', 'english', 'Estimate Request Assigned (Sent to Staff)', 'New Estimate Request Assigned', '<span> Hello {estimate_request_assigned},&nbsp;</span><br /><br />Estimate request #{estimate_request_id} has been assigned to you.<br /><br />You can view the request at the following link: <a href=\"{estimate_request_link}\">{estimate_request_link}</a><br /><br />Kind Regards,<br /><span>{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (79, 'estimate_request', 'estimate-request-received-to-user', 'english', 'Estimate Request Received (Sent to User)', 'Estimate Request Received', 'Hello,<br /><br /><strong>Your request has been received.</strong><br /><br />This email is to let you know that we received your request and we will get back to you as soon as possible with more information.<br /><br />Best Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 0, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (80, 'notifications', 'non-billed-tasks-reminder', 'english', 'Non-billed tasks reminder (sent to selected staff members)', 'Action required: Completed tasks are not billed', 'Hello {staff_firstname}<br><br>The following tasks are marked as complete but not yet billed:<br><br>{unbilled_tasks_list}<br><br>Kind Regards,<br><br>{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (81, 'invoice', 'invoices-batch-payments', 'english', 'Invoices Payments Recorded in Batch (Sent to Customer)', 'We have received your payments', 'Hello {contact_firstname} {contact_lastname}<br><br>Thank you for the payments. Please find the payments details below:<br><br>{batch_payments_list}<br><br>We are looking forward working with you.<br><br>Kind Regards,<br><br>{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (82, 'contract', 'contract-sign-reminder', 'english', 'Contract Sign Reminder (Sent to Customer)', 'Contract Sign Reminder', '<p>Hello {contact_firstname} {contact_lastname}<br /><br />This is a reminder to review and sign the contract:<a href=\"{contract_link}\">{contract_subject}</a></p><p>You can view and sign by visiting: <a href=\"{contract_link}\">{contract_subject}</a></p><p><br />We are looking forward working with you.<br /><br />Kind Regards,<br /><br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);


#
# TABLE STRUCTURE FOR: tblestimate_request_forms
#

DROP TABLE IF EXISTS `tblestimate_request_forms`;

CREATE TABLE `tblestimate_request_forms` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `form_key` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `form_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `recaptcha` int DEFAULT NULL,
  `status` int NOT NULL,
  `submit_btn_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `submit_btn_bg_color` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '#84c529',
  `submit_btn_text_color` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '#ffffff',
  `success_submit_msg` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `submit_action` int DEFAULT '0',
  `submit_redirect_url` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `language` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dateadded` datetime DEFAULT NULL,
  `notify_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notify_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `responsible` int DEFAULT NULL,
  `notify_request_submitted` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tblestimate_request_forms` (`id`, `form_key`, `type`, `name`, `form_data`, `recaptcha`, `status`, `submit_btn_name`, `submit_btn_bg_color`, `submit_btn_text_color`, `success_submit_msg`, `submit_action`, `submit_redirect_url`, `language`, `dateadded`, `notify_type`, `notify_ids`, `responsible`, `notify_request_submitted`) VALUES (1, 'ce356405a9ee47e5230cbf7cd3aa2f53', '', 'Mohammed ', NULL, NULL, 2, 'Submit', '#84c529', '#ffffff', 'hi', 0, '', 'english', '2024-08-20 16:53:12', 'specific_staff', 'a:0:{}', 1, 1);


#
# TABLE STRUCTURE FOR: tblestimate_request_status
#

DROP TABLE IF EXISTS `tblestimate_request_status`;

CREATE TABLE `tblestimate_request_status` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `statusorder` int DEFAULT NULL,
  `color` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `flag` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tblestimate_request_status` (`id`, `name`, `statusorder`, `color`, `flag`) VALUES (1, 'Cancelled', 1, '#808080', 'cancelled');
INSERT INTO `tblestimate_request_status` (`id`, `name`, `statusorder`, `color`, `flag`) VALUES (2, 'Processing', 2, '#007bff', 'processing');
INSERT INTO `tblestimate_request_status` (`id`, `name`, `statusorder`, `color`, `flag`) VALUES (3, 'Completed', 3, '#28a745', 'completed');


#
# TABLE STRUCTURE FOR: tblestimate_requests
#

DROP TABLE IF EXISTS `tblestimate_requests`;

CREATE TABLE `tblestimate_requests` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `submission` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_status_change` datetime DEFAULT NULL,
  `date_estimated` datetime DEFAULT NULL,
  `from_form_id` int DEFAULT NULL,
  `assigned` int DEFAULT NULL,
  `status` int DEFAULT NULL,
  `default_language` int NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblestimates
#

DROP TABLE IF EXISTS `tblestimates`;

CREATE TABLE `tblestimates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sent` tinyint(1) NOT NULL DEFAULT '0',
  `datesend` datetime DEFAULT NULL,
  `clientid` int NOT NULL,
  `deleted_customer_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `project_id` int NOT NULL DEFAULT '0',
  `number` int NOT NULL,
  `prefix` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `number_format` int NOT NULL DEFAULT '0',
  `hash` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `date` date NOT NULL,
  `expirydate` date DEFAULT NULL,
  `currency` int NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT '0.00',
  `total` decimal(15,2) NOT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `addedfrom` int NOT NULL,
  `status` int NOT NULL DEFAULT '1',
  `clientnote` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `adminnote` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `discount_percent` decimal(15,2) DEFAULT '0.00',
  `discount_total` decimal(15,2) DEFAULT '0.00',
  `discount_type` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoiceid` int DEFAULT NULL,
  `invoiced_date` datetime DEFAULT NULL,
  `terms` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `reference_no` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sale_agent` int NOT NULL DEFAULT '0',
  `billing_street` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_state` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_zip` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_country` int DEFAULT NULL,
  `shipping_street` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_state` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_zip` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_country` int DEFAULT NULL,
  `include_shipping` tinyint(1) NOT NULL,
  `show_shipping_on_estimate` tinyint(1) NOT NULL DEFAULT '1',
  `show_quantity_as` int NOT NULL DEFAULT '1',
  `pipeline_order` int DEFAULT '1',
  `is_expiry_notified` int NOT NULL DEFAULT '0',
  `acceptance_firstname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `acceptance_lastname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `acceptance_email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_ip` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `signature` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `short_link` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `currency` (`currency`),
  KEY `project_id` (`project_id`),
  KEY `sale_agent` (`sale_agent`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tblestimates` (`id`, `sent`, `datesend`, `clientid`, `deleted_customer_name`, `project_id`, `number`, `prefix`, `number_format`, `hash`, `datecreated`, `date`, `expirydate`, `currency`, `subtotal`, `total_tax`, `total`, `adjustment`, `addedfrom`, `status`, `clientnote`, `adminnote`, `discount_percent`, `discount_total`, `discount_type`, `invoiceid`, `invoiced_date`, `terms`, `reference_no`, `sale_agent`, `billing_street`, `billing_city`, `billing_state`, `billing_zip`, `billing_country`, `shipping_street`, `shipping_city`, `shipping_state`, `shipping_zip`, `shipping_country`, `include_shipping`, `show_shipping_on_estimate`, `show_quantity_as`, `pipeline_order`, `is_expiry_notified`, `acceptance_firstname`, `acceptance_lastname`, `acceptance_email`, `acceptance_date`, `acceptance_ip`, `signature`, `short_link`) VALUES (2, 0, NULL, 3, NULL, 0, 1, 'EST-', 1, '675e31ee68e6364e6ec5e0568d097314', '2024-08-20 19:40:35', '2024-08-20', '2024-08-27', 3, '1450.00', '0.00', '1400.00', '0.00', 1, 1, '', '', '0.00', '50.00', 'before_tax', NULL, NULL, 'Terms and Conditions:<br />\r\n• The above product and services mentioned are covered in this quotation.<br />\r\n• This quotation excl udes civil works.<br />\r\n• Any additional items or services will be invoiced separately.<br />\r\nPayment Term:<br />\r\n• 50% Advanced and 50% Upon project / Services completion or Product Delivered<br />\r\n• Payment is due from the delivery of the Product/Services.<br />\r\n• The payment options available are as agreed upon, including Cash, Cheque, and Online Bank<br />\r\nTransfer.<br />\r\n<br />\r\n<br />\r\n<br />\r\nService Advisor -------------------------------                                                                                  Customer Sign------------------------------------', 'QIC Insurance', 1, '', '', '', '', 0, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblestimates` (`id`, `sent`, `datesend`, `clientid`, `deleted_customer_name`, `project_id`, `number`, `prefix`, `number_format`, `hash`, `datecreated`, `date`, `expirydate`, `currency`, `subtotal`, `total_tax`, `total`, `adjustment`, `addedfrom`, `status`, `clientnote`, `adminnote`, `discount_percent`, `discount_total`, `discount_type`, `invoiceid`, `invoiced_date`, `terms`, `reference_no`, `sale_agent`, `billing_street`, `billing_city`, `billing_state`, `billing_zip`, `billing_country`, `shipping_street`, `shipping_city`, `shipping_state`, `shipping_zip`, `shipping_country`, `include_shipping`, `show_shipping_on_estimate`, `show_quantity_as`, `pipeline_order`, `is_expiry_notified`, `acceptance_firstname`, `acceptance_lastname`, `acceptance_email`, `acceptance_date`, `acceptance_ip`, `signature`, `short_link`) VALUES (3, 0, NULL, 3, NULL, 0, 2, 'Job-', 2, 'add5bc682d5f99c318c8c8aa231ee724', '2024-08-21 10:45:07', '2024-08-21', '2024-08-28', 3, '3060.00', '0.00', '3010.00', '0.00', 1, 4, '', '', '0.00', '50.00', 'after_tax', 2, '2024-08-21 10:49:34', '• The above product and services mentioned are covered in this quotation.<br />\r\n• This quotation excl udes civil works.<br />\r\n• Any additional items or services will be invoiced separately.<br />\r\nPayment Term:<br />\r\n• 50% Advanced and 50% Upon project / Services completion or Product Delivered<br />\r\n• Payment is due from the delivery of the Product/Services.<br />\r\n• The payment options available are as agreed upon, including Cash, Cheque, and Online Bank<br />\r\nTransfer.', 'QIC Insurance', 1, '', '', '', '', 0, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblestimates` (`id`, `sent`, `datesend`, `clientid`, `deleted_customer_name`, `project_id`, `number`, `prefix`, `number_format`, `hash`, `datecreated`, `date`, `expirydate`, `currency`, `subtotal`, `total_tax`, `total`, `adjustment`, `addedfrom`, `status`, `clientnote`, `adminnote`, `discount_percent`, `discount_total`, `discount_type`, `invoiceid`, `invoiced_date`, `terms`, `reference_no`, `sale_agent`, `billing_street`, `billing_city`, `billing_state`, `billing_zip`, `billing_country`, `shipping_street`, `shipping_city`, `shipping_state`, `shipping_zip`, `shipping_country`, `include_shipping`, `show_shipping_on_estimate`, `show_quantity_as`, `pipeline_order`, `is_expiry_notified`, `acceptance_firstname`, `acceptance_lastname`, `acceptance_email`, `acceptance_date`, `acceptance_ip`, `signature`, `short_link`) VALUES (4, 0, NULL, 2, NULL, 0, 3, 'Job-', 2, 'aaf29630d12ea7827ec178ddd04d426d', '2024-08-21 11:59:13', '2024-08-21', '2024-08-28', 3, '200.00', '0.00', '150.00', '0.00', 1, 1, '', '', '0.00', '50.00', 'before_tax', NULL, NULL, '', 'QIC Insurance', 1, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblestimates` (`id`, `sent`, `datesend`, `clientid`, `deleted_customer_name`, `project_id`, `number`, `prefix`, `number_format`, `hash`, `datecreated`, `date`, `expirydate`, `currency`, `subtotal`, `total_tax`, `total`, `adjustment`, `addedfrom`, `status`, `clientnote`, `adminnote`, `discount_percent`, `discount_total`, `discount_type`, `invoiceid`, `invoiced_date`, `terms`, `reference_no`, `sale_agent`, `billing_street`, `billing_city`, `billing_state`, `billing_zip`, `billing_country`, `shipping_street`, `shipping_city`, `shipping_state`, `shipping_zip`, `shipping_country`, `include_shipping`, `show_shipping_on_estimate`, `show_quantity_as`, `pipeline_order`, `is_expiry_notified`, `acceptance_firstname`, `acceptance_lastname`, `acceptance_email`, `acceptance_date`, `acceptance_ip`, `signature`, `short_link`) VALUES (5, 0, NULL, 3, NULL, 0, 4, 'Job-', 2, '752aa77ec34a60c2a4b66f8f3ebbad39', '2024-08-21 12:04:04', '2024-08-21', '2024-08-28', 3, '400.00', '0.00', '400.00', '0.00', 1, 1, '', '', '0.00', '0.00', '', NULL, NULL, '', 'QIC Insurance', 1, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: tblevents
#

DROP TABLE IF EXISTS `tblevents`;

CREATE TABLE `tblevents` (
  `eventid` int NOT NULL AUTO_INCREMENT,
  `title` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `userid` int NOT NULL,
  `start` datetime NOT NULL,
  `end` datetime DEFAULT NULL,
  `public` int NOT NULL DEFAULT '0',
  `color` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isstartnotified` tinyint(1) NOT NULL DEFAULT '0',
  `reminder_before` int NOT NULL DEFAULT '0',
  `reminder_before_type` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`eventid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblexpenses
#

DROP TABLE IF EXISTS `tblexpenses`;

CREATE TABLE `tblexpenses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category` int NOT NULL,
  `currency` int NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `tax` int DEFAULT NULL,
  `tax2` int NOT NULL DEFAULT '0',
  `reference_no` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `expense_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `clientid` int NOT NULL,
  `project_id` int NOT NULL DEFAULT '0',
  `billable` int DEFAULT '0',
  `invoiceid` int DEFAULT NULL,
  `paymentmode` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` date NOT NULL,
  `recurring_type` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `repeat_every` int DEFAULT NULL,
  `recurring` int NOT NULL DEFAULT '0',
  `cycles` int NOT NULL DEFAULT '0',
  `total_cycles` int NOT NULL DEFAULT '0',
  `custom_recurring` int NOT NULL DEFAULT '0',
  `last_recurring_date` date DEFAULT NULL,
  `create_invoice_billable` tinyint(1) DEFAULT NULL,
  `send_invoice_to_customer` tinyint(1) NOT NULL,
  `recurring_from` int DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `addedfrom` int NOT NULL,
  `vendor` int DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `date_paid` date DEFAULT NULL,
  `status` int DEFAULT NULL,
  `is_bill` int NOT NULL DEFAULT '0',
  `reason_for_void` text COLLATE utf8mb4_unicode_ci,
  `voided` int NOT NULL DEFAULT '0',
  `approved` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `project_id` (`project_id`),
  KEY `category` (`category`),
  KEY `currency` (`currency`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblexpenses_categories
#

DROP TABLE IF EXISTS `tblexpenses_categories`;

CREATE TABLE `tblexpenses_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tblexpenses_categories` (`id`, `name`, `description`) VALUES (1, 'Salary', '');
INSERT INTO `tblexpenses_categories` (`id`, `name`, `description`) VALUES (2, 'Paint Material', '');
INSERT INTO `tblexpenses_categories` (`id`, `name`, `description`) VALUES (3, 'Office Accessories', '');
INSERT INTO `tblexpenses_categories` (`id`, `name`, `description`) VALUES (4, 'Garage Rent', '');
INSERT INTO `tblexpenses_categories` (`id`, `name`, `description`) VALUES (5, 'Employee QID Renewal', '');
INSERT INTO `tblexpenses_categories` (`id`, `name`, `description`) VALUES (6, 'Kahramaa Bill', '');
INSERT INTO `tblexpenses_categories` (`id`, `name`, `description`) VALUES (7, 'Telephone and Mobile', '');
INSERT INTO `tblexpenses_categories` (`id`, `name`, `description`) VALUES (8, 'Fuel', '');
INSERT INTO `tblexpenses_categories` (`id`, `name`, `description`) VALUES (9, 'Commission', '');
INSERT INTO `tblexpenses_categories` (`id`, `name`, `description`) VALUES (10, 'Garage Tools', '');
INSERT INTO `tblexpenses_categories` (`id`, `name`, `description`) VALUES (11, 'Garage Maintenance', '');
INSERT INTO `tblexpenses_categories` (`id`, `name`, `description`) VALUES (12, 'Others', '');


#
# TABLE STRUCTURE FOR: tblfiles
#

DROP TABLE IF EXISTS `tblfiles`;

CREATE TABLE `tblfiles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `rel_id` int NOT NULL,
  `rel_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `filetype` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `visible_to_customer` int NOT NULL DEFAULT '0',
  `attachment_key` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `external` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `external_link` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `thumbnail_link` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'For external usage',
  `staffid` int NOT NULL,
  `contact_id` int DEFAULT '0',
  `task_comment_id` int NOT NULL DEFAULT '0',
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblfilter_defaults
#

DROP TABLE IF EXISTS `tblfilter_defaults`;

CREATE TABLE `tblfilter_defaults` (
  `filter_id` int unsigned NOT NULL,
  `staff_id` int NOT NULL,
  `identifier` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `view` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  KEY `filter_id` (`filter_id`),
  KEY `staff_id` (`staff_id`),
  CONSTRAINT `tblfilter_defaults_ibfk_1` FOREIGN KEY (`filter_id`) REFERENCES `tblfilters` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tblfilter_defaults_ibfk_2` FOREIGN KEY (`staff_id`) REFERENCES `tblstaff` (`staffid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblfilters
#

DROP TABLE IF EXISTS `tblfilters`;

CREATE TABLE `tblfilters` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `builder` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `staff_id` int unsigned NOT NULL,
  `identifier` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_shared` tinyint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblform_question_box
#

DROP TABLE IF EXISTS `tblform_question_box`;

CREATE TABLE `tblform_question_box` (
  `boxid` int NOT NULL AUTO_INCREMENT,
  `boxtype` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `questionid` int NOT NULL,
  PRIMARY KEY (`boxid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblform_question_box_description
#

DROP TABLE IF EXISTS `tblform_question_box_description`;

CREATE TABLE `tblform_question_box_description` (
  `questionboxdescriptionid` int NOT NULL AUTO_INCREMENT,
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `boxid` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `questionid` int NOT NULL,
  PRIMARY KEY (`questionboxdescriptionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblform_questions
#

DROP TABLE IF EXISTS `tblform_questions`;

CREATE TABLE `tblform_questions` (
  `questionid` int NOT NULL AUTO_INCREMENT,
  `rel_id` int NOT NULL,
  `rel_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `question` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `question_order` int NOT NULL,
  PRIMARY KEY (`questionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblform_results
#

DROP TABLE IF EXISTS `tblform_results`;

CREATE TABLE `tblform_results` (
  `resultid` int NOT NULL AUTO_INCREMENT,
  `boxid` int NOT NULL,
  `boxdescriptionid` int DEFAULT NULL,
  `rel_id` int NOT NULL,
  `rel_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `questionid` int NOT NULL,
  `answer` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `resultsetid` int NOT NULL,
  PRIMARY KEY (`resultid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblgdpr_requests
#

DROP TABLE IF EXISTS `tblgdpr_requests`;

CREATE TABLE `tblgdpr_requests` (
  `id` int NOT NULL AUTO_INCREMENT,
  `clientid` int NOT NULL DEFAULT '0',
  `contact_id` int NOT NULL DEFAULT '0',
  `lead_id` int NOT NULL DEFAULT '0',
  `request_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request_date` datetime NOT NULL,
  `request_from` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblinvoicepaymentrecords
#

DROP TABLE IF EXISTS `tblinvoicepaymentrecords`;

CREATE TABLE `tblinvoicepaymentrecords` (
  `id` int NOT NULL AUTO_INCREMENT,
  `invoiceid` int NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `paymentmode` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paymentmethod` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` date NOT NULL,
  `daterecorded` datetime NOT NULL,
  `note` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `transactionid` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `invoiceid` (`invoiceid`),
  KEY `paymentmethod` (`paymentmethod`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tblinvoicepaymentrecords` (`id`, `invoiceid`, `amount`, `paymentmode`, `paymentmethod`, `date`, `daterecorded`, `note`, `transactionid`) VALUES (2, 2, '1000.00', '2', NULL, '2024-08-21', '2024-08-21 10:52:41', '', '');
INSERT INTO `tblinvoicepaymentrecords` (`id`, `invoiceid`, `amount`, `paymentmode`, `paymentmethod`, `date`, `daterecorded`, `note`, `transactionid`) VALUES (3, 2, '500.00', '2', NULL, '2024-08-21', '2024-08-21 12:22:40', 'Balance Due Amount', '');


#
# TABLE STRUCTURE FOR: tblinvoices
#

DROP TABLE IF EXISTS `tblinvoices`;

CREATE TABLE `tblinvoices` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sent` tinyint(1) NOT NULL DEFAULT '0',
  `datesend` datetime DEFAULT NULL,
  `clientid` int NOT NULL,
  `deleted_customer_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `number` int NOT NULL,
  `prefix` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `number_format` int NOT NULL DEFAULT '0',
  `datecreated` datetime NOT NULL,
  `date` date NOT NULL,
  `duedate` date DEFAULT NULL,
  `currency` int NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT '0.00',
  `total` decimal(15,2) NOT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `addedfrom` int DEFAULT NULL,
  `hash` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int DEFAULT '1',
  `clientnote` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `adminnote` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `last_overdue_reminder` date DEFAULT NULL,
  `last_due_reminder` date DEFAULT NULL,
  `cancel_overdue_reminders` int NOT NULL DEFAULT '0',
  `allowed_payment_modes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `token` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `discount_percent` decimal(15,2) DEFAULT '0.00',
  `discount_total` decimal(15,2) DEFAULT '0.00',
  `discount_type` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `recurring` int NOT NULL DEFAULT '0',
  `recurring_type` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_recurring` tinyint(1) NOT NULL DEFAULT '0',
  `cycles` int NOT NULL DEFAULT '0',
  `total_cycles` int NOT NULL DEFAULT '0',
  `is_recurring_from` int DEFAULT NULL,
  `last_recurring_date` date DEFAULT NULL,
  `terms` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `sale_agent` int NOT NULL DEFAULT '0',
  `billing_street` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_state` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_zip` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_country` int DEFAULT NULL,
  `shipping_street` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_state` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_zip` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_country` int DEFAULT NULL,
  `include_shipping` tinyint(1) NOT NULL,
  `show_shipping_on_invoice` tinyint(1) NOT NULL DEFAULT '1',
  `show_quantity_as` int NOT NULL DEFAULT '1',
  `project_id` int DEFAULT '0',
  `subscription_id` int NOT NULL DEFAULT '0',
  `short_link` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `currency` (`currency`),
  KEY `clientid` (`clientid`),
  KEY `project_id` (`project_id`),
  KEY `sale_agent` (`sale_agent`),
  KEY `total` (`total`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tblinvoices` (`id`, `sent`, `datesend`, `clientid`, `deleted_customer_name`, `number`, `prefix`, `number_format`, `datecreated`, `date`, `duedate`, `currency`, `subtotal`, `total_tax`, `total`, `adjustment`, `addedfrom`, `hash`, `status`, `clientnote`, `adminnote`, `last_overdue_reminder`, `last_due_reminder`, `cancel_overdue_reminders`, `allowed_payment_modes`, `token`, `discount_percent`, `discount_total`, `discount_type`, `recurring`, `recurring_type`, `custom_recurring`, `cycles`, `total_cycles`, `is_recurring_from`, `last_recurring_date`, `terms`, `sale_agent`, `billing_street`, `billing_city`, `billing_state`, `billing_zip`, `billing_country`, `shipping_street`, `shipping_city`, `shipping_state`, `shipping_zip`, `shipping_country`, `include_shipping`, `show_shipping_on_invoice`, `show_quantity_as`, `project_id`, `subscription_id`, `short_link`) VALUES (2, 0, NULL, 3, NULL, 1, 'INV-', 2, '2024-08-21 10:49:33', '2024-08-21', '2024-09-20', 3, '2800.00', '0.00', '2750.00', '0.00', 1, 'a21c22a946c5817eeec538c60ef30066', 3, '', '', NULL, NULL, 0, 'a:3:{i:0;s:1:\"1\";i:1;s:1:\"2\";i:2;s:1:\"3\";}', NULL, '0.00', '50.00', 'after_tax', 0, NULL, 0, 0, 0, NULL, NULL, '', 1, '', '', '', '', 0, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, 0, 0, NULL);


#
# TABLE STRUCTURE FOR: tblitem_tax
#

DROP TABLE IF EXISTS `tblitem_tax`;

CREATE TABLE `tblitem_tax` (
  `id` int NOT NULL AUTO_INCREMENT,
  `itemid` int NOT NULL,
  `rel_id` int NOT NULL,
  `rel_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `taxrate` decimal(15,2) NOT NULL,
  `taxname` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `itemid` (`itemid`),
  KEY `rel_id` (`rel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblitemable
#

DROP TABLE IF EXISTS `tblitemable`;

CREATE TABLE `tblitemable` (
  `id` int NOT NULL AUTO_INCREMENT,
  `rel_id` int NOT NULL,
  `rel_type` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `long_description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `qty` decimal(15,2) NOT NULL,
  `rate` decimal(15,2) NOT NULL,
  `unit` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `item_order` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `qty` (`qty`),
  KEY `rate` (`rate`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tblitemable` (`id`, `rel_id`, `rel_type`, `description`, `long_description`, `qty`, `rate`, `unit`, `item_order`) VALUES (10, 2, 'estimate', 'Break', 'Change', '1.00', '200.00', '', 1);
INSERT INTO `tblitemable` (`id`, `rel_id`, `rel_type`, `description`, `long_description`, `qty`, `rate`, `unit`, `item_order`) VALUES (11, 2, 'estimate', 'Light', 'Change', '2.00', '500.00', '', 2);
INSERT INTO `tblitemable` (`id`, `rel_id`, `rel_type`, `description`, `long_description`, `qty`, `rate`, `unit`, `item_order`) VALUES (12, 2, 'estimate', 'Door', 'Repair', '1.00', '250.00', '', 3);
INSERT INTO `tblitemable` (`id`, `rel_id`, `rel_type`, `description`, `long_description`, `qty`, `rate`, `unit`, `item_order`) VALUES (13, 3, 'estimate', 'Head Light', 'Change', '2.00', '500.00', '', 1);
INSERT INTO `tblitemable` (`id`, `rel_id`, `rel_type`, `description`, `long_description`, `qty`, `rate`, `unit`, `item_order`) VALUES (14, 3, 'estimate', 'Door Right Side', 'Repair', '1.00', '500.00', '', 2);
INSERT INTO `tblitemable` (`id`, `rel_id`, `rel_type`, `description`, `long_description`, `qty`, `rate`, `unit`, `item_order`) VALUES (15, 3, 'estimate', 'Break', 'Change', '2.00', '400.00', '', 3);
INSERT INTO `tblitemable` (`id`, `rel_id`, `rel_type`, `description`, `long_description`, `qty`, `rate`, `unit`, `item_order`) VALUES (16, 3, 'estimate', 'Labor Charge', '', '1.00', '500.00', '', 4);
INSERT INTO `tblitemable` (`id`, `rel_id`, `rel_type`, `description`, `long_description`, `qty`, `rate`, `unit`, `item_order`) VALUES (17, 2, 'invoice', 'Head Light', 'Change', '2.00', '500.00', '', 1);
INSERT INTO `tblitemable` (`id`, `rel_id`, `rel_type`, `description`, `long_description`, `qty`, `rate`, `unit`, `item_order`) VALUES (18, 2, 'invoice', 'Door Right Side', 'Repair', '1.00', '500.00', '', 2);
INSERT INTO `tblitemable` (`id`, `rel_id`, `rel_type`, `description`, `long_description`, `qty`, `rate`, `unit`, `item_order`) VALUES (19, 2, 'invoice', 'Break', 'Change', '2.00', '400.00', '', 3);
INSERT INTO `tblitemable` (`id`, `rel_id`, `rel_type`, `description`, `long_description`, `qty`, `rate`, `unit`, `item_order`) VALUES (20, 2, 'invoice', 'Labor Charge', '', '1.00', '500.00', '', 4);
INSERT INTO `tblitemable` (`id`, `rel_id`, `rel_type`, `description`, `long_description`, `qty`, `rate`, `unit`, `item_order`) VALUES (21, 3, 'estimate', 'Tyre', '', '2.00', '130.00', '', 5);
INSERT INTO `tblitemable` (`id`, `rel_id`, `rel_type`, `description`, `long_description`, `qty`, `rate`, `unit`, `item_order`) VALUES (22, 4, 'estimate', 'tyre', '', '1.00', '200.00', '', 1);
INSERT INTO `tblitemable` (`id`, `rel_id`, `rel_type`, `description`, `long_description`, `qty`, `rate`, `unit`, `item_order`) VALUES (23, 5, 'estimate', 'glass', '', '1.00', '400.00', '', 1);


#
# TABLE STRUCTURE FOR: tblitems
#

DROP TABLE IF EXISTS `tblitems`;

CREATE TABLE `tblitems` (
  `id` int NOT NULL AUTO_INCREMENT,
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `long_description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `rate` decimal(15,2) NOT NULL,
  `tax` int DEFAULT NULL,
  `tax2` int DEFAULT NULL,
  `unit` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `group_id` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `tax` (`tax`),
  KEY `tax2` (`tax2`),
  KEY `group_id` (`group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tblitems` (`id`, `description`, `long_description`, `rate`, `tax`, `tax2`, `unit`, `group_id`) VALUES (1, 'Computer', '- i5\r\n-256hdd', '2000.00', NULL, NULL, '1', 0);
INSERT INTO `tblitems` (`id`, `description`, `long_description`, `rate`, `tax`, `tax2`, `unit`, `group_id`) VALUES (2, 'Laptop', '-i7\r\n-SSD', '2500.00', NULL, NULL, '2', 0);
INSERT INTO `tblitems` (`id`, `description`, `long_description`, `rate`, `tax`, `tax2`, `unit`, `group_id`) VALUES (3, 'Laptop', '', '2011.00', NULL, NULL, '2', 0);


#
# TABLE STRUCTURE FOR: tblitems_groups
#

DROP TABLE IF EXISTS `tblitems_groups`;

CREATE TABLE `tblitems_groups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblknowedge_base_article_feedback
#

DROP TABLE IF EXISTS `tblknowedge_base_article_feedback`;

CREATE TABLE `tblknowedge_base_article_feedback` (
  `articleanswerid` int NOT NULL AUTO_INCREMENT,
  `articleid` int NOT NULL,
  `answer` int NOT NULL,
  `ip` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`articleanswerid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblknowledge_base
#

DROP TABLE IF EXISTS `tblknowledge_base`;

CREATE TABLE `tblknowledge_base` (
  `articleid` int NOT NULL AUTO_INCREMENT,
  `articlegroup` int NOT NULL,
  `subject` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint NOT NULL,
  `datecreated` datetime NOT NULL,
  `article_order` int NOT NULL DEFAULT '0',
  `staff_article` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`articleid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblknowledge_base_groups
#

DROP TABLE IF EXISTS `tblknowledge_base_groups`;

CREATE TABLE `tblknowledge_base_groups` (
  `groupid` int NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `group_slug` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `active` tinyint NOT NULL,
  `color` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '#28B8DA',
  `group_order` int DEFAULT '0',
  PRIMARY KEY (`groupid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tbllead_activity_log
#

DROP TABLE IF EXISTS `tbllead_activity_log`;

CREATE TABLE `tbllead_activity_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `leadid` int NOT NULL,
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `additional_data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `date` datetime NOT NULL,
  `staffid` int NOT NULL,
  `full_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_activity` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tbllead_integration_emails
#

DROP TABLE IF EXISTS `tbllead_integration_emails`;

CREATE TABLE `tbllead_integration_emails` (
  `id` int NOT NULL AUTO_INCREMENT,
  `subject` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `body` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `dateadded` datetime NOT NULL,
  `leadid` int NOT NULL,
  `emailid` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblleads
#

DROP TABLE IF EXISTS `tblleads`;

CREATE TABLE `tblleads` (
  `id` int NOT NULL AUTO_INCREMENT,
  `hash` varchar(65) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `country` int NOT NULL DEFAULT '0',
  `zip` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned` int NOT NULL DEFAULT '0',
  `dateadded` datetime NOT NULL,
  `from_form_id` int NOT NULL DEFAULT '0',
  `status` int NOT NULL,
  `source` int NOT NULL,
  `lastcontact` datetime DEFAULT NULL,
  `dateassigned` date DEFAULT NULL,
  `last_status_change` datetime DEFAULT NULL,
  `addedfrom` int NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `leadorder` int DEFAULT '1',
  `phonenumber` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_converted` datetime DEFAULT NULL,
  `lost` tinyint(1) NOT NULL DEFAULT '0',
  `junk` int NOT NULL DEFAULT '0',
  `last_lead_status` int NOT NULL DEFAULT '0',
  `is_imported_from_email_integration` tinyint(1) NOT NULL DEFAULT '0',
  `email_integration_uid` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT '0',
  `default_language` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `client_id` int NOT NULL DEFAULT '0',
  `lead_value` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `company` (`company`),
  KEY `email` (`email`),
  KEY `assigned` (`assigned`),
  KEY `status` (`status`),
  KEY `source` (`source`),
  KEY `lastcontact` (`lastcontact`),
  KEY `dateadded` (`dateadded`),
  KEY `leadorder` (`leadorder`),
  KEY `from_form_id` (`from_form_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblleads_email_integration
#

DROP TABLE IF EXISTS `tblleads_email_integration`;

CREATE TABLE `tblleads_email_integration` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'the ID always must be 1',
  `active` int NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `imap_server` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `check_every` int NOT NULL DEFAULT '5',
  `responsible` int NOT NULL,
  `lead_source` int NOT NULL,
  `lead_status` int NOT NULL,
  `encryption` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `folder` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_run` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notify_lead_imported` tinyint(1) NOT NULL DEFAULT '1',
  `notify_lead_contact_more_times` tinyint(1) NOT NULL DEFAULT '1',
  `notify_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notify_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `mark_public` int NOT NULL DEFAULT '0',
  `only_loop_on_unseen_emails` tinyint(1) NOT NULL DEFAULT '1',
  `delete_after_import` int NOT NULL DEFAULT '0',
  `create_task_if_customer` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tblleads_email_integration` (`id`, `active`, `email`, `imap_server`, `password`, `check_every`, `responsible`, `lead_source`, `lead_status`, `encryption`, `folder`, `last_run`, `notify_lead_imported`, `notify_lead_contact_more_times`, `notify_type`, `notify_ids`, `mark_public`, `only_loop_on_unseen_emails`, `delete_after_import`, `create_task_if_customer`) VALUES (1, 0, '', '', '', 10, 0, 0, 0, 'tls', 'INBOX', '', 1, 1, 'assigned', '', 0, 1, 0, 1);


#
# TABLE STRUCTURE FOR: tblleads_sources
#

DROP TABLE IF EXISTS `tblleads_sources`;

CREATE TABLE `tblleads_sources` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tblleads_sources` (`id`, `name`) VALUES (2, 'Facebook');
INSERT INTO `tblleads_sources` (`id`, `name`) VALUES (1, 'Google');


#
# TABLE STRUCTURE FOR: tblleads_status
#

DROP TABLE IF EXISTS `tblleads_status`;

CREATE TABLE `tblleads_status` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `statusorder` int DEFAULT NULL,
  `color` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '#28B8DA',
  `isdefault` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tblleads_status` (`id`, `name`, `statusorder`, `color`, `isdefault`) VALUES (1, 'Customer', 1000, '#7cb342', 1);


#
# TABLE STRUCTURE FOR: tblmail_queue
#

DROP TABLE IF EXISTS `tblmail_queue`;

CREATE TABLE `tblmail_queue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `engine` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cc` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `bcc` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `message` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `alt_message` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` enum('pending','sending','sent','failed') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `headers` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `attachments` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblmigrations
#

DROP TABLE IF EXISTS `tblmigrations`;

CREATE TABLE `tblmigrations` (
  `version` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tblmigrations` (`version`) VALUES ('316');


#
# TABLE STRUCTURE FOR: tblmilestones
#

DROP TABLE IF EXISTS `tblmilestones`;

CREATE TABLE `tblmilestones` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `description_visible_to_customer` tinyint(1) DEFAULT '0',
  `start_date` date DEFAULT NULL,
  `due_date` date NOT NULL,
  `project_id` int NOT NULL,
  `color` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `milestone_order` int NOT NULL DEFAULT '0',
  `datecreated` date NOT NULL,
  `hide_from_customer` int DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblmodules
#

DROP TABLE IF EXISTS `tblmodules`;

CREATE TABLE `tblmodules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `module_name` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `installed_version` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tblmodules` (`id`, `module_name`, `installed_version`, `active`) VALUES (1, 'accounting', '1.3.4', 1);
INSERT INTO `tblmodules` (`id`, `module_name`, `installed_version`, `active`) VALUES (2, 'backup', '2.3.0', 1);
INSERT INTO `tblmodules` (`id`, `module_name`, `installed_version`, `active`) VALUES (3, 'exports', '1.0.0', 1);
INSERT INTO `tblmodules` (`id`, `module_name`, `installed_version`, `active`) VALUES (4, 'menu_setup', '2.3.0', 1);
INSERT INTO `tblmodules` (`id`, `module_name`, `installed_version`, `active`) VALUES (5, 'theme_style', '2.3.0', 1);


#
# TABLE STRUCTURE FOR: tblnewsfeed_comment_likes
#

DROP TABLE IF EXISTS `tblnewsfeed_comment_likes`;

CREATE TABLE `tblnewsfeed_comment_likes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `postid` int NOT NULL,
  `commentid` int NOT NULL,
  `userid` int NOT NULL,
  `dateliked` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblnewsfeed_post_comments
#

DROP TABLE IF EXISTS `tblnewsfeed_post_comments`;

CREATE TABLE `tblnewsfeed_post_comments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `content` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `userid` int NOT NULL,
  `postid` int NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblnewsfeed_post_likes
#

DROP TABLE IF EXISTS `tblnewsfeed_post_likes`;

CREATE TABLE `tblnewsfeed_post_likes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `postid` int NOT NULL,
  `userid` int NOT NULL,
  `dateliked` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblnewsfeed_posts
#

DROP TABLE IF EXISTS `tblnewsfeed_posts`;

CREATE TABLE `tblnewsfeed_posts` (
  `postid` int NOT NULL AUTO_INCREMENT,
  `creator` int NOT NULL,
  `datecreated` datetime NOT NULL,
  `visibility` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinned` int NOT NULL,
  `datepinned` datetime DEFAULT NULL,
  PRIMARY KEY (`postid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblnotes
#

DROP TABLE IF EXISTS `tblnotes`;

CREATE TABLE `tblnotes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `rel_id` int NOT NULL,
  `rel_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `date_contacted` datetime DEFAULT NULL,
  `addedfrom` int NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblnotifications
#

DROP TABLE IF EXISTS `tblnotifications`;

CREATE TABLE `tblnotifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `isread` int NOT NULL DEFAULT '0',
  `isread_inline` tinyint(1) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fromuserid` int NOT NULL,
  `fromclientid` int NOT NULL DEFAULT '0',
  `from_fullname` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `touserid` int NOT NULL,
  `fromcompany` int DEFAULT NULL,
  `link` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `additional_data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tblnotifications` (`id`, `isread`, `isread_inline`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES (1, 1, 1, '2024-08-20 16:21:53', 'not_proposal_proposal_accepted', 0, 0, '', 1, 1, 'proposals/list_proposals/1', 'a:1:{i:0;s:10:\"PRO-000001\";}');


#
# TABLE STRUCTURE FOR: tbloptions
#

DROP TABLE IF EXISTS `tbloptions`;

CREATE TABLE `tbloptions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=608 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (1, 'dateformat', 'd/m/Y|%d/%m/%Y', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (2, 'companyname', 'Al Raed Automobile Services', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (3, 'services', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (4, 'maximum_allowed_ticket_attachments', '4', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (5, 'ticket_attachments_file_extensions', '.jpg,.png,.pdf,.doc,.zip,.rar', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (6, 'staff_access_only_assigned_departments', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (7, 'use_knowledge_base', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (8, 'smtp_email', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (9, 'smtp_password', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (10, 'company_info_format', '{company_name}<br />\r\n      {address}<br />\r\n      {city} {state}<br />\r\n      {country_code} {zip_code}<br />\r\n      {vat_number_with_label}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (11, 'smtp_port', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (12, 'smtp_host', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (13, 'smtp_email_charset', 'utf-8', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (14, 'default_timezone', 'Asia/Qatar', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (15, 'clients_default_theme', 'perfex', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (16, 'company_logo', '804911d5528adf9194dac5a9304aef65.png', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (17, 'tables_pagination_limit', '25', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (18, 'main_domain', 'www.alraedautomobile.com', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (19, 'allow_registration', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (20, 'knowledge_base_without_registration', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (21, 'email_signature', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (22, 'default_staff_role', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (23, 'newsfeed_maximum_files_upload', '10', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (24, 'contract_expiration_before', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (25, 'invoice_prefix', 'INV-', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (26, 'decimal_separator', '.', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (27, 'thousand_separator', ',', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (28, 'invoice_company_name', 'Al Raed Automobile Services', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (29, 'invoice_company_address', 'East Industrial Area, Al Rayan Road, Street No 40, Gate No 01', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (30, 'invoice_company_city', 'Doha', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (31, 'invoice_company_country_code', '974', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (32, 'invoice_company_postal_code', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (33, 'invoice_company_phonenumber', '4478 3711', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (34, 'view_invoice_only_logged_in', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (35, 'invoice_number_format', '2', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (36, 'next_invoice_number', '2', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (37, 'active_language', 'english', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (38, 'invoice_number_decrement_on_delete', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (39, 'automatically_send_invoice_overdue_reminder_after', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (40, 'automatically_resend_invoice_overdue_reminder_after', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (41, 'expenses_auto_operations_hour', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (42, 'delete_only_on_last_invoice', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (43, 'delete_only_on_last_estimate', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (44, 'create_invoice_from_recurring_only_on_paid_invoices', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (45, 'allow_payment_amount_to_be_modified', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (46, 'rtl_support_client', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (47, 'limit_top_search_bar_results_to', '10', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (48, 'estimate_prefix', 'Job-', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (49, 'next_estimate_number', '5', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (50, 'estimate_number_decrement_on_delete', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (51, 'estimate_number_format', '2', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (52, 'estimate_auto_convert_to_invoice_on_client_accept', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (53, 'exclude_estimate_from_client_area_with_draft_status', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (54, 'rtl_support_admin', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (55, 'last_cron_run', '1724475607', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (56, 'show_sale_agent_on_estimates', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (57, 'show_sale_agent_on_invoices', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (58, 'predefined_terms_invoice', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (59, 'predefined_terms_estimate', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (60, 'default_task_priority', '2', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (61, 'dropbox_app_key', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (62, 'show_expense_reminders_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (63, 'only_show_contact_tickets', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (64, 'predefined_clientnote_invoice', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (65, 'predefined_clientnote_estimate', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (66, 'custom_pdf_logo_image_url', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (67, 'favicon', 'favicon.png', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (68, 'invoice_due_after', '30', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (69, 'google_api_key', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (70, 'google_calendar_main_calendar', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (71, 'default_tax', 'a:0:{}', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (72, 'show_invoices_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (73, 'show_estimates_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (74, 'show_contracts_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (75, 'show_tasks_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (76, 'show_customer_reminders_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (77, 'output_client_pdfs_from_admin_area_in_client_language', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (78, 'show_lead_reminders_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (79, 'send_estimate_expiry_reminder_before', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (80, 'leads_default_source', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (81, 'leads_default_status', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (82, 'proposal_expiry_reminder_enabled', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (83, 'send_proposal_expiry_reminder_before', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (84, 'default_contact_permissions', 'a:6:{i:0;s:1:\"1\";i:1;s:1:\"2\";i:2;s:1:\"3\";i:3;s:1:\"4\";i:4;s:1:\"5\";i:5;s:1:\"6\";}', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (85, 'pdf_logo_width', '150', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (86, 'access_tickets_to_none_staff_members', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (87, 'customer_default_country', '179', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (88, 'view_estimate_only_logged_in', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (89, 'show_status_on_pdf_ei', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (90, 'email_piping_only_replies', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (91, 'email_piping_only_registered', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (92, 'default_view_calendar', 'dayGridMonth', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (93, 'email_piping_default_priority', '2', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (94, 'total_to_words_lowercase', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (95, 'show_tax_per_item', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (96, 'total_to_words_enabled', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (97, 'receive_notification_on_new_ticket', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (98, 'autoclose_tickets_after', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (99, 'media_max_file_size_upload', '10', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (100, 'client_staff_add_edit_delete_task_comments_first_hour', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (101, 'show_projects_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (102, 'leads_kanban_limit', '50', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (103, 'tasks_reminder_notification_before', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (104, 'pdf_font', 'freesans', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (105, 'pdf_table_heading_color', '#323a45', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (106, 'pdf_table_heading_text_color', '#ffffff', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (107, 'pdf_font_size', '10', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (108, 'default_leads_kanban_sort', 'leadorder', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (109, 'default_leads_kanban_sort_type', 'asc', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (110, 'allowed_files', '.png,.jpg,.pdf,.doc,.docx,.xls,.xlsx,.zip,.rar,.txt', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (111, 'show_all_tasks_for_project_member', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (112, 'email_protocol', 'smtp', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (113, 'calendar_first_day', '6', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (114, 'recaptcha_secret_key', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (115, 'show_help_on_setup_menu', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (116, 'show_proposals_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (117, 'smtp_encryption', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (118, 'recaptcha_site_key', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (119, 'smtp_username', 'alraedautomobile@dotswebsolution.com', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (120, 'auto_stop_tasks_timers_on_new_timer', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (121, 'notification_when_customer_pay_invoice', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (122, 'calendar_invoice_color', '#ff6f00', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (123, 'calendar_estimate_color', '#ff6f00', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (124, 'calendar_proposal_color', '#84c529', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (125, 'new_task_auto_assign_current_member', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (126, 'calendar_reminder_color', '#03a9f4', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (127, 'calendar_contract_color', '#b72974', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (128, 'calendar_project_color', '#b72974', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (129, 'update_info_message', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (130, 'show_estimate_reminders_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (131, 'show_invoice_reminders_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (132, 'show_proposal_reminders_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (133, 'proposal_due_after', '7', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (134, 'allow_customer_to_change_ticket_status', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (135, 'lead_lock_after_convert_to_customer', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (136, 'default_proposals_pipeline_sort', 'pipeline_order', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (137, 'default_proposals_pipeline_sort_type', 'asc', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (138, 'default_estimates_pipeline_sort', 'pipeline_order', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (139, 'default_estimates_pipeline_sort_type', 'asc', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (140, 'use_recaptcha_customers_area', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (141, 'remove_decimals_on_zero', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (142, 'remove_tax_name_from_item_table', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (143, 'pdf_format_invoice', 'A4-PORTRAIT', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (144, 'pdf_format_estimate', 'A4-PORTRAIT', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (145, 'pdf_format_proposal', 'A4-PORTRAIT', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (146, 'pdf_format_payment', 'A4-PORTRAIT', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (147, 'pdf_format_contract', 'A4-PORTRAIT', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (148, 'swap_pdf_info', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (149, 'exclude_invoice_from_client_area_with_draft_status', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (150, 'cron_has_run_from_cli', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (151, 'hide_cron_is_required_message', '0', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (152, 'auto_assign_customer_admin_after_lead_convert', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (153, 'show_transactions_on_invoice_pdf', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (154, 'show_pay_link_to_invoice_pdf', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (155, 'tasks_kanban_limit', '50', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (156, 'purchase_key', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (157, 'estimates_pipeline_limit', '50', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (158, 'proposals_pipeline_limit', '50', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (159, 'proposal_number_prefix', 'PRO-', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (160, 'number_padding_prefixes', '6', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (161, 'show_page_number_on_pdf', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (162, 'calendar_events_limit', '4', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (163, 'show_setup_menu_item_only_on_hover', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (164, 'company_requires_vat_number_field', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (165, 'company_is_required', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (166, 'allow_contact_to_delete_files', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (167, 'company_vat', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (168, 'di', '1724139708', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (169, 'invoice_auto_operations_hour', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (170, 'use_minified_files', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (171, 'only_own_files_contacts', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (172, 'allow_primary_contact_to_view_edit_billing_and_shipping', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (173, 'estimate_due_after', '7', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (174, 'staff_members_open_tickets_to_all_contacts', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (175, 'time_format', '12', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (176, 'delete_activity_log_older_then', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (177, 'disable_language', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (178, 'company_state', 'Qatar', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (179, 'email_header', '<!doctype html>\r\n      <html>\r\n      <head>\r\n      <meta name=\"viewport\" content=\"width=device-width\" />\r\n      <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />\r\n      <style>\r\n      body {\r\n        background-color: #f6f6f6;\r\n        font-family: sans-serif;\r\n        -webkit-font-smoothing: antialiased;\r\n        font-size: 14px;\r\n        line-height: 1.4;\r\n        margin: 0;\r\n        padding: 0;\r\n        -ms-text-size-adjust: 100%;\r\n        -webkit-text-size-adjust: 100%;\r\n      }\r\n      table {\r\n        border-collapse: separate;\r\n        mso-table-lspace: 0pt;\r\n        mso-table-rspace: 0pt;\r\n        width: 100%;\r\n      }\r\n      table td {\r\n        font-family: sans-serif;\r\n        font-size: 14px;\r\n        vertical-align: top;\r\n      }\r\n      /* -------------------------------------\r\n      BODY & CONTAINER\r\n      ------------------------------------- */\r\n      .body {\r\n        background-color: #f6f6f6;\r\n        width: 100%;\r\n      }\r\n      /* Set a max-width, and make it display as block so it will automatically stretch to that width, but will also shrink down on a phone or something */\r\n      \r\n      .container {\r\n        display: block;\r\n        margin: 0 auto !important;\r\n        /* makes it centered */\r\n        max-width: 680px;\r\n        padding: 10px;\r\n        width: 680px;\r\n      }\r\n      /* This should also be a block element, so that it will fill 100% of the .container */\r\n      \r\n      .content {\r\n        box-sizing: border-box;\r\n        display: block;\r\n        margin: 0 auto;\r\n        max-width: 680px;\r\n        padding: 10px;\r\n      }\r\n      /* -------------------------------------\r\n      HEADER, FOOTER, MAIN\r\n      ------------------------------------- */\r\n      \r\n      .main {\r\n        background: #fff;\r\n        border-radius: 3px;\r\n        width: 100%;\r\n      }\r\n      .wrapper {\r\n        box-sizing: border-box;\r\n        padding: 20px;\r\n      }\r\n      .footer {\r\n        clear: both;\r\n        padding-top: 10px;\r\n        text-align: center;\r\n        width: 100%;\r\n      }\r\n      .footer td,\r\n      .footer p,\r\n      .footer span,\r\n      .footer a {\r\n        color: #999999;\r\n        font-size: 12px;\r\n        text-align: center;\r\n      }\r\n      hr {\r\n        border: 0;\r\n        border-bottom: 1px solid #f6f6f6;\r\n        margin: 20px 0;\r\n      }\r\n      /* -------------------------------------\r\n      RESPONSIVE AND MOBILE FRIENDLY STYLES\r\n      ------------------------------------- */\r\n      \r\n      @media only screen and (max-width: 620px) {\r\n        table[class=body] .content {\r\n          padding: 0 !important;\r\n        }\r\n        table[class=body] .container {\r\n          padding: 0 !important;\r\n          width: 100% !important;\r\n        }\r\n        table[class=body] .main {\r\n          border-left-width: 0 !important;\r\n          border-radius: 0 !important;\r\n          border-right-width: 0 !important;\r\n        }\r\n      }\r\n      </style>\r\n      </head>\r\n      <body class=\"\">\r\n      <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class=\"body\">\r\n      <tr>\r\n      <td>&nbsp;</td>\r\n      <td class=\"container\">\r\n      <div class=\"content\">\r\n      <!-- START CENTERED WHITE CONTAINER -->\r\n      <table class=\"main\">\r\n      <!-- START MAIN CONTENT AREA -->\r\n      <tr>\r\n      <td class=\"wrapper\">\r\n      <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n      <tr>\r\n      <td>', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (180, 'show_pdf_signature_invoice', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (181, 'show_pdf_signature_estimate', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (182, 'signature_image', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (183, 'email_footer', '</td>\r\n      </tr>\r\n      </table>\r\n      </td>\r\n      </tr>\r\n      <!-- END MAIN CONTENT AREA -->\r\n      </table>\r\n      <!-- START FOOTER -->\r\n      <div class=\"footer\">\r\n      <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n      <tr>\r\n      <td class=\"content-block\">\r\n      <span>{companyname}</span>\r\n      </td>\r\n      </tr>\r\n      </table>\r\n      </div>\r\n      <!-- END FOOTER -->\r\n      <!-- END CENTERED WHITE CONTAINER -->\r\n      </div>\r\n      </td>\r\n      <td>&nbsp;</td>\r\n      </tr>\r\n      </table>\r\n      </body>\r\n      </html>', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (184, 'exclude_proposal_from_client_area_with_draft_status', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (185, 'pusher_app_key', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (186, 'pusher_app_secret', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (187, 'pusher_app_id', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (188, 'pusher_realtime_notifications', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (189, 'pdf_format_statement', 'A4-PORTRAIT', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (190, 'pusher_cluster', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (191, 'show_table_export_button', 'to_all', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (192, 'allow_staff_view_proposals_assigned', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (193, 'show_cloudflare_notice', '0', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (194, 'task_modal_class', 'modal-lg', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (195, 'lead_modal_class', 'modal-lg', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (196, 'show_timesheets_overview_all_members_notice_admins', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (197, 'desktop_notifications', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (198, 'hide_notified_reminders_from_calendar', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (199, 'customer_info_format', '{company_name}<br />\r\n      {street}<br />\r\n      {city} {state}<br />\r\n      {country_code} {zip_code}<br />\r\n      {vat_number_with_label}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (200, 'timer_started_change_status_in_progress', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (201, 'default_ticket_reply_status', '3', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (202, 'default_task_status', 'auto', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (203, 'email_queue_skip_with_attachments', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (204, 'email_queue_enabled', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (205, 'last_email_queue_retry', '1724475607', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (206, 'auto_dismiss_desktop_notifications_after', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (207, 'proposal_info_format', '{proposal_to}<br />\r\n      {address}<br />\r\n      {city} {state}<br />\r\n      {country_code} {zip_code}<br />\r\n      {phone}<br />\r\n      {email}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (208, 'ticket_replies_order', 'asc', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (209, 'new_recurring_invoice_action', 'generate_and_send', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (210, 'bcc_emails', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (211, 'email_templates_language_checks', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (212, 'proposal_accept_identity_confirmation', '0', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (213, 'estimate_accept_identity_confirmation', '0', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (214, 'new_task_auto_follower_current_member', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (215, 'task_biillable_checked_on_creation', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (216, 'predefined_clientnote_credit_note', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (217, 'predefined_terms_credit_note', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (218, 'next_credit_note_number', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (219, 'credit_note_prefix', 'CN-', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (220, 'credit_note_number_decrement_on_delete', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (221, 'pdf_format_credit_note', 'A4-PORTRAIT', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (222, 'show_pdf_signature_credit_note', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (223, 'show_credit_note_reminders_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (224, 'show_amount_due_on_invoice', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (225, 'show_total_paid_on_invoice', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (226, 'show_credits_applied_on_invoice', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (227, 'staff_members_create_inline_lead_status', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (228, 'staff_members_create_inline_customer_groups', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (229, 'staff_members_create_inline_ticket_services', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (230, 'staff_members_save_tickets_predefined_replies', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (231, 'staff_members_create_inline_contract_types', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (232, 'staff_members_create_inline_expense_categories', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (233, 'show_project_on_credit_note', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (234, 'proposals_auto_operations_hour', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (235, 'estimates_auto_operations_hour', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (236, 'contracts_auto_operations_hour', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (237, 'credit_note_number_format', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (238, 'allow_non_admin_members_to_import_leads', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (239, 'e_sign_legal_text', 'By clicking on \"Sign\", I consent to be legally bound by this electronic representation of my signature.', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (240, 'show_pdf_signature_contract', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (241, 'view_contract_only_logged_in', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (242, 'show_subscriptions_in_customers_area', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (243, 'calendar_only_assigned_tasks', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (244, 'after_subscription_payment_captured', 'nothing', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (245, 'mail_engine', 'phpmailer', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (246, 'gdpr_enable_terms_and_conditions', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (247, 'privacy_policy', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (248, 'terms_and_conditions', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (249, 'gdpr_enable_terms_and_conditions_lead_form', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (250, 'gdpr_enable_terms_and_conditions_ticket_form', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (251, 'gdpr_contact_enable_right_to_be_forgotten', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (252, 'show_gdpr_in_customers_menu', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (253, 'show_gdpr_link_in_footer', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (254, 'enable_gdpr', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (255, 'gdpr_on_forgotten_remove_invoices_credit_notes', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (256, 'gdpr_on_forgotten_remove_estimates', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (257, 'gdpr_enable_consent_for_contacts', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (258, 'gdpr_consent_public_page_top_block', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (259, 'gdpr_page_top_information_block', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (260, 'gdpr_enable_lead_public_form', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (261, 'gdpr_show_lead_custom_fields_on_public_form', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (262, 'gdpr_lead_attachments_on_public_form', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (263, 'gdpr_enable_consent_for_leads', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (264, 'gdpr_lead_enable_right_to_be_forgotten', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (265, 'allow_staff_view_invoices_assigned', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (266, 'gdpr_data_portability_leads', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (267, 'gdpr_lead_data_portability_allowed', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (268, 'gdpr_contact_data_portability_allowed', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (269, 'gdpr_data_portability_contacts', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (270, 'allow_staff_view_estimates_assigned', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (271, 'gdpr_after_lead_converted_delete', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (272, 'gdpr_show_terms_and_conditions_in_footer', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (273, 'save_last_order_for_tables', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (274, 'company_logo_dark', 'd6494c9b1ff35de329f26af3b00185de.png', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (275, 'customers_register_require_confirmation', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (276, 'allow_non_admin_staff_to_delete_ticket_attachments', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (277, 'receive_notification_on_new_ticket_replies', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (278, 'google_client_id', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (279, 'enable_google_picker', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (280, 'show_ticket_reminders_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (281, 'ticket_import_reply_only', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (282, 'visible_customer_profile_tabs', 'all', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (283, 'show_project_on_invoice', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (284, 'show_project_on_estimate', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (285, 'staff_members_create_inline_lead_source', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (286, 'lead_unique_validation', '[\"email\"]', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (287, 'last_upgrade_copy_data', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (288, 'custom_js_admin_scripts', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (289, 'custom_js_customer_scripts', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (290, 'stripe_webhook_id', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (291, 'stripe_webhook_signing_secret', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (292, 'stripe_ideal_webhook_id', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (293, 'stripe_ideal_webhook_signing_secret', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (294, 'show_php_version_notice', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (295, 'recaptcha_ignore_ips', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (296, 'show_task_reminders_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (297, 'customer_settings', 'true', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (298, 'tasks_reminder_notification_hour', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (299, 'allow_primary_contact_to_manage_other_contacts', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (300, 'items_table_amounts_exclude_currency_symbol', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (301, 'round_off_task_timer_option', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (302, 'round_off_task_timer_time', '5', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (303, 'bitly_access_token', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (304, 'enable_support_menu_badges', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (305, 'attach_invoice_to_payment_receipt_email', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (306, 'invoice_due_notice_before', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (307, 'invoice_due_notice_resend_after', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (308, '_leads_settings', 'true', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (309, 'show_estimate_request_in_customers_area', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (310, 'gdpr_enable_terms_and_conditions_estimate_request_form', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (311, 'identification_key', '1760867706172413981566c44927b05a6', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (312, 'automatically_stop_task_timer_after_hours', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (313, 'automatically_assign_ticket_to_first_staff_responding', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (314, 'reminder_for_completed_but_not_billed_tasks', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (315, 'staff_notify_completed_but_not_billed_tasks', '[\"1\"]', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (316, 'reminder_for_completed_but_not_billed_tasks_days', '[\"Monday\"]', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (317, 'tasks_reminder_notification_last_notified_day', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (318, 'staff_related_ticket_notification_to_assignee_only', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (319, 'show_pdf_signature_proposal', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (320, 'enable_honeypot_spam_validation', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (321, 'microsoft_mail_client_id', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (322, 'microsoft_mail_client_secret', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (323, 'microsoft_mail_azure_tenant_id', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (324, 'google_mail_client_id', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (325, 'google_mail_client_secret', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (326, 'google_mail_refresh_token', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (327, 'microsoft_mail_refresh_token', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (328, 'automatically_set_logged_in_staff_sales_agent', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (329, 'contract_sign_reminder_every_days', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (330, 'last_updated_date', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (331, 'v310_incompatible_tables', '[]', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (332, 'required_register_fields', '[]', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (333, 'allow_non_admin_members_to_delete_tickets_and_replies', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (334, 'allow_non_admin_members_to_edit_ticket_messages', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (335, 'proposal_auto_convert_to_invoice_on_client_accept', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (336, 'show_project_on_proposal', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (337, 'upgraded_from_version', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (338, 'sms_clickatell_api_key', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (339, 'sms_clickatell_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (340, 'sms_clickatell_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (341, 'sms_msg91_sender_id', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (342, 'sms_msg91_api_type', 'api', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (343, 'sms_msg91_auth_key', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (344, 'sms_msg91_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (345, 'sms_msg91_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (346, 'sms_twilio_account_sid', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (347, 'sms_twilio_auth_token', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (348, 'sms_twilio_phone_number', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (349, 'sms_twilio_sender_id', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (350, 'sms_twilio_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (351, 'sms_twilio_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (352, 'paymentmethod_authorize_acceptjs_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (353, 'paymentmethod_authorize_acceptjs_label', 'Authorize.net Accept.js', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (354, 'paymentmethod_authorize_acceptjs_public_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (355, 'paymentmethod_authorize_acceptjs_api_login_id', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (356, 'paymentmethod_authorize_acceptjs_api_transaction_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (357, 'paymentmethod_authorize_acceptjs_description_dashboard', 'Payment for Invoice {invoice_number}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (358, 'paymentmethod_authorize_acceptjs_currencies', 'USD', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (359, 'paymentmethod_authorize_acceptjs_test_mode_enabled', '0', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (360, 'paymentmethod_authorize_acceptjs_default_selected', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (361, 'paymentmethod_authorize_acceptjs_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (362, 'paymentmethod_instamojo_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (363, 'paymentmethod_instamojo_label', 'Instamojo', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (364, 'paymentmethod_instamojo_fee_fixed', '0', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (365, 'paymentmethod_instamojo_fee_percent', '0', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (366, 'paymentmethod_instamojo_api_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (367, 'paymentmethod_instamojo_auth_token', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (368, 'paymentmethod_instamojo_description_dashboard', 'Payment for Invoice {invoice_number}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (369, 'paymentmethod_instamojo_currencies', 'INR', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (370, 'paymentmethod_instamojo_test_mode_enabled', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (371, 'paymentmethod_instamojo_default_selected', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (372, 'paymentmethod_instamojo_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (373, 'paymentmethod_mollie_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (374, 'paymentmethod_mollie_label', 'Mollie', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (375, 'paymentmethod_mollie_api_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (376, 'paymentmethod_mollie_description_dashboard', 'Payment for Invoice {invoice_number}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (377, 'paymentmethod_mollie_currencies', 'EUR', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (378, 'paymentmethod_mollie_test_mode_enabled', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (379, 'paymentmethod_mollie_default_selected', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (380, 'paymentmethod_mollie_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (381, 'paymentmethod_paypal_braintree_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (382, 'paymentmethod_paypal_braintree_label', 'Braintree', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (383, 'paymentmethod_paypal_braintree_merchant_id', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (384, 'paymentmethod_paypal_braintree_api_public_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (385, 'paymentmethod_paypal_braintree_api_private_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (386, 'paymentmethod_paypal_braintree_currencies', 'USD', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (387, 'paymentmethod_paypal_braintree_paypal_enabled', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (388, 'paymentmethod_paypal_braintree_test_mode_enabled', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (389, 'paymentmethod_paypal_braintree_default_selected', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (390, 'paymentmethod_paypal_braintree_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (391, 'paymentmethod_paypal_checkout_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (392, 'paymentmethod_paypal_checkout_label', 'Paypal Smart Checkout', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (393, 'paymentmethod_paypal_checkout_fee_fixed', '0', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (394, 'paymentmethod_paypal_checkout_fee_percent', '0', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (395, 'paymentmethod_paypal_checkout_client_id', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (396, 'paymentmethod_paypal_checkout_secret', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (397, 'paymentmethod_paypal_checkout_payment_description', 'Payment for Invoice {invoice_number}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (398, 'paymentmethod_paypal_checkout_currencies', 'USD,CAD,EUR', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (399, 'paymentmethod_paypal_checkout_test_mode_enabled', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (400, 'paymentmethod_paypal_checkout_default_selected', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (401, 'paymentmethod_paypal_checkout_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (402, 'paymentmethod_paypal_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (403, 'paymentmethod_paypal_label', 'Paypal', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (404, 'paymentmethod_paypal_fee_fixed', '0', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (405, 'paymentmethod_paypal_fee_percent', '0', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (406, 'paymentmethod_paypal_username', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (407, 'paymentmethod_paypal_password', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (408, 'paymentmethod_paypal_signature', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (409, 'paymentmethod_paypal_description_dashboard', 'Payment for Invoice {invoice_number}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (410, 'paymentmethod_paypal_currencies', 'EUR,USD', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (411, 'paymentmethod_paypal_test_mode_enabled', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (412, 'paymentmethod_paypal_default_selected', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (413, 'paymentmethod_paypal_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (414, 'paymentmethod_payu_money_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (415, 'paymentmethod_payu_money_label', 'PayU Money', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (416, 'paymentmethod_payu_money_fee_fixed', '0', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (417, 'paymentmethod_payu_money_fee_percent', '0', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (418, 'paymentmethod_payu_money_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (419, 'paymentmethod_payu_money_salt', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (420, 'paymentmethod_payu_money_description_dashboard', 'Payment for Invoice {invoice_number}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (421, 'paymentmethod_payu_money_currencies', 'INR', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (422, 'paymentmethod_payu_money_test_mode_enabled', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (423, 'paymentmethod_payu_money_default_selected', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (424, 'paymentmethod_payu_money_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (425, 'paymentmethod_stripe_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (426, 'paymentmethod_stripe_label', 'Stripe Checkout', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (427, 'paymentmethod_stripe_fee_fixed', '0', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (428, 'paymentmethod_stripe_fee_percent', '0', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (429, 'paymentmethod_stripe_api_publishable_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (430, 'paymentmethod_stripe_api_secret_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (431, 'paymentmethod_stripe_description_dashboard', 'Payment for Invoice {invoice_number}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (432, 'paymentmethod_stripe_currencies', 'USD,CAD', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (433, 'paymentmethod_stripe_allow_primary_contact_to_update_credit_card', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (434, 'paymentmethod_stripe_default_selected', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (435, 'paymentmethod_stripe_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (436, 'paymentmethod_stripe_ideal_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (437, 'paymentmethod_stripe_ideal_label', 'Stripe iDEAL', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (438, 'paymentmethod_stripe_ideal_api_secret_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (439, 'paymentmethod_stripe_ideal_api_publishable_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (440, 'paymentmethod_stripe_ideal_description_dashboard', 'Payment for Invoice {invoice_number}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (441, 'paymentmethod_stripe_ideal_statement_descriptor', 'Payment for Invoice {invoice_number}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (442, 'paymentmethod_stripe_ideal_currencies', 'EUR', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (443, 'paymentmethod_stripe_ideal_default_selected', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (444, 'paymentmethod_stripe_ideal_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (445, 'paymentmethod_two_checkout_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (446, 'paymentmethod_two_checkout_label', '2Checkout', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (447, 'paymentmethod_two_checkout_fee_fixed', '0', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (448, 'paymentmethod_two_checkout_fee_percent', '0', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (449, 'paymentmethod_two_checkout_merchant_code', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (450, 'paymentmethod_two_checkout_secret_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (451, 'paymentmethod_two_checkout_description', 'Payment for Invoice {invoice_number}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (452, 'paymentmethod_two_checkout_currencies', 'USD, EUR, GBP', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (453, 'paymentmethod_two_checkout_test_mode_enabled', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (454, 'paymentmethod_two_checkout_default_selected', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (455, 'paymentmethod_two_checkout_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (456, 'acc_first_month_of_financial_year', 'January', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (457, 'acc_first_month_of_tax_year', 'same_as_financial_year', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (458, 'acc_accounting_method', 'accrual', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (459, 'acc_close_the_books', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (460, 'acc_allow_changes_after_viewing', 'allow_changes_after_viewing_a_warning', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (461, 'acc_close_book_password', 'Dots$#@!4321', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (462, 'acc_close_book_passwordr', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (463, 'acc_enable_account_numbers', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (464, 'acc_show_account_numbers', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (465, 'acc_closing_date', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (466, 'acc_add_default_account', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (467, 'acc_add_default_account_new', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (468, 'acc_invoice_automatic_conversion', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (469, 'acc_payment_automatic_conversion', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (470, 'acc_credit_note_automatic_conversion', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (471, 'acc_credit_note_refund_automatic_conversion', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (472, 'acc_expense_automatic_conversion', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (473, 'acc_tax_automatic_conversion', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (474, 'acc_invoice_payment_account', '66', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (475, 'acc_invoice_deposit_to', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (476, 'acc_payment_payment_account', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (477, 'acc_payment_deposit_to', '13', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (478, 'acc_credit_note_payment_account', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (479, 'acc_credit_note_deposit_to', '13', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (480, 'acc_credit_note_refund_payment_account', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (481, 'acc_credit_note_refund_deposit_to', '13', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (482, 'acc_expense_payment_account', '13', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (483, 'acc_expense_deposit_to', '80', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (484, 'acc_tax_payment_account', '29', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (485, 'acc_tax_deposit_to', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (486, 'acc_expense_tax_payment_account', '13', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (487, 'acc_expense_tax_deposit_to', '29', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (488, 'acc_active_payment_mode_mapping', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (489, 'acc_active_expense_category_mapping', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (490, 'acc_payment_expense_automatic_conversion', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (491, 'acc_payment_sale_automatic_conversion', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (492, 'acc_expense_payment_payment_account', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (493, 'acc_expense_payment_deposit_to', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (494, 'acc_pl_total_insurance_automatic_conversion', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (495, 'acc_pl_total_insurance_payment_account', '13', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (496, 'acc_pl_total_insurance_deposit_to', '32', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (497, 'acc_pl_tax_paye_automatic_conversion', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (498, 'acc_pl_tax_paye_payment_account', '13', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (499, 'acc_pl_tax_paye_deposit_to', '28', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (500, 'acc_pl_net_pay_automatic_conversion', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (501, 'acc_pl_net_pay_payment_account', '13', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (502, 'acc_pl_net_pay_deposit_to', '56', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (503, 'acc_wh_stock_import_automatic_conversion', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (504, 'acc_wh_stock_import_payment_account', '87', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (505, 'acc_wh_stock_import_deposit_to', '37', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (506, 'acc_wh_stock_export_automatic_conversion', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (507, 'acc_wh_stock_export_payment_account', '37', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (508, 'acc_wh_stock_export_deposit_to', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (509, 'acc_wh_loss_adjustment_automatic_conversion', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (510, 'acc_wh_decrease_payment_account', '37', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (511, 'acc_wh_decrease_deposit_to', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (512, 'acc_wh_increase_payment_account', '87', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (513, 'acc_wh_increase_deposit_to', '37', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (514, 'acc_wh_opening_stock_automatic_conversion', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (515, 'acc_wh_opening_stock_payment_account', '88', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (516, 'acc_wh_opening_stock_deposit_to', '37', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (517, 'acc_pur_order_automatic_conversion', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (518, 'acc_pur_order_payment_account', '13', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (519, 'acc_pur_order_deposit_to', '80', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (520, 'acc_pur_payment_automatic_conversion', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (521, 'acc_pur_payment_payment_account', '16', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (522, 'acc_pur_payment_deposit_to', '37', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (523, 'acc_mrp_manufacturing_order_automatic_conversion', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (524, 'acc_mrp_material_cost_payment_account', '13', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (525, 'acc_mrp_material_cost_deposit_to', '45', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (526, 'acc_mrp_labour_cost_payment_account', '13', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (527, 'acc_mrp_labour_cost_deposit_to', '18', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (528, 'acc_pur_order_return_automatic_conversion', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (529, 'acc_pur_order_return_payment_account', '80', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (530, 'acc_pur_order_return_deposit_to', '13', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (531, 'acc_pur_refund_automatic_conversion', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (532, 'acc_pur_refund_payment_account', '37', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (533, 'acc_pur_refund_deposit_to', '16', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (534, 'acc_pur_invoice_automatic_conversion', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (535, 'acc_pur_invoice_payment_account', '13', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (536, 'acc_pur_invoice_deposit_to', '80', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (537, 'acc_omni_sales_order_return_automatic_conversion', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (538, 'acc_omni_sales_order_return_payment_account', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (539, 'acc_omni_sales_order_return_deposit_to', '66', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (540, 'acc_omni_sales_refund_automatic_conversion', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (541, 'acc_omni_sales_refund_payment_account', '13', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (542, 'acc_omni_sales_refund_deposit_to', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (543, 'acc_routing_number_icon_a', 'a', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (544, 'acc_routing_number_icon_b', 'a', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (545, 'acc_bank_account_icon_a', 'a', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (546, 'acc_bank_account_icon_b', 'a', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (547, 'acc_current_check_no_icon_a', 'a', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (548, 'acc_current_check_no_icon_b', 'a', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (549, 'acc_check_type', 'type_1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (550, 'acc_fe_asset_automatic_conversion', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (551, 'acc_fe_asset_payment_account', '13', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (552, 'acc_fe_asset_deposit_to', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (553, 'acc_fe_license_automatic_conversion', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (554, 'acc_fe_license_payment_account', '13', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (555, 'acc_fe_license_deposit_to', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (556, 'acc_fe_consumable_automatic_conversion', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (557, 'acc_fe_consumable_payment_account', '13', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (558, 'acc_fe_consumable_deposit_to', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (559, 'acc_fe_component_automatic_conversion', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (560, 'acc_fe_component_payment_account', '13', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (561, 'acc_fe_component_deposit_to', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (562, 'acc_fe_maintenance_automatic_conversion', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (563, 'acc_fe_maintenance_payment_account', '13', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (564, 'acc_fe_maintenance_deposit_to', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (565, 'acc_fe_depreciation_automatic_conversion', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (566, 'acc_fe_depreciation_payment_account', '13', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (567, 'acc_fe_depreciation_deposit_to', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (568, 'acc_wh_stock_export_profit_payment_account', '66', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (569, 'acc_wh_stock_export_profit_deposit_to', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (570, 'update_bank_account_v124', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (571, 'update_income_statement_modifications_v125', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (572, 'acc_enable_income_statement_modifications', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (573, 'acc_invoice_discount_payment_account', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (574, 'acc_invoice_discount_deposit_to', '19', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (575, 'acc_pur_tax_automatic_conversion', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (576, 'acc_pur_tax_payment_account', '13', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (577, 'acc_pur_tax_deposit_to', '29', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (578, 'acc_wh_stock_import_return_automatic_conversion', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (579, 'acc_wh_stock_import_return_payment_account', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (580, 'acc_wh_stock_import_return_deposit_to', '37', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (581, 'acc_wh_stock_export_profit_automatic_conversion', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (582, 'cr_date_cronjob_currency_rates', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (583, 'cr_automatically_get_currency_rate', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (584, 'cr_global_amount_expiration', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (585, 'auto_backup_enabled', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (586, 'auto_backup_every', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (587, 'last_auto_backup', '1724302806', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (588, 'delete_backups_older_then', '30', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (589, 'auto_backup_hour', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (590, 'aside_menu_active', '{\"dashboard\":{\"id\":\"dashboard\",\"icon\":\"\",\"disabled\":\"false\",\"position\":1},\"estimates\":{\"id\":\"estimates\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"10\"},\"invoices\":{\"id\":\"invoices\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"15\"},\"sales\":{\"id\":\"sales\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"20\",\"children\":{\"proposals\":{\"disabled\":\"true\",\"id\":\"proposals\",\"icon\":\"\",\"position\":\"5\"},\"payments\":{\"disabled\":\"false\",\"id\":\"payments\",\"icon\":\"\",\"position\":\"10\"},\"credit_notes\":{\"disabled\":\"false\",\"id\":\"credit_notes\",\"icon\":\"\",\"position\":\"15\"},\"items\":{\"disabled\":\"false\",\"id\":\"items\",\"icon\":\"\",\"position\":\"20\"}}},\"customers\":{\"id\":\"customers\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"25\"},\"accounting\":{\"id\":\"accounting\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"30\",\"children\":{\"accounting_dashboard\":{\"disabled\":\"false\",\"id\":\"accounting_dashboard\",\"icon\":\"\",\"position\":\"5\"},\"accounting_banking\":{\"disabled\":\"false\",\"id\":\"accounting_banking\",\"icon\":\"\",\"position\":\"10\"},\"accounting_transaction\":{\"disabled\":\"false\",\"id\":\"accounting_transaction\",\"icon\":\"\",\"position\":\"15\"},\"accounting_registers\":{\"disabled\":\"false\",\"id\":\"accounting_registers\",\"icon\":\"\",\"position\":\"20\"},\"accounting_bills\":{\"disabled\":\"false\",\"id\":\"accounting_bills\",\"icon\":\"\",\"position\":\"25\"},\"accounting_checks\":{\"disabled\":\"false\",\"id\":\"accounting_checks\",\"icon\":\"\",\"position\":\"30\"},\"accounting_journal_entry\":{\"disabled\":\"false\",\"id\":\"accounting_journal_entry\",\"icon\":\"\",\"position\":\"35\"},\"accounting_transfer\":{\"disabled\":\"false\",\"id\":\"accounting_transfer\",\"icon\":\"\",\"position\":\"40\"},\"accounting_chart_of_accounts\":{\"disabled\":\"false\",\"id\":\"accounting_chart_of_accounts\",\"icon\":\"\",\"position\":\"45\"},\"accounting_reconcile\":{\"disabled\":\"false\",\"id\":\"accounting_reconcile\",\"icon\":\"\",\"position\":\"50\"},\"accounting_budget\":{\"disabled\":\"false\",\"id\":\"accounting_budget\",\"icon\":\"\",\"position\":\"55\"},\"accounting_vendor\":{\"disabled\":\"false\",\"id\":\"accounting_vendor\",\"icon\":\"\",\"position\":\"60\"},\"accounting_report\":{\"disabled\":\"false\",\"id\":\"accounting_report\",\"icon\":\"\",\"position\":\"65\"},\"accounting_setting\":{\"disabled\":\"false\",\"id\":\"accounting_setting\",\"icon\":\"\",\"position\":\"70\"}}},\"subscriptions\":{\"id\":\"subscriptions\",\"icon\":\"\",\"disabled\":\"true\",\"position\":\"35\"},\"expenses\":{\"id\":\"expenses\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"40\"},\"contracts\":{\"id\":\"contracts\",\"icon\":\"\",\"disabled\":\"true\",\"position\":\"45\"},\"projects\":{\"id\":\"projects\",\"icon\":\"\",\"disabled\":\"true\",\"position\":\"50\"},\"tasks\":{\"id\":\"tasks\",\"icon\":\"\",\"disabled\":\"true\",\"position\":\"55\"},\"support\":{\"id\":\"support\",\"icon\":\"\",\"disabled\":\"true\",\"position\":\"60\"},\"leads\":{\"id\":\"leads\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"65\"},\"estimate_request\":{\"id\":\"estimate_request\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"70\"},\"knowledge-base\":{\"id\":\"knowledge-base\",\"icon\":\"\",\"disabled\":\"true\",\"position\":\"75\"},\"utilities\":{\"id\":\"utilities\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"80\",\"children\":{\"media\":{\"disabled\":\"false\",\"id\":\"media\",\"icon\":\"\",\"position\":\"5\"},\"bulk-pdf-exporter\":{\"disabled\":\"false\",\"id\":\"bulk-pdf-exporter\",\"icon\":\"\",\"position\":\"10\"},\"csv-export\":{\"disabled\":\"false\",\"id\":\"csv-export\",\"icon\":\"\",\"position\":\"15\"},\"calendar\":{\"disabled\":\"false\",\"id\":\"calendar\",\"icon\":\"\",\"position\":\"20\"},\"announcements\":{\"disabled\":\"true\",\"id\":\"announcements\",\"icon\":\"\",\"position\":\"25\"},\"activity-log\":{\"disabled\":\"false\",\"id\":\"activity-log\",\"icon\":\"\",\"position\":\"30\"},\"utility_backup\":{\"disabled\":\"false\",\"id\":\"utility_backup\",\"icon\":\"\",\"position\":\"35\"},\"ticket-pipe-log\":{\"disabled\":\"true\",\"id\":\"ticket-pipe-log\",\"icon\":\"\",\"position\":\"40\"}}},\"reports\":{\"id\":\"reports\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"85\",\"children\":{\"sales-reports\":{\"disabled\":\"false\",\"id\":\"sales-reports\",\"icon\":\"\",\"position\":\"5\"},\"expenses-reports\":{\"disabled\":\"false\",\"id\":\"expenses-reports\",\"icon\":\"\",\"position\":\"10\"},\"expenses-vs-income-reports\":{\"disabled\":\"false\",\"id\":\"expenses-vs-income-reports\",\"icon\":\"\",\"position\":\"15\"},\"leads-reports\":{\"disabled\":\"true\",\"id\":\"leads-reports\",\"icon\":\"\",\"position\":\"20\"},\"timesheets-reports\":{\"disabled\":\"false\",\"id\":\"timesheets-reports\",\"icon\":\"\",\"position\":\"25\"},\"knowledge-base-reports\":{\"disabled\":\"false\",\"id\":\"knowledge-base-reports\",\"icon\":\"\",\"position\":\"30\"}}}}', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (591, 'setup_menu_active', '{\"staff\":{\"id\":\"staff\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"5\"},\"customers\":{\"id\":\"customers\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"10\",\"children\":{\"customer-groups\":{\"disabled\":\"false\",\"id\":\"customer-groups\",\"icon\":\"\",\"position\":\"5\"}}},\"support\":{\"id\":\"support\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"15\",\"children\":{\"departments\":{\"disabled\":\"false\",\"id\":\"departments\",\"icon\":\"\",\"position\":\"5\"},\"tickets-predefined-replies\":{\"disabled\":\"false\",\"id\":\"tickets-predefined-replies\",\"icon\":\"\",\"position\":\"10\"},\"tickets-priorities\":{\"disabled\":\"false\",\"id\":\"tickets-priorities\",\"icon\":\"\",\"position\":\"15\"},\"tickets-statuses\":{\"disabled\":\"false\",\"id\":\"tickets-statuses\",\"icon\":\"\",\"position\":\"20\"},\"tickets-services\":{\"disabled\":\"false\",\"id\":\"tickets-services\",\"icon\":\"\",\"position\":\"25\"},\"tickets-spam-filters\":{\"disabled\":\"false\",\"id\":\"tickets-spam-filters\",\"icon\":\"\",\"position\":\"30\"}}},\"leads\":{\"id\":\"leads\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"20\",\"children\":{\"leads-sources\":{\"disabled\":\"false\",\"id\":\"leads-sources\",\"icon\":\"\",\"position\":\"5\"},\"leads-statuses\":{\"disabled\":\"false\",\"id\":\"leads-statuses\",\"icon\":\"\",\"position\":\"10\"},\"leads-email-integration\":{\"disabled\":\"false\",\"id\":\"leads-email-integration\",\"icon\":\"\",\"position\":\"15\"},\"web-to-lead\":{\"disabled\":\"false\",\"id\":\"web-to-lead\",\"icon\":\"\",\"position\":\"20\"}}},\"finance\":{\"id\":\"finance\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"25\",\"children\":{\"taxes\":{\"disabled\":\"false\",\"id\":\"taxes\",\"icon\":\"\",\"position\":\"5\"},\"currencies\":{\"disabled\":\"false\",\"id\":\"currencies\",\"icon\":\"\",\"position\":\"10\"},\"payment-modes\":{\"id\":\"payment-modes\",\"disabled\":\"false\",\"icon\":\"\",\"position\":\"15\"},\"expenses-categories\":{\"disabled\":\"false\",\"id\":\"expenses-categories\",\"icon\":\"\",\"position\":\"20\"}}},\"contracts\":{\"id\":\"contracts\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"30\",\"children\":{\"contracts-types\":{\"disabled\":\"false\",\"id\":\"contracts-types\",\"icon\":\"\",\"position\":\"5\"}}},\"estimate_request\":{\"id\":\"estimate_request\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"35\",\"children\":{\"estimate-request-forms\":{\"disabled\":\"false\",\"id\":\"estimate-request-forms\",\"icon\":\"\",\"position\":\"5\"},\"estimate-request-statuses\":{\"disabled\":\"false\",\"id\":\"estimate-request-statuses\",\"icon\":\"\",\"position\":\"10\"}}},\"modules\":{\"id\":\"modules\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"40\"},\"email-templates\":{\"id\":\"email-templates\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"45\"},\"custom-fields\":{\"id\":\"custom-fields\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"50\"},\"gdpr\":{\"id\":\"gdpr\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"55\"},\"roles\":{\"id\":\"roles\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"60\"},\"menu-options\":{\"id\":\"menu-options\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"65\",\"children\":{\"main-menu-options\":{\"disabled\":\"false\",\"id\":\"main-menu-options\",\"icon\":\"\",\"position\":\"5\"},\"setup-menu-options\":{\"disabled\":\"false\",\"id\":\"setup-menu-options\",\"icon\":\"\",\"position\":\"10\"}}},\"theme-style\":{\"id\":\"theme-style\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"70\"},\"settings\":{\"id\":\"settings\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"75\"}}', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (592, 'theme_style', '[]', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (593, 'theme_style_custom_admin_area', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (594, 'theme_style_custom_clients_area', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (595, 'theme_style_custom_clients_and_admin_area', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (596, 'sms_trigger_invoice_overdue_notice', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (597, 'sms_trigger_invoice_due_notice', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (598, 'sms_trigger_invoice_payment_recorded', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (599, 'sms_trigger_estimate_expiration_reminder', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (600, 'sms_trigger_proposal_expiration_reminder', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (601, 'sms_trigger_proposal_new_comment_to_customer', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (602, 'sms_trigger_proposal_new_comment_to_staff', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (603, 'sms_trigger_contract_new_comment_to_customer', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (604, 'sms_trigger_contract_new_comment_to_staff', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (605, 'sms_trigger_contract_expiration_reminder', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (606, 'sms_trigger_contract_sign_reminder_to_customer', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (607, 'sms_trigger_staff_reminder', '', 0);


#
# TABLE STRUCTURE FOR: tblpayment_attempts
#

DROP TABLE IF EXISTS `tblpayment_attempts`;

CREATE TABLE `tblpayment_attempts` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `reference` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `invoice_id` int NOT NULL,
  `amount` double NOT NULL,
  `fee` double NOT NULL,
  `payment_gateway` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblpayment_modes
#

DROP TABLE IF EXISTS `tblpayment_modes`;

CREATE TABLE `tblpayment_modes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `show_on_pdf` int NOT NULL DEFAULT '0',
  `invoices_only` int NOT NULL DEFAULT '0',
  `expenses_only` int NOT NULL DEFAULT '0',
  `selected_by_default` int NOT NULL DEFAULT '1',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tblpayment_modes` (`id`, `name`, `description`, `show_on_pdf`, `invoices_only`, `expenses_only`, `selected_by_default`, `active`) VALUES (1, 'Bank', '', 0, 0, 0, 1, 1);
INSERT INTO `tblpayment_modes` (`id`, `name`, `description`, `show_on_pdf`, `invoices_only`, `expenses_only`, `selected_by_default`, `active`) VALUES (2, 'Cash', '', 0, 0, 0, 1, 1);
INSERT INTO `tblpayment_modes` (`id`, `name`, `description`, `show_on_pdf`, `invoices_only`, `expenses_only`, `selected_by_default`, `active`) VALUES (3, 'Debit / Credit Card', '', 0, 0, 0, 1, 1);


#
# TABLE STRUCTURE FOR: tblpinned_projects
#

DROP TABLE IF EXISTS `tblpinned_projects`;

CREATE TABLE `tblpinned_projects` (
  `id` int NOT NULL AUTO_INCREMENT,
  `project_id` int NOT NULL,
  `staff_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblproject_activity
#

DROP TABLE IF EXISTS `tblproject_activity`;

CREATE TABLE `tblproject_activity` (
  `id` int NOT NULL AUTO_INCREMENT,
  `project_id` int NOT NULL,
  `staff_id` int NOT NULL DEFAULT '0',
  `contact_id` int NOT NULL DEFAULT '0',
  `fullname` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `visible_to_customer` int NOT NULL DEFAULT '0',
  `description_key` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Language file key',
  `additional_data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblproject_files
#

DROP TABLE IF EXISTS `tblproject_files`;

CREATE TABLE `tblproject_files` (
  `id` int NOT NULL AUTO_INCREMENT,
  `file_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `original_file_name` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `subject` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `filetype` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `last_activity` datetime DEFAULT NULL,
  `project_id` int NOT NULL,
  `visible_to_customer` tinyint(1) DEFAULT '0',
  `staffid` int NOT NULL,
  `contact_id` int NOT NULL DEFAULT '0',
  `external` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `external_link` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `thumbnail_link` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblproject_members
#

DROP TABLE IF EXISTS `tblproject_members`;

CREATE TABLE `tblproject_members` (
  `id` int NOT NULL AUTO_INCREMENT,
  `project_id` int NOT NULL,
  `staff_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblproject_notes
#

DROP TABLE IF EXISTS `tblproject_notes`;

CREATE TABLE `tblproject_notes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `project_id` int NOT NULL,
  `content` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `staff_id` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblproject_settings
#

DROP TABLE IF EXISTS `tblproject_settings`;

CREATE TABLE `tblproject_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `project_id` int NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblprojectdiscussioncomments
#

DROP TABLE IF EXISTS `tblprojectdiscussioncomments`;

CREATE TABLE `tblprojectdiscussioncomments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `discussion_id` int NOT NULL,
  `discussion_type` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` int DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime DEFAULT NULL,
  `content` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `staff_id` int NOT NULL,
  `contact_id` int DEFAULT '0',
  `fullname` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_mime_type` varchar(70) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblprojectdiscussions
#

DROP TABLE IF EXISTS `tblprojectdiscussions`;

CREATE TABLE `tblprojectdiscussions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `project_id` int NOT NULL,
  `subject` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `show_to_customer` tinyint(1) NOT NULL DEFAULT '0',
  `datecreated` datetime NOT NULL,
  `last_activity` datetime DEFAULT NULL,
  `staff_id` int NOT NULL DEFAULT '0',
  `contact_id` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblprojects
#

DROP TABLE IF EXISTS `tblprojects`;

CREATE TABLE `tblprojects` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` int NOT NULL DEFAULT '0',
  `clientid` int NOT NULL,
  `billing_type` int NOT NULL,
  `start_date` date NOT NULL,
  `deadline` date DEFAULT NULL,
  `project_created` date NOT NULL,
  `date_finished` datetime DEFAULT NULL,
  `progress` int DEFAULT '0',
  `progress_from_tasks` int NOT NULL DEFAULT '1',
  `project_cost` decimal(15,2) DEFAULT NULL,
  `project_rate_per_hour` decimal(15,2) DEFAULT NULL,
  `estimated_hours` decimal(15,2) DEFAULT NULL,
  `addedfrom` int NOT NULL,
  `contact_notification` int DEFAULT '1',
  `notify_contacts` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblproposal_comments
#

DROP TABLE IF EXISTS `tblproposal_comments`;

CREATE TABLE `tblproposal_comments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `proposalid` int NOT NULL,
  `staffid` int NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblproposals
#

DROP TABLE IF EXISTS `tblproposals`;

CREATE TABLE `tblproposals` (
  `id` int NOT NULL AUTO_INCREMENT,
  `subject` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `addedfrom` int NOT NULL,
  `datecreated` datetime NOT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT '0.00',
  `adjustment` decimal(15,2) DEFAULT NULL,
  `discount_percent` decimal(15,2) NOT NULL,
  `discount_total` decimal(15,2) NOT NULL,
  `discount_type` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `show_quantity_as` int NOT NULL DEFAULT '1',
  `currency` int NOT NULL,
  `open_till` date DEFAULT NULL,
  `date` date NOT NULL,
  `rel_id` int DEFAULT NULL,
  `rel_type` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned` int DEFAULT NULL,
  `hash` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `proposal_to` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `project_id` int DEFAULT NULL,
  `country` int NOT NULL DEFAULT '0',
  `zip` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `allow_comments` tinyint(1) NOT NULL DEFAULT '1',
  `status` int NOT NULL,
  `estimate_id` int DEFAULT NULL,
  `invoice_id` int DEFAULT NULL,
  `date_converted` datetime DEFAULT NULL,
  `pipeline_order` int DEFAULT '1',
  `is_expiry_notified` int NOT NULL DEFAULT '0',
  `acceptance_firstname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `acceptance_lastname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `acceptance_email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_ip` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `signature` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `short_link` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblpur_vendor
#

DROP TABLE IF EXISTS `tblpur_vendor`;

CREATE TABLE `tblpur_vendor` (
  `userid` int unsigned NOT NULL AUTO_INCREMENT,
  `company` varchar(200) DEFAULT NULL,
  `vat` varchar(200) DEFAULT NULL,
  `phonenumber` varchar(30) DEFAULT NULL,
  `country` int NOT NULL DEFAULT '0',
  `city` varchar(100) DEFAULT NULL,
  `zip` varchar(15) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `address` text,
  `website` varchar(150) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `active` int NOT NULL DEFAULT '1',
  `leadid` int DEFAULT NULL,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int DEFAULT '0',
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int DEFAULT '0',
  `longitude` varchar(191) DEFAULT NULL,
  `latitude` varchar(191) DEFAULT NULL,
  `default_language` varchar(40) DEFAULT NULL,
  `default_currency` int NOT NULL DEFAULT '0',
  `show_primary_contact` int NOT NULL DEFAULT '0',
  `stripe_id` varchar(40) DEFAULT NULL,
  `registration_confirmed` int NOT NULL DEFAULT '1',
  `addedfrom` int NOT NULL DEFAULT '0',
  `category` text,
  `bank_detail` text,
  `payment_terms` text,
  `vendor_code` varchar(100) DEFAULT NULL,
  `return_within_day` int DEFAULT NULL,
  `return_order_fee` decimal(15,2) DEFAULT NULL,
  `return_policies` text,
  `balance` decimal(15,2) DEFAULT NULL,
  `balance_as_of` date DEFAULT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

#
# TABLE STRUCTURE FOR: tblrelated_items
#

DROP TABLE IF EXISTS `tblrelated_items`;

CREATE TABLE `tblrelated_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `rel_id` int NOT NULL,
  `rel_type` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `item_id` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblreminders
#

DROP TABLE IF EXISTS `tblreminders`;

CREATE TABLE `tblreminders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `date` datetime NOT NULL,
  `isnotified` int NOT NULL DEFAULT '0',
  `rel_id` int NOT NULL,
  `staff` int NOT NULL,
  `rel_type` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `notify_by_email` int NOT NULL DEFAULT '1',
  `creator` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `staff` (`staff`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblroles
#

DROP TABLE IF EXISTS `tblroles`;

CREATE TABLE `tblroles` (
  `roleid` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `permissions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`roleid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tblroles` (`roleid`, `name`, `permissions`) VALUES (1, 'Employee', NULL);
INSERT INTO `tblroles` (`roleid`, `name`, `permissions`) VALUES (2, 'Manager', 'a:36:{s:17:\"bulk_pdf_exporter\";a:1:{i:0;s:4:\"view\";}s:9:\"contracts\";a:5:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";i:4;s:18:\"view_all_templates\";}s:12:\"credit_notes\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:9:\"customers\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:15:\"email_templates\";a:2:{i:0;s:4:\"view\";i:1;s:4:\"edit\";}s:9:\"estimates\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:8:\"expenses\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:8:\"invoices\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:5:\"items\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:14:\"knowledge_base\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:8:\"payments\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:8:\"projects\";a:7:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";i:4;s:17:\"create_milestones\";i:5;s:15:\"edit_milestones\";i:6;s:17:\"delete_milestones\";}s:9:\"proposals\";a:5:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";i:4;s:18:\"view_all_templates\";}s:7:\"reports\";a:2:{i:0;s:4:\"view\";i:1;s:15:\"view-timesheets\";}s:5:\"roles\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:8:\"settings\";a:1:{i:0;s:4:\"view\";}s:5:\"staff\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:13:\"subscriptions\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:5:\"tasks\";a:8:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";i:4;s:14:\"edit_timesheet\";i:5;s:18:\"edit_own_timesheet\";i:6;s:16:\"delete_timesheet\";i:7;s:20:\"delete_own_timesheet\";}s:19:\"checklist_templates\";a:2:{i:0;s:6:\"create\";i:1;s:6:\"delete\";}s:16:\"estimate_request\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:5:\"leads\";a:2:{i:0;s:4:\"view\";i:1;s:6:\"delete\";}s:20:\"accounting_dashboard\";a:1:{i:0;s:4:\"view\";}s:18:\"accounting_banking\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:22:\"accounting_transaction\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:20:\"accounting_registers\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:16:\"accounting_bills\";a:2:{i:0;s:4:\"view\";i:1;s:6:\"create\";}s:17:\"accounting_checks\";a:2:{i:0;s:4:\"view\";i:1;s:6:\"create\";}s:24:\"accounting_journal_entry\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:19:\"accounting_transfer\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:28:\"accounting_chart_of_accounts\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:20:\"accounting_reconcile\";a:3:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";}s:17:\"accounting_budget\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:17:\"accounting_vendor\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:17:\"accounting_report\";a:1:{i:0;s:4:\"view\";}s:18:\"accounting_setting\";a:1:{i:0;s:4:\"view\";}}');


#
# TABLE STRUCTURE FOR: tblsales_activity
#

DROP TABLE IF EXISTS `tblsales_activity`;

CREATE TABLE `tblsales_activity` (
  `id` int NOT NULL AUTO_INCREMENT,
  `rel_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rel_id` int NOT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `additional_data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `staffid` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `full_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tblsales_activity` (`id`, `rel_type`, `rel_id`, `description`, `additional_data`, `staffid`, `full_name`, `date`) VALUES (7, 'estimate', 2, 'estimate_activity_created', '', '1', 'Alraed Automobile', '2024-08-20 19:40:35');
INSERT INTO `tblsales_activity` (`id`, `rel_type`, `rel_id`, `description`, `additional_data`, `staffid`, `full_name`, `date`) VALUES (8, 'estimate', 3, 'estimate_activity_created', '', '1', 'Alraed Automobile', '2024-08-21 10:45:07');
INSERT INTO `tblsales_activity` (`id`, `rel_type`, `rel_id`, `description`, `additional_data`, `staffid`, `full_name`, `date`) VALUES (9, 'estimate', 3, 'invoice_estimate_activity_added_item', 'a:1:{i:0;s:5:\"Break\";}', '1', 'Alraed Automobile', '2024-08-21 10:47:23');
INSERT INTO `tblsales_activity` (`id`, `rel_type`, `rel_id`, `description`, `additional_data`, `staffid`, `full_name`, `date`) VALUES (10, 'estimate', 3, 'invoice_estimate_activity_added_item', 'a:1:{i:0;s:12:\"Labor Charge\";}', '1', 'Alraed Automobile', '2024-08-21 10:47:23');
INSERT INTO `tblsales_activity` (`id`, `rel_type`, `rel_id`, `description`, `additional_data`, `staffid`, `full_name`, `date`) VALUES (11, 'invoice', 2, 'invoice_activity_created', '', '1', 'Alraed Automobile', '2024-08-21 10:49:33');
INSERT INTO `tblsales_activity` (`id`, `rel_type`, `rel_id`, `description`, `additional_data`, `staffid`, `full_name`, `date`) VALUES (12, 'estimate', 3, 'estimate_activity_converted', 'a:1:{i:0;s:93:\"<a href=\"https://erp.alraedautomobile.com/admin/invoices/list_invoices/2\">INV-2024/000001</a>\";}', '1', 'Alraed Automobile', '2024-08-21 10:49:34');
INSERT INTO `tblsales_activity` (`id`, `rel_type`, `rel_id`, `description`, `additional_data`, `staffid`, `full_name`, `date`) VALUES (13, 'invoice', 2, 'invoice_activity_status_updated', 'a:2:{i:0;s:36:\"<original_status>1</original_status>\";i:1;s:26:\"<new_status>3</new_status>\";}', '1', 'Alraed Automobile', '2024-08-21 10:52:41');
INSERT INTO `tblsales_activity` (`id`, `rel_type`, `rel_id`, `description`, `additional_data`, `staffid`, `full_name`, `date`) VALUES (14, 'invoice', 2, 'invoice_activity_payment_made_by_staff', 'a:2:{i:0;s:11:\"1,000.00QAR\";i:1;s:90:\"<a href=\"https://erp.alraedautomobile.com/admin/payments/payment/2\" target=\"_blank\">#2</a>\";}', '1', 'Alraed Automobile', '2024-08-21 10:52:41');
INSERT INTO `tblsales_activity` (`id`, `rel_type`, `rel_id`, `description`, `additional_data`, `staffid`, `full_name`, `date`) VALUES (15, 'estimate', 3, 'invoice_estimate_activity_added_item', 'a:1:{i:0;s:4:\"Tyre\";}', '1', 'Alraed Automobile', '2024-08-21 11:57:36');
INSERT INTO `tblsales_activity` (`id`, `rel_type`, `rel_id`, `description`, `additional_data`, `staffid`, `full_name`, `date`) VALUES (16, 'estimate', 4, 'estimate_activity_created', '', '1', 'Alraed Automobile', '2024-08-21 11:59:13');
INSERT INTO `tblsales_activity` (`id`, `rel_type`, `rel_id`, `description`, `additional_data`, `staffid`, `full_name`, `date`) VALUES (17, 'estimate', 5, 'estimate_activity_created', '', '1', 'Alraed Automobile', '2024-08-21 12:04:04');
INSERT INTO `tblsales_activity` (`id`, `rel_type`, `rel_id`, `description`, `additional_data`, `staffid`, `full_name`, `date`) VALUES (18, 'invoice', 2, 'invoice_activity_payment_made_by_staff', 'a:2:{i:0;s:9:\"500.00QAR\";i:1;s:90:\"<a href=\"https://erp.alraedautomobile.com/admin/payments/payment/3\" target=\"_blank\">#3</a>\";}', '1', 'Alraed Automobile', '2024-08-21 12:22:40');


#
# TABLE STRUCTURE FOR: tblscheduled_emails
#

DROP TABLE IF EXISTS `tblscheduled_emails`;

CREATE TABLE `tblscheduled_emails` (
  `id` int NOT NULL AUTO_INCREMENT,
  `rel_id` int NOT NULL,
  `rel_type` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `scheduled_at` datetime NOT NULL,
  `contacts` varchar(197) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cc` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `attach_pdf` tinyint(1) NOT NULL DEFAULT '1',
  `template` varchar(197) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblservices
#

DROP TABLE IF EXISTS `tblservices`;

CREATE TABLE `tblservices` (
  `serviceid` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`serviceid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblsessions
#

DROP TABLE IF EXISTS `tblsessions`;

CREATE TABLE `tblsessions` (
  `id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `timestamp` int unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('082cubcrrov5qd3hs2quep5qrpubrj7l', '176.202.10.165', 1724169932, '__ci_last_regenerate|i:1724169932;_prev_url|s:46:\"https://erp.alraedautomobile.com/admin/clients\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"d6f40605d1ea422b575b70cf0010bd32\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:43:\"/home/alraed/erp.alraedautomobile.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-chf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-czhf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cjhf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cJhf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:18:\"application/x-gzip\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:19:\"application/x-bzip2\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:16:\"application/x-xz\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:15:\"application/zip\";a:5:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";s:7:\"getsize\";a:3:{s:4:\"argc\";s:5:\"-Z -t\";s:5:\"regex\";s:21:\"/^.+?,\\s?([0-9]+).+$/\";s:7:\"replace\";s:2:\"$1\";}}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:50:\"/home/alraed/erp.alraedautomobile.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1724161982;}elFinderNetVolumes|a:0:{}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('09ak2l657689f6o1u3neg197c8cmsh8t', '45.148.234.134', 1724151338, '__ci_last_regenerate|i:1724151338;red_url|s:33:\"https://erp.alraedautomobile.com/\";_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0a5q8tbltuk3e5l9c2s04fv9uefkkliq', '68.66.220.30', 1724216411, '__ci_last_regenerate|i:1724216410;_prev_url|s:43:\"https://erp.alraedautomobile.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0aorq6pqlnqrb8eef8doqtt01osdrmg8', '176.202.10.165', 1724226307, '__ci_last_regenerate|i:1724226307;_prev_url|s:57:\"https://erp.alraedautomobile.com/admin/estimates/estimate\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";red_url|s:33:\"https://erp.alraedautomobile.com/\";message-success|s:28:\"Estimate added successfully.\";__ci_vars|a:1:{s:15:\"message-success\";s:3:\"new\";}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0qedslbc431or4b9bd56c0reb0ce3o3m', '176.202.10.165', 1724157662, '__ci_last_regenerate|i:1724157661;red_url|s:38:\"https://erp.alraedautomobile.com/admin\";_prev_url|s:53:\"https://erp.alraedautomobile.com/admin/authentication\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0umik9m4phk1d7vgsjtj5qmuk8fri9f7', '176.202.10.165', 1724166235, '__ci_last_regenerate|i:1724166235;_prev_url|s:53:\"https://erp.alraedautomobile.com/admin/clients/client\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"d6f40605d1ea422b575b70cf0010bd32\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:43:\"/home/alraed/erp.alraedautomobile.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-chf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-czhf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cjhf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cJhf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:18:\"application/x-gzip\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:19:\"application/x-bzip2\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:16:\"application/x-xz\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:15:\"application/zip\";a:5:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";s:7:\"getsize\";a:3:{s:4:\"argc\";s:5:\"-Z -t\";s:5:\"regex\";s:21:\"/^.+?,\\s?([0-9]+).+$/\";s:7:\"replace\";s:2:\"$1\";}}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:50:\"/home/alraed/erp.alraedautomobile.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1724161982;}elFinderNetVolumes|a:0:{}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('18m5mclolt68kd5g3oe051sf3hhs1ilb', '23.228.131.5', 1724153342, '__ci_last_regenerate|i:1724153341;red_url|s:38:\"https://erp.alraedautomobile.com/admin\";_prev_url|s:53:\"https://erp.alraedautomobile.com/admin/authentication\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1au38var58qsarufs42160m35usq5fd4', '2a03:b0c0:3:d0::d1a:1', 1724145178, '__ci_last_regenerate|i:1724145178;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1c8d1q9spv5oufb6cvjcud5g1oq58crn', '212.70.108.7', 1724140095, '__ci_last_regenerate|i:1724140095;_prev_url|s:46:\"https://erp.alraedautomobile.com/admin/modules\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('230rvlasa2fsno8up45g3qihugqeisqh', '203.192.226.78', 1724146940, '__ci_last_regenerate|i:1724146940;_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('282ujp7uplk48gfkkg1g5nt763ga82pp', '193.202.83.32', 1724146923, '__ci_last_regenerate|i:1724146923;_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2c17ps7rgrspjkf5kb49cupp9um4luqn', '176.202.10.165', 1724168553, '__ci_last_regenerate|i:1724168553;_prev_url|s:38:\"https://erp.alraedautomobile.com/admin\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2ceau9p12da1ig36quqcbru98thbpp0n', '2604:a880:400:d0::24c8:8001', 1724145178, '__ci_last_regenerate|i:1724145178;is_mobile|b:1;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2jlhpd7hv9ma8s5h427eacjfv75rlvg4', '34.105.219.249', 1724139812, '__ci_last_regenerate|i:1724139812;_prev_url|s:53:\"https://erp.alraedautomobile.com/admin/authentication\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2offlv7gnmf87dve4gdlh2a7icrt5d5f', '176.202.10.165', 1724226006, '__ci_last_regenerate|i:1724226006;_prev_url|s:57:\"https://erp.alraedautomobile.com/admin/estimates/estimate\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3aas692sevbiv7iq9v1kfpsgboauqrug', '176.202.10.165', 1724172851, '__ci_last_regenerate|i:1724172670;_prev_url|s:48:\"https://erp.alraedautomobile.com/admin/estimates\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"d6f40605d1ea422b575b70cf0010bd32\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:43:\"/home/alraed/erp.alraedautomobile.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-chf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-czhf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cjhf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cJhf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:18:\"application/x-gzip\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:19:\"application/x-bzip2\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:16:\"application/x-xz\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:15:\"application/zip\";a:5:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";s:7:\"getsize\";a:3:{s:4:\"argc\";s:5:\"-Z -t\";s:5:\"regex\";s:21:\"/^.+?,\\s?([0-9]+).+$/\";s:7:\"replace\";s:2:\"$1\";}}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:50:\"/home/alraed/erp.alraedautomobile.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1724161982;}elFinderNetVolumes|a:0:{}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3etlb4533rhmomri2ts1u9vtc40utomj', '192.175.111.229', 1724147517, '__ci_last_regenerate|i:1724147517;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3fp6b9e3f3t42io6i6grcf9l3g04526m', '212.70.108.7', 1724142810, '__ci_last_regenerate|i:1724142810;_prev_url|s:43:\"https://erp.alraedautomobile.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3gpfie1ukuv5obl377eni0q7vtcr8v55', '202.7.52.129', 1724146948, '__ci_last_regenerate|i:1724146948;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3uulltdue14rdihuknnh1gg9c8pvduci', '176.202.10.165', 1724152733, '__ci_last_regenerate|i:1724152733;red_url|s:33:\"https://erp.alraedautomobile.com/\";_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('43m0dv2rhuhmv6klae1fdnjf7336ggb1', '176.202.10.165', 1724159082, '__ci_last_regenerate|i:1724159082;_prev_url|s:61:\"https://erp.alraedautomobile.com/admin/settings?group=company\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('46cannjo0v7ugopbf7tf0cv70rc94dr3', '197.155.69.18', 1724146943, '__ci_last_regenerate|i:1724146943;_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('47vi3vmh15rei66hiint1j19fiupu42s', '134.122.88.193', 1724313043, '__ci_last_regenerate|i:1724313043;_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('493758rnnjmosgot8msaov1136bhvpqs', '195.211.77.142', 1724192148, '__ci_last_regenerate|i:1724192148;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4dk3kas4c8f0p6t8lpg0cph6h6ojddg4', '113.160.115.82', 1724146946, '__ci_last_regenerate|i:1724146946;_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4pkv2ge2cgjlpo9niae726umnamsvb4c', '174.72.24.251', 1724146801, '__ci_last_regenerate|i:1724146801;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5hgcdjnjfjbiton46rf2r3v343fmbo19', '176.202.10.165', 1724170898, '__ci_last_regenerate|i:1724170898;_prev_url|s:57:\"https://erp.alraedautomobile.com/admin/estimates/estimate\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"d6f40605d1ea422b575b70cf0010bd32\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:43:\"/home/alraed/erp.alraedautomobile.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-chf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-czhf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cjhf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cJhf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:18:\"application/x-gzip\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:19:\"application/x-bzip2\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:16:\"application/x-xz\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:15:\"application/zip\";a:5:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";s:7:\"getsize\";a:3:{s:4:\"argc\";s:5:\"-Z -t\";s:5:\"regex\";s:21:\"/^.+?,\\s?([0-9]+).+$/\";s:7:\"replace\";s:2:\"$1\";}}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:50:\"/home/alraed/erp.alraedautomobile.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1724161982;}elFinderNetVolumes|a:0:{}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5hldus2be6djlmr8eb020i2227doerfh', '176.202.10.165', 1724159487, '__ci_last_regenerate|i:1724159487;_prev_url|s:57:\"https://erp.alraedautomobile.com/admin/estimates/estimate\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5lksb4jljm690cav4qka2brprnknrjlq', '154.28.229.247', 1724145226, '__ci_last_regenerate|i:1724145221;red_url|s:33:\"https://erp.alraedautomobile.com/\";_prev_url|s:63:\"https://erp.alraedautomobile.com/authentication/forgot_password\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('69okrpi1d94t2slfg266buv8o6ks46vv', '47.88.94.28', 1724190329, '__ci_last_regenerate|i:1724190329;is_mobile|b:1;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6c4joi3ul26gpuku95heu746epsfrpm4', '2604:a880:800:10::d4e:a001', 1724145178, '__ci_last_regenerate|i:1724145178;is_mobile|b:1;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6do7jqr7s8dng8ntkqq44h04jlllhic7', '176.202.10.165', 1724172358, '__ci_last_regenerate|i:1724172358;_prev_url|s:73:\"https://erp.alraedautomobile.com/admin/settings?group=sales&tab=estimates\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"d6f40605d1ea422b575b70cf0010bd32\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:43:\"/home/alraed/erp.alraedautomobile.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-chf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-czhf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cjhf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cJhf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:18:\"application/x-gzip\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:19:\"application/x-bzip2\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:16:\"application/x-xz\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:15:\"application/zip\";a:5:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";s:7:\"getsize\";a:3:{s:4:\"argc\";s:5:\"-Z -t\";s:5:\"regex\";s:21:\"/^.+?,\\s?([0-9]+).+$/\";s:7:\"replace\";s:2:\"$1\";}}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:50:\"/home/alraed/erp.alraedautomobile.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1724161982;}elFinderNetVolumes|a:0:{}message-success|s:16:\"Settings Updated\";__ci_vars|a:1:{s:15:\"message-success\";s:3:\"old\";}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6jj4b7v9n7ji7j74odc45jiv72kd84jh', '176.202.10.165', 1724232097, '__ci_last_regenerate|i:1724232097;_prev_url|s:68:\"https://erp.alraedautomobile.com/admin/estimates/pdf/5?output_type=I\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6ke7eosuqq598phb99blanvafrt9b2ce', '223.113.128.201', 1724293929, '__ci_last_regenerate|i:1724293928;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6lifaqhl0fgu29ogdf9ktfb6tqt90caq', '35.187.232.113', 1724140918, '__ci_last_regenerate|i:1724140917;red_url|s:69:\"https://erp.alraedautomobile.com/admin/misc/dismiss_cloudflare_notice\";_prev_url|s:53:\"https://erp.alraedautomobile.com/admin/authentication\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6oaa7rscujv0sdq6vql9ae8v8uso2p45', '78.100.51.218', 1724142251, '__ci_last_regenerate|i:1724142251;_prev_url|s:38:\"https://erp.alraedautomobile.com/admin\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6s763bcenjvaeecamdjgv8t26br1glvb', '176.202.10.165', 1724162413, '__ci_last_regenerate|i:1724162413;_prev_url|s:49:\"https://erp.alraedautomobile.com/admin/currencies\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"d6f40605d1ea422b575b70cf0010bd32\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:43:\"/home/alraed/erp.alraedautomobile.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-chf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-czhf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cjhf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cJhf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:18:\"application/x-gzip\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:19:\"application/x-bzip2\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:16:\"application/x-xz\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:15:\"application/zip\";a:5:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";s:7:\"getsize\";a:3:{s:4:\"argc\";s:5:\"-Z -t\";s:5:\"regex\";s:21:\"/^.+?,\\s?([0-9]+).+$/\";s:7:\"replace\";s:2:\"$1\";}}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:50:\"/home/alraed/erp.alraedautomobile.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1724161982;}elFinderNetVolumes|a:0:{}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6u4flguhpvup9n61u2m3eejbq0h954pf', '176.202.10.165', 1724158772, '__ci_last_regenerate|i:1724158772;_prev_url|s:67:\"https://erp.alraedautomobile.com/admin/accounting/new_journal_entry\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('74r96ntd86tlvqtke3ht4evfk86rs785', '195.211.77.140', 1724192116, '__ci_last_regenerate|i:1724192116;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('770gq6vdpjk36a42vp89t5lcjpe1tje1', '113.160.187.2', 1724146944, '__ci_last_regenerate|i:1724146944;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7hnd35ltqj8bihfi5878n12f044p7vpn', '134.122.88.193', 1724313043, '__ci_last_regenerate|i:1724313043;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7l5vjjn96ebcdpeu9bntlkkvtbveco0f', '146.70.224.98', 1724145670, '__ci_last_regenerate|i:1724145669;red_url|s:33:\"https://erp.alraedautomobile.com/\";_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7nd3rab8ngeogvjbuaagk75kieg3qosc', '176.202.10.165', 1724230539, '__ci_last_regenerate|i:1724230539;_prev_url|s:77:\"https://erp.alraedautomobile.com/admin/invoices/list_invoices?filter=not_sent\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7nt5f6s2kggoomvtg85qchbejf2gk9k9', '64.15.129.108', 1724147518, '__ci_last_regenerate|i:1724147518;_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7raoaaivd8f7ad3t3ib16b6n59h7va05', '174.72.24.251', 1724145384, '__ci_last_regenerate|i:1724145384;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('81ipcn5b1rbjdqj7723bv2qdd8du331k', '52.81.78.71', 1724293953, '__ci_last_regenerate|i:1724293953;_prev_url|s:64:\"https://erp.alraedautomobile.com/authentication/login/robots.txt\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8c6lciuj2ruifq2jfgmej8ldi82a2i47', '176.202.10.165', 1724168567, '__ci_last_regenerate|i:1724168553;_prev_url|s:61:\"https://erp.alraedautomobile.com/admin/settings?group=general\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8m03d1suuklneruog0a5brlvgj21mrat', '154.28.229.166', 1724189809, '__ci_last_regenerate|i:1724189809;red_url|s:33:\"https://erp.alraedautomobile.com/\";_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8qd2ca66v5chpe4u4ktbf9065lq41ilf', '212.70.108.7', 1724142884, '__ci_last_regenerate|i:1724142884;_prev_url|s:45:\"https://erp.alraedautomobile.com/admin/backup\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8u229ps1q2hg00bkh80n03djo8rd7du6', '103.171.172.58', 1724146952, '__ci_last_regenerate|i:1724146952;_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('93f7mja95h7glt2tkf7j6tiifaaau1t4', '192.175.111.243', 1724147517, '__ci_last_regenerate|i:1724147517;_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9fs7e2gd3j4lonlnk324nenfcgce9u5q', '34.248.137.227', 1724155975, '__ci_last_regenerate|i:1724155975;red_url|s:33:\"https://erp.alraedautomobile.com/\";_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9gofnv99btcm2p22mh6g423829vf8ccg', '45.140.205.67', 1724146923, '__ci_last_regenerate|i:1724146923;_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9k9m2g8pogqatl30n07jsa6tot8e7emr', '93.177.119.64', 1724146923, '__ci_last_regenerate|i:1724146923;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9ot5nvboq0kt0mqdagohu24fmquahg52', '205.169.39.195', 1724145251, '__ci_last_regenerate|i:1724145251;red_url|s:33:\"https://erp.alraedautomobile.com/\";_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9rnaa6me4neb809igae6vuqehpu7mlnr', '176.202.10.165', 1724160468, '__ci_last_regenerate|i:1724160468;_prev_url|s:65:\"https://erp.alraedautomobile.com/admin/estimates/list_estimates/1\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9vhvenhm6990mvhacvlht8l0c75oo1kf', '45.87.9.220', 1724145288, '__ci_last_regenerate|i:1724145287;is_mobile|b:1;red_url|s:33:\"https://erp.alraedautomobile.com/\";_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('acvo58o5mojsvna9nskt4mqgpfuj47s6', '176.202.10.165', 1724158051, '__ci_last_regenerate|i:1724158051;_prev_url|s:44:\"https://erp.alraedautomobile.com/admin/leads\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('agme5ibat9v1dmfj3snusncicr4qh9e4', '176.202.10.165', 1724159821, '__ci_last_regenerate|i:1724159821;_prev_url|s:44:\"https://erp.alraedautomobile.com/admin/leads\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('am1ga3j7l1mj4tc3suju5b8s6nqangk6', '154.28.229.216', 1724189809, '__ci_last_regenerate|i:1724189809;red_url|s:33:\"https://erp.alraedautomobile.com/\";_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b7u0tup8fqq71ma3lanjf5bf7otk6ld8', '102.0.7.248', 1724146939, '__ci_last_regenerate|i:1724146939;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ba86d8p1if9iibs9ba787bethi0nelej', '2001:41d0:602:b8::', 1724152764, '__ci_last_regenerate|i:1724152759;red_url|s:38:\"https://erp.alraedautomobile.com/admin\";_prev_url|s:53:\"https://erp.alraedautomobile.com/admin/authentication\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bf5rd2966molair4ljvnpq06ejrf2d6d', '176.202.10.165', 1724167941, '__ci_last_regenerate|i:1724167941;_prev_url|s:55:\"https://erp.alraedautomobile.com/admin/clients/client/2\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"d6f40605d1ea422b575b70cf0010bd32\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:43:\"/home/alraed/erp.alraedautomobile.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-chf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-czhf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cjhf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cJhf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:18:\"application/x-gzip\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:19:\"application/x-bzip2\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:16:\"application/x-xz\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:15:\"application/zip\";a:5:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";s:7:\"getsize\";a:3:{s:4:\"argc\";s:5:\"-Z -t\";s:5:\"regex\";s:21:\"/^.+?,\\s?([0-9]+).+$/\";s:7:\"replace\";s:2:\"$1\";}}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:50:\"/home/alraed/erp.alraedautomobile.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1724161982;}elFinderNetVolumes|a:0:{}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bg69b6ml0charu1vg3l36m25bchr02qg', '106.75.17.115', 1724294027, '__ci_last_regenerate|i:1724294027;_prev_url|s:64:\"https://erp.alraedautomobile.com/authentication/login/robots.txt\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bnhpm0vj6jo3doo66ke4a90r49lbt884', '2604:a880:400:d0::2309:5001', 1724145178, '__ci_last_regenerate|i:1724145178;is_mobile|b:1;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('brsfmusm0vk60bsj44a3hfhmocia3rdf', '14.229.14.173', 1724146950, '__ci_last_regenerate|i:1724146950;_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('btf89bgrcm1mv297capljs3l033nhl69', '38.47.39.37', 1724146945, '__ci_last_regenerate|i:1724146945;_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c06aoq5d2mpq9rpvq30ju0ublp0sp0au', '212.70.108.7', 1724142817, '__ci_last_regenerate|i:1724142817;_prev_url|s:43:\"https://erp.alraedautomobile.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c3m7k8k3sd2hmo4ce9qvhnbjgli0kpcj', '192.175.111.251', 1724147518, '__ci_last_regenerate|i:1724147518;_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c866vrgq3fa1h215vj8p0em1retu7330', '47.254.85.182', 1724189267, '__ci_last_regenerate|i:1724189267;is_mobile|b:1;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cftip81nuhdk9fm8l37ba048fid7d4i8', '176.202.10.165', 1724161907, '__ci_last_regenerate|i:1724161907;_prev_url|s:67:\"https://erp.alraedautomobile.com/admin/accounting/chart_of_accounts\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cg3j92il7jp9miinv5s53e583q499jc5', '2001:41d0:602:b8::', 1724151254, '__ci_last_regenerate|i:1724151247;red_url|s:38:\"https://erp.alraedautomobile.com/admin\";_prev_url|s:53:\"https://erp.alraedautomobile.com/admin/authentication\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cie8rbfh4p4fssir20bpgpfq4kf18ct1', '134.122.88.193', 1724313043, '__ci_last_regenerate|i:1724313042;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cjilh3b0i1ogt6knuod1mjvomi5v8ncv', '34.105.219.249', 1724140213, '__ci_last_regenerate|i:1724140212;red_url|s:45:\"https://erp.alraedautomobile.com/admin/backup\";_prev_url|s:53:\"https://erp.alraedautomobile.com/admin/authentication\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cjmcutuh87ddrd13icsojl349ns2espo', '176.202.10.165', 1724162065, '__ci_last_regenerate|i:1724162065;_prev_url|s:59:\"https://erp.alraedautomobile.com/admin/menu_setup/main_menu\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"d6f40605d1ea422b575b70cf0010bd32\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:43:\"/home/alraed/erp.alraedautomobile.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-chf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-czhf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cjhf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cJhf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:18:\"application/x-gzip\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:19:\"application/x-bzip2\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:16:\"application/x-xz\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:15:\"application/zip\";a:5:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";s:7:\"getsize\";a:3:{s:4:\"argc\";s:5:\"-Z -t\";s:5:\"regex\";s:21:\"/^.+?,\\s?([0-9]+).+$/\";s:7:\"replace\";s:2:\"$1\";}}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:50:\"/home/alraed/erp.alraedautomobile.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1724161982;}elFinderNetVolumes|a:0:{}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('co5l63gfdrcqpcv7i82316gkhl08t9dd', '205.169.39.0', 1724145254, '__ci_last_regenerate|i:1724145251;red_url|s:33:\"https://erp.alraedautomobile.com/\";_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ctvuc4860lnb92ac3j7d0s2rfj0888dt', '103.216.50.20', 1724146944, '__ci_last_regenerate|i:1724146944;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d99v6glqqpusqabod35h2v8155i57h86', '113.162.84.219', 1724146938, '__ci_last_regenerate|i:1724146938;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('db2pchntjvrv6tntb1ehr6nj6lqunlmi', '102.216.68.22', 1724146950, '__ci_last_regenerate|i:1724146950;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dfogdstu1vm8rsf9o15v5ac3kle6uf7q', '34.105.219.249', 1724142252, '__ci_last_regenerate|i:1724142252;_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('djgojsm6q77cmh5vkvut83mkjg5et4fp', '176.202.10.165', 1724172035, '__ci_last_regenerate|i:1724172035;_prev_url|s:57:\"https://erp.alraedautomobile.com/admin/estimates/estimate\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"d6f40605d1ea422b575b70cf0010bd32\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:43:\"/home/alraed/erp.alraedautomobile.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-chf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-czhf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cjhf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cJhf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:18:\"application/x-gzip\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:19:\"application/x-bzip2\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:16:\"application/x-xz\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:15:\"application/zip\";a:5:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";s:7:\"getsize\";a:3:{s:4:\"argc\";s:5:\"-Z -t\";s:5:\"regex\";s:21:\"/^.+?,\\s?([0-9]+).+$/\";s:7:\"replace\";s:2:\"$1\";}}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:50:\"/home/alraed/erp.alraedautomobile.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1724161982;}elFinderNetVolumes|a:0:{}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dk1hbe1smh1qgct1ftv3ch5o772ar86c', '176.202.10.165', 1724157617, '__ci_last_regenerate|i:1724157617;red_url|s:38:\"https://erp.alraedautomobile.com/admin\";_prev_url|s:53:\"https://erp.alraedautomobile.com/admin/authentication\";message-danger|s:25:\"Invalid email or password\";__ci_vars|a:1:{s:14:\"message-danger\";s:3:\"old\";}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e0g9efsbhun40kf102plifs0ku2oag3v', '176.202.10.165', 1724233191, '__ci_last_regenerate|i:1724233191;_prev_url|s:63:\"https://erp.alraedautomobile.com/admin/invoices/list_invoices/2\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e0ogi4c3k6qki8aisbg7f33n9607t7f0', '34.105.219.249', 1724140197, '__ci_last_regenerate|i:1724140196;red_url|s:62:\"https://erp.alraedautomobile.com/admin/modules/activate/backup\";_prev_url|s:53:\"https://erp.alraedautomobile.com/admin/authentication\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e5jkodco3f4jcmc1n3msfptnd818qsrd', '34.105.219.249', 1724140202, '__ci_last_regenerate|i:1724140202;red_url|s:63:\"https://erp.alraedautomobile.com/admin/modules/activate/exports\";_prev_url|s:53:\"https://erp.alraedautomobile.com/admin/authentication\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e7vhpi2n5rr92eirn42p8got060uclbo', '52.81.78.71', 1724180675, '__ci_last_regenerate|i:1724180675;_prev_url|s:64:\"https://erp.alraedautomobile.com/authentication/login/robots.txt\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eakga8drqemnf5etmij7avckrbe8sabc', '45.87.9.173', 1724468832, '__ci_last_regenerate|i:1724468831;is_mobile|b:1;red_url|s:33:\"https://erp.alraedautomobile.com/\";_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ejhcc3rd5nbk5tu47rght666sj5l5sh9', '34.105.219.249', 1724140091, '__ci_last_regenerate|i:1724140091;red_url|s:53:\"https://erp.alraedautomobile.com/admin/modules/upload\";_prev_url|s:53:\"https://erp.alraedautomobile.com/admin/authentication\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eqoib4qi5i7q4618da8r14cbs0korfj9', '176.202.10.165', 1724172670, '__ci_last_regenerate|i:1724172670;_prev_url|s:57:\"https://erp.alraedautomobile.com/admin/estimates/estimate\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"d6f40605d1ea422b575b70cf0010bd32\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:43:\"/home/alraed/erp.alraedautomobile.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-chf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-czhf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cjhf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cJhf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:18:\"application/x-gzip\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:19:\"application/x-bzip2\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:16:\"application/x-xz\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:15:\"application/zip\";a:5:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";s:7:\"getsize\";a:3:{s:4:\"argc\";s:5:\"-Z -t\";s:5:\"regex\";s:21:\"/^.+?,\\s?([0-9]+).+$/\";s:7:\"replace\";s:2:\"$1\";}}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:50:\"/home/alraed/erp.alraedautomobile.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1724161982;}elFinderNetVolumes|a:0:{}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f0hht3pemon7piteb4jbl3dibip63f0u', '106.75.17.115', 1724294018, '__ci_last_regenerate|i:1724294018;_prev_url|s:64:\"https://erp.alraedautomobile.com/authentication/login/robots.txt\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f16fdn0l3b5gnfdbbr1rp7mqc8sqarct', '176.202.10.165', 1724160126, '__ci_last_regenerate|i:1724160126;_prev_url|s:76:\"https://erp.alraedautomobile.com/proposal/1/74edd1bbb96803328c6f94f9e633aaf0\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f974dqds1s2drgti31jd19lc1ol8pcr7', '176.202.10.165', 1724169628, '__ci_last_regenerate|i:1724169628;_prev_url|s:58:\"https://erp.alraedautomobile.com/admin/custom_fields/field\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"d6f40605d1ea422b575b70cf0010bd32\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:43:\"/home/alraed/erp.alraedautomobile.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-chf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-czhf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cjhf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cJhf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:18:\"application/x-gzip\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:19:\"application/x-bzip2\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:16:\"application/x-xz\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:15:\"application/zip\";a:5:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";s:7:\"getsize\";a:3:{s:4:\"argc\";s:5:\"-Z -t\";s:5:\"regex\";s:21:\"/^.+?,\\s?([0-9]+).+$/\";s:7:\"replace\";s:2:\"$1\";}}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:50:\"/home/alraed/erp.alraedautomobile.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1724161982;}elFinderNetVolumes|a:0:{}message-success|s:32:\"Custom field added successfully.\";__ci_vars|a:1:{s:15:\"message-success\";s:3:\"new\";}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fbma1vstgkvh1enhp3bt919ll6e0jp0e', '104.166.80.79', 1724157822, '__ci_last_regenerate|i:1724157822;red_url|s:33:\"https://erp.alraedautomobile.com/\";_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fds3f3pqit2950alfk7njjekqdd82d5p', '212.119.45.133', 1724146923, '__ci_last_regenerate|i:1724146923;_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ffqu9jg2a9jn8731hhfn3aqojd1dmj6u', '223.113.128.201', 1724293938, '__ci_last_regenerate|i:1724293938;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fivh1t8d0e2ibqtiv8tip52mdh56kfuv', '176.202.10.165', 1724152938, '__ci_last_regenerate|i:1724152938;red_url|s:33:\"https://erp.alraedautomobile.com/\";_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fk5tpcbn5lam1s5fg1hiceq8qhifqram', '106.75.17.115', 1724294018, '__ci_last_regenerate|i:1724294018;_prev_url|s:65:\"https://erp.alraedautomobile.com/authentication/login/sitemap.xml\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fqjhbg3eouj05bjra2titr9ovac41n19', '47.88.94.28', 1724190329, '__ci_last_regenerate|i:1724190329;is_mobile|b:1;_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('frfrk13f4rn2f99laieirooldnglr9sh', '45.87.9.109', 1724220436, '__ci_last_regenerate|i:1724220435;is_mobile|b:1;red_url|s:33:\"https://erp.alraedautomobile.com/\";_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fv63s741m5a27el1qdsrsn53dddcafq9', '2604:a880:800:10::d4e:a001', 1724145178, '__ci_last_regenerate|i:1724145178;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('g4jfg8j67nqv4p4kg2iu9bn9mr08krv6', '176.202.10.165', 1724162756, '__ci_last_regenerate|i:1724162756;_prev_url|s:51:\"https://erp.alraedautomobile.com/admin/paymentmodes\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"d6f40605d1ea422b575b70cf0010bd32\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:43:\"/home/alraed/erp.alraedautomobile.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-chf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-czhf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cjhf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cJhf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:18:\"application/x-gzip\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:19:\"application/x-bzip2\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:16:\"application/x-xz\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:15:\"application/zip\";a:5:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";s:7:\"getsize\";a:3:{s:4:\"argc\";s:5:\"-Z -t\";s:5:\"regex\";s:21:\"/^.+?,\\s?([0-9]+).+$/\";s:7:\"replace\";s:2:\"$1\";}}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:50:\"/home/alraed/erp.alraedautomobile.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1724161982;}elFinderNetVolumes|a:0:{}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('g4kutm0o333kltrom2fm9nd4u6k619ac', '176.202.10.165', 1724159177, '__ci_last_regenerate|i:1724159177;_prev_url|s:61:\"https://erp.alraedautomobile.com/admin/knowledge_base/article\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('g5st4r43ho1j0noc96tmj0jmefj7ot90', '154.28.229.216', 1724189817, '__ci_last_regenerate|i:1724189811;red_url|s:33:\"https://erp.alraedautomobile.com/\";_prev_url|s:63:\"https://erp.alraedautomobile.com/authentication/forgot_password\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gjbp69oshv61ir5q5tm0nuo257qlc129', '176.202.10.165', 1724225176, '__ci_last_regenerate|i:1724225176;red_url|s:48:\"https://erp.alraedautomobile.com/admin/estimates\";_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gk8oi8pj4aaplhgr36ecbetav53pno89', '176.202.10.165', 1724159790, '__ci_last_regenerate|i:1724159790;_prev_url|s:62:\"https://erp.alraedautomobile.com/admin/settings?group=calendar\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('h015lt7567p6f1u7ab5rsh1lvrap2q2g', '176.202.10.165', 1724143372, '__ci_last_regenerate|i:1724143372;red_url|s:33:\"https://erp.alraedautomobile.com/\";_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hke7rdbu29m0s04epm3gv5b1eghvkkqa', '176.202.10.165', 1724162604, '__ci_last_regenerate|i:1724162469;_prev_url|s:52:\"https://erp.alraedautomobile.com/admin/reports/leads\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hl9ogr4k8vb9urdqnlr3j9dpe2vlpiau', '51.81.46.212', 1724161601, '__ci_last_regenerate|i:1724161601;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hp8v9kietq5b5ahfj9p31tqsaafp0qep', '34.105.219.249', 1724139767, '__ci_last_regenerate|i:1724139767;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hs5dle7b8pkkd5or4agll58kp0ver1fv', '2604:a880:400:d0::2309:5001', 1724145178, '__ci_last_regenerate|i:1724145178;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hv2to7p2m24rjvbfblmc62rcd57p5lnr', '176.202.10.165', 1724164667, '__ci_last_regenerate|i:1724164667;_prev_url|s:58:\"https://erp.alraedautomobile.com/admin/accounting/new_rule\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"d6f40605d1ea422b575b70cf0010bd32\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:43:\"/home/alraed/erp.alraedautomobile.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-chf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-czhf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cjhf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cJhf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:18:\"application/x-gzip\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:19:\"application/x-bzip2\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:16:\"application/x-xz\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:15:\"application/zip\";a:5:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";s:7:\"getsize\";a:3:{s:4:\"argc\";s:5:\"-Z -t\";s:5:\"regex\";s:21:\"/^.+?,\\s?([0-9]+).+$/\";s:7:\"replace\";s:2:\"$1\";}}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:50:\"/home/alraed/erp.alraedautomobile.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1724161982;}elFinderNetVolumes|a:0:{}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('i5au0b4liq0m29ffhuum44g3kmvc6288', '52.81.78.71', 1724293953, '__ci_last_regenerate|i:1724293953;_prev_url|s:65:\"https://erp.alraedautomobile.com/authentication/login/sitemap.xml\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('icbgfhot3hroudlk7bi0bt88thhdrltb', '176.202.10.165', 1724164361, '__ci_last_regenerate|i:1724164361;_prev_url|s:49:\"https://erp.alraedautomobile.com/admin/roles/role\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"d6f40605d1ea422b575b70cf0010bd32\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:43:\"/home/alraed/erp.alraedautomobile.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-chf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-czhf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cjhf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cJhf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:18:\"application/x-gzip\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:19:\"application/x-bzip2\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:16:\"application/x-xz\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:15:\"application/zip\";a:5:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";s:7:\"getsize\";a:3:{s:4:\"argc\";s:5:\"-Z -t\";s:5:\"regex\";s:21:\"/^.+?,\\s?([0-9]+).+$/\";s:7:\"replace\";s:2:\"$1\";}}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:50:\"/home/alraed/erp.alraedautomobile.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1724161982;}elFinderNetVolumes|a:0:{}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('if8p46hlug7ilqo7fjqss0215l3bp1ub', '176.202.10.165', 1724158155, '__ci_last_regenerate|i:1724158155;_prev_url|s:47:\"https://erp.alraedautomobile.com/admin/settings\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ighsan6jj48r2kiak9kqfe7emjp47fnl', '34.145.227.243', 1724139865, '__ci_last_regenerate|i:1724139865;red_url|s:33:\"https://erp.alraedautomobile.com/\";_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ikl2qtk2pjeac98t6s9tkjkrgd7jitl1', '103.81.118.194', 1724146936, '__ci_last_regenerate|i:1724146936;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('inc7fq5v2cv3ak3rt5in77r612ir69ep', '51.81.46.212', 1724161601, '__ci_last_regenerate|i:1724161601;_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('iui9k3run7npifjvtb17s2a9mj6mql4m', '34.105.219.249', 1724142750, '__ci_last_regenerate|i:1724142750;red_url|s:47:\"https://erp.alraedautomobile.com/admin/settings\";_prev_url|s:53:\"https://erp.alraedautomobile.com/admin/authentication\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('j6rdh84eecnv18t9i2eo7a98id1dj5kl', '195.211.77.142', 1724145204, '__ci_last_regenerate|i:1724145204;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jehejdvf7b1npcgbjkaoc405akgjd49j', '104.166.80.79', 1724157823, '__ci_last_regenerate|i:1724157823;red_url|s:33:\"https://erp.alraedautomobile.com/\";_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jingc5im77kob67j9tofv37clg9bl1ie', '223.113.128.201', 1724293938, '__ci_last_regenerate|i:1724293938;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jjcqutvqpcb7plujk3ovsuu4cbpt955d', '68.66.220.30', 1724302806, '__ci_last_regenerate|i:1724302805;_prev_url|s:43:\"https://erp.alraedautomobile.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jln4bmfdip4nfe55ud5aublqlup75n6t', '2604:a880:400:d0::24c8:8001', 1724145178, '__ci_last_regenerate|i:1724145178;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jml453ufgbovjk768bv5hmlh61fa8o69', '52.81.78.71', 1724180673, '__ci_last_regenerate|i:1724180673;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jo2b2kmi3ffo7udao9a31atdjar4vvn5', '106.75.17.115', 1724294027, '__ci_last_regenerate|i:1724294027;_prev_url|s:65:\"https://erp.alraedautomobile.com/authentication/login/sitemap.xml\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jpt4occtt9uq3l4k006tntlrue1a01lu', '34.105.219.249', 1724142885, '__ci_last_regenerate|i:1724142885;red_url|s:72:\"https://erp.alraedautomobile.com/admin/backup/update_auto_backup_options\";_prev_url|s:53:\"https://erp.alraedautomobile.com/admin/authentication\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('k9doudmc07f4rctgni2c9lna5d7ndrvt', '204.85.30.68', 1724157676, '__ci_last_regenerate|i:1724157676;red_url|s:38:\"https://erp.alraedautomobile.com/admin\";_prev_url|s:53:\"https://erp.alraedautomobile.com/admin/authentication\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kbqgqtkfeefu28lt5nfiee3bjseho0tm', '45.140.205.208', 1724146923, '__ci_last_regenerate|i:1724146923;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('klnvgu563g9iht6cs3dmmqosesgk6k42', '194.104.8.144', 1724151339, '__ci_last_regenerate|i:1724151339;red_url|s:33:\"https://erp.alraedautomobile.com/\";_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('knc6gl5troe608esn16ukr5jpu1imn4t', '34.105.219.249', 1724140213, '__ci_last_regenerate|i:1724140212;red_url|s:45:\"https://erp.alraedautomobile.com/admin/backup\";_prev_url|s:53:\"https://erp.alraedautomobile.com/admin/authentication\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kscff7sqbuicv88qi6cjc4jb3guu5edf', '45.140.205.43', 1724146923, '__ci_last_regenerate|i:1724146923;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l1r39699keslnk1c82tuuqoji59an9hg', '18.144.74.167', 1724145251, '__ci_last_regenerate|i:1724145251;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lhp6uq5vp8f53pv6tq7r4gl49sc9c9gu', '34.133.138.57', 1724145319, '__ci_last_regenerate|i:1724145319;red_url|s:33:\"https://erp.alraedautomobile.com/\";_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lml214lbcjiqo9kv15tqb5vfautqnkef', '176.202.10.165', 1724171282, '__ci_last_regenerate|i:1724171282;_prev_url|s:61:\"https://erp.alraedautomobile.com/admin/settings?group=general\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"d6f40605d1ea422b575b70cf0010bd32\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:43:\"/home/alraed/erp.alraedautomobile.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-chf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-czhf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cjhf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cJhf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:18:\"application/x-gzip\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:19:\"application/x-bzip2\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:16:\"application/x-xz\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:15:\"application/zip\";a:5:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";s:7:\"getsize\";a:3:{s:4:\"argc\";s:5:\"-Z -t\";s:5:\"regex\";s:21:\"/^.+?,\\s?([0-9]+).+$/\";s:7:\"replace\";s:2:\"$1\";}}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:50:\"/home/alraed/erp.alraedautomobile.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1724161982;}elFinderNetVolumes|a:0:{}message-success|s:16:\"Settings Updated\";__ci_vars|a:1:{s:15:\"message-success\";s:3:\"old\";}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ln9763tfu4hpfm7cl94c5rdqsuvul4ir', '223.113.128.201', 1724293929, '__ci_last_regenerate|i:1724293928;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lo1kupnss53hggq3vk5p9drp9bb95j9u', '34.248.137.227', 1724155975, '__ci_last_regenerate|i:1724155975;red_url|s:33:\"https://erp.alraedautomobile.com/\";_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lqmie2cf83osja6u7hkjkhlud49mpq63', '176.202.10.165', 1724165009, '__ci_last_regenerate|i:1724165009;_prev_url|s:93:\"https://erp.alraedautomobile.com/admin/accounting/setting?group=income_statement_modification\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"d6f40605d1ea422b575b70cf0010bd32\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:43:\"/home/alraed/erp.alraedautomobile.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-chf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-czhf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cjhf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cJhf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:18:\"application/x-gzip\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:19:\"application/x-bzip2\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:16:\"application/x-xz\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:15:\"application/zip\";a:5:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";s:7:\"getsize\";a:3:{s:4:\"argc\";s:5:\"-Z -t\";s:5:\"regex\";s:21:\"/^.+?,\\s?([0-9]+).+$/\";s:7:\"replace\";s:2:\"$1\";}}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:50:\"/home/alraed/erp.alraedautomobile.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1724161982;}elFinderNetVolumes|a:0:{}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('m8l01scuaa09bopoik0b598p81sov2np', '176.202.10.165', 1724159399, '__ci_last_regenerate|i:1724159399;_prev_url|s:70:\"https://erp.alraedautomobile.com/admin/settings?group=payment_gateways\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mao8vaad3l08rj6ca4psa9sgpdpu406j', '52.81.78.71', 1724180690, '__ci_last_regenerate|i:1724180690;_prev_url|s:65:\"https://erp.alraedautomobile.com/authentication/login/sitemap.xml\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mg14nv60pmj810blsuqqgp719v57v22m', '176.202.10.165', 1724226676, '__ci_last_regenerate|i:1724226676;_prev_url|s:51:\"https://erp.alraedautomobile.com/admin/paymentmodes\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mg7vh6k6k1it9e7dfrm5tnnn2q9o7le6', '176.202.10.165', 1724231511, '__ci_last_regenerate|i:1724231511;_prev_url|s:61:\"https://erp.alraedautomobile.com/admin/settings?group=general\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;red_url|s:33:\"https://erp.alraedautomobile.com/\";debug|s:103:\"Logo or Favicon change detected. If you still see the original CRM logo try to clear your browser cache\";__ci_vars|a:1:{s:5:\"debug\";s:3:\"old\";}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mhqpq1rsift9blfrm82j9g2tsajo9ipc', '106.75.17.115', 1724294016, '__ci_last_regenerate|i:1724294016;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ms3e63r6gk0csjtrkqjudc7jffj33r8n', '176.202.10.165', 1724170241, '__ci_last_regenerate|i:1724170241;_prev_url|s:38:\"https://erp.alraedautomobile.com/admin\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"d6f40605d1ea422b575b70cf0010bd32\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:43:\"/home/alraed/erp.alraedautomobile.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-chf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-czhf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cjhf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cJhf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:18:\"application/x-gzip\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:19:\"application/x-bzip2\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:16:\"application/x-xz\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:15:\"application/zip\";a:5:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";s:7:\"getsize\";a:3:{s:4:\"argc\";s:5:\"-Z -t\";s:5:\"regex\";s:21:\"/^.+?,\\s?([0-9]+).+$/\";s:7:\"replace\";s:2:\"$1\";}}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:50:\"/home/alraed/erp.alraedautomobile.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1724161982;}elFinderNetVolumes|a:0:{}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('msn4r4u9jls640svp38mt0fg9v43a5t2', '195.211.77.140', 1724145197, '__ci_last_regenerate|i:1724145197;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mss827evl96psv16v6se4nj4aik1jlas', '34.105.219.249', 1724140103, '__ci_last_regenerate|i:1724140102;red_url|s:66:\"https://erp.alraedautomobile.com/admin/modules/activate/accounting\";_prev_url|s:53:\"https://erp.alraedautomobile.com/admin/authentication\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nf95vke3tos2fnprerkjr4ejnbc94nt5', '47.254.85.182', 1724189268, '__ci_last_regenerate|i:1724189268;is_mobile|b:1;_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ni9pfls6kd9isuhjopl0nisfetd6bv9p', '35.187.232.113', 1724140895, '__ci_last_regenerate|i:1724140895;red_url|s:59:\"https://erp.alraedautomobile.com/admin/accounting/dashboard\";_prev_url|s:53:\"https://erp.alraedautomobile.com/admin/authentication\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nltid106f6ud8mmj4biqn3v0pmnir6lf', '176.202.10.165', 1724163297, '__ci_last_regenerate|i:1724163297;_prev_url|s:58:\"https://erp.alraedautomobile.com/admin/expenses/categories\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"d6f40605d1ea422b575b70cf0010bd32\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:43:\"/home/alraed/erp.alraedautomobile.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-chf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-czhf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cjhf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cJhf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:18:\"application/x-gzip\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:19:\"application/x-bzip2\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:16:\"application/x-xz\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:15:\"application/zip\";a:5:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";s:7:\"getsize\";a:3:{s:4:\"argc\";s:5:\"-Z -t\";s:5:\"regex\";s:21:\"/^.+?,\\s?([0-9]+).+$/\";s:7:\"replace\";s:2:\"$1\";}}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:50:\"/home/alraed/erp.alraedautomobile.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1724161982;}elFinderNetVolumes|a:0:{}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nlvcvc5mo536p4fl9k5brvtn86hj6oqm', '34.105.219.249', 1724140206, '__ci_last_regenerate|i:1724140206;red_url|s:66:\"https://erp.alraedautomobile.com/admin/modules/activate/menu_setup\";_prev_url|s:53:\"https://erp.alraedautomobile.com/admin/authentication\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('npm13pd0p75q4c39u2vf1afk0mfhcd80', '133.242.174.119', 1724158277, '__ci_last_regenerate|i:1724158276;is_mobile|b:1;red_url|s:33:\"https://erp.alraedautomobile.com/\";_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nste4t71cmunm0tl7dgfesr7e846m55s', '2a01:4f8:10a:2d6::2', 1724146947, '__ci_last_regenerate|i:1724146946;is_mobile|b:1;red_url|s:33:\"https://erp.alraedautomobile.com/\";_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o874epg07efq8a7k7fdrvv16bsfak7f3', '34.105.219.249', 1724140215, '__ci_last_regenerate|i:1724140215;red_url|s:60:\"https://erp.alraedautomobile.com/admin/backup/make_backup_db\";_prev_url|s:53:\"https://erp.alraedautomobile.com/admin/authentication\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o8cijs8rpa2aatb2j62qiom2pmqd5kmu', '104.253.214.226', 1724145406, '__ci_last_regenerate|i:1724145406;is_mobile|b:1;red_url|s:33:\"https://erp.alraedautomobile.com/\";_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('opph4oj7up0svuptli19ar3ovosjqul6', '34.105.219.249', 1724140062, '__ci_last_regenerate|i:1724140062;red_url|s:46:\"https://erp.alraedautomobile.com/admin/modules\";_prev_url|s:53:\"https://erp.alraedautomobile.com/admin/authentication\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ovmq1qhk14u0iacmsfner368tak83t9n', '2001:41d0:602:b8::', 1724152695, '__ci_last_regenerate|i:1724152689;red_url|s:38:\"https://erp.alraedautomobile.com/admin\";_prev_url|s:53:\"https://erp.alraedautomobile.com/admin/authentication\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('p0rp4837pvt90cj2oclftclqg019upoj', '176.202.10.165', 1724165900, '__ci_last_regenerate|i:1724165900;_prev_url|s:68:\"https://erp.alraedautomobile.com/admin/accounting/create_plaid_token\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"d6f40605d1ea422b575b70cf0010bd32\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:43:\"/home/alraed/erp.alraedautomobile.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-chf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-czhf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cjhf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cJhf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:18:\"application/x-gzip\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:19:\"application/x-bzip2\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:16:\"application/x-xz\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:15:\"application/zip\";a:5:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";s:7:\"getsize\";a:3:{s:4:\"argc\";s:5:\"-Z -t\";s:5:\"regex\";s:21:\"/^.+?,\\s?([0-9]+).+$/\";s:7:\"replace\";s:2:\"$1\";}}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:50:\"/home/alraed/erp.alraedautomobile.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1724161982;}elFinderNetVolumes|a:0:{}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('p6hpnirsn6q50pisalc7ril845e36erg', '83.142.55.115', 1724146923, '__ci_last_regenerate|i:1724146923;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('p83m3fvm9q7l100rdes181bi92hhmeaf', '94.139.233.80', 1724220490, '__ci_last_regenerate|i:1724220489;is_mobile|b:1;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pe09oo7k14bsbbsmeqt7pbp8rei1005p', '45.201.199.142', 1724146952, '__ci_last_regenerate|i:1724146952;_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pfdndg84pegmhq2aeq5i2c0kco1t2uq9', '176.202.10.165', 1724231187, '__ci_last_regenerate|i:1724231187;_prev_url|s:68:\"https://erp.alraedautomobile.com/admin/estimates/pdf/5?output_type=I\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qjhirhbhbtanmpepa2nfra51me78t1pp', '176.202.10.165', 1724157662, '__ci_last_regenerate|i:1724157661;red_url|s:38:\"https://erp.alraedautomobile.com/admin\";_prev_url|s:53:\"https://erp.alraedautomobile.com/admin/authentication\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qlvdtra3lu7fjva116qeo8ntb3oh8etl', '2001:861:3007:42a0:9cca:edda:9dea:87b7', 1724228331, '__ci_last_regenerate|i:1724228331;is_mobile|b:1;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qn6hk17cjfqarnqfobvjg6u7sim7baot', '212.70.108.7', 1724153260, '__ci_last_regenerate|i:1724153260;_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qv8p73sffgupbknrinqije4jiuucgkvp', '176.202.10.165', 1724163916, '__ci_last_regenerate|i:1724163916;_prev_url|s:49:\"https://erp.alraedautomobile.com/admin/roles/role\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"d6f40605d1ea422b575b70cf0010bd32\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:43:\"/home/alraed/erp.alraedautomobile.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-chf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-czhf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cjhf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cJhf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:18:\"application/x-gzip\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:19:\"application/x-bzip2\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:16:\"application/x-xz\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:15:\"application/zip\";a:5:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";s:7:\"getsize\";a:3:{s:4:\"argc\";s:5:\"-Z -t\";s:5:\"regex\";s:21:\"/^.+?,\\s?([0-9]+).+$/\";s:7:\"replace\";s:2:\"$1\";}}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:50:\"/home/alraed/erp.alraedautomobile.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1724161982;}elFinderNetVolumes|a:0:{}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qvu41cfl4hdjrk5q6qsol8b0kfvh73r7', '176.202.10.165', 1724230871, '__ci_last_regenerate|i:1724230871;_prev_url|s:54:\"https://erp.alraedautomobile.com/admin/estimates/pdf/4\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('r10kivk46detav5a5hckrdodcoij1b5c', '64.15.129.122', 1724147518, '__ci_last_regenerate|i:1724147518;_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rbv2i2g13hq1kl5n6g8r0u0cj8u8q23n', '212.70.108.7', 1724140892, '__ci_last_regenerate|i:1724140892;_prev_url|s:45:\"https://erp.alraedautomobile.com/admin/backup\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ren6sqriuqnmdl9sgkquqtsvkk4kr0e9', '171.244.43.14', 1724188407, '__ci_last_regenerate|i:1724188406;is_mobile|b:1;red_url|s:33:\"https://erp.alraedautomobile.com/\";_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rg1njvv3lv1l8lm6mpmpadul6s4al17e', '104.164.173.170', 1724146613, '__ci_last_regenerate|i:1724146611;red_url|s:33:\"https://erp.alraedautomobile.com/\";_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rgj5dgmsrh4q8sjqssgdvs2jt1lssr4b', '104.166.80.205', 1724150669, '__ci_last_regenerate|i:1724150668;red_url|s:33:\"https://erp.alraedautomobile.com/\";_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rkrru94bvofomac0d74iph9s6vd5vbd2', '192.175.111.251', 1724147518, '__ci_last_regenerate|i:1724147518;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rmksh6aue7hjl7qnuouqjkg521iejvpt', '45.87.9.94', 1724288694, '__ci_last_regenerate|i:1724288692;is_mobile|b:1;red_url|s:33:\"https://erp.alraedautomobile.com/\";_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rpjt4kh642lp4brqps3td6ulqhorp1ak', '205.169.39.195', 1724145261, '__ci_last_regenerate|i:1724145260;red_url|s:33:\"https://erp.alraedautomobile.com/\";_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ru6eq7jpd0pp689mmlroh01h6vgoikr7', '45.87.9.126', 1724386239, '__ci_last_regenerate|i:1724386238;is_mobile|b:1;red_url|s:33:\"https://erp.alraedautomobile.com/\";_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s3kv09vc0qtili4cmvaigovhmqlp536t', '176.202.10.165', 1724157682, '__ci_last_regenerate|i:1724157682;red_url|s:33:\"https://erp.alraedautomobile.com/\";_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s5mkh9cdqc3t1cg3gnei880llm9hlmo4', '212.70.108.7', 1724142578, '__ci_last_regenerate|i:1724142578;_prev_url|s:45:\"https://erp.alraedautomobile.com/admin/backup\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s60f3ogn294388ppecebmmpo4d1r7k01', '34.248.137.227', 1724155980, '__ci_last_regenerate|i:1724155979;_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('sctnpm4o34hi0e5r933151rbun3uedcu', '176.202.10.165', 1724249263, '__ci_last_regenerate|i:1724249263;_prev_url|s:38:\"https://erp.alraedautomobile.com/admin\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('sjh78gogjs6civv2lnvc3r9iopcud9eb', '192.175.111.249', 1724147518, '__ci_last_regenerate|i:1724147518;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('sloco6k3ekvti7p3a7bnqq1q2tk4e2k1', '176.202.10.165', 1724171592, '__ci_last_regenerate|i:1724171592;_prev_url|s:57:\"https://erp.alraedautomobile.com/admin/estimates/estimate\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"d6f40605d1ea422b575b70cf0010bd32\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:43:\"/home/alraed/erp.alraedautomobile.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-chf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-czhf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cjhf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cJhf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:18:\"application/x-gzip\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:19:\"application/x-bzip2\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:16:\"application/x-xz\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:15:\"application/zip\";a:5:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";s:7:\"getsize\";a:3:{s:4:\"argc\";s:5:\"-Z -t\";s:5:\"regex\";s:21:\"/^.+?,\\s?([0-9]+).+$/\";s:7:\"replace\";s:2:\"$1\";}}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:50:\"/home/alraed/erp.alraedautomobile.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1724161982;}elFinderNetVolumes|a:0:{}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('slrncia3uglka76t3fi8qldm4lmnrju8', '34.105.219.249', 1724139905, '__ci_last_regenerate|i:1724139904;red_url|s:47:\"https://erp.alraedautomobile.com/admin/settings\";_prev_url|s:53:\"https://erp.alraedautomobile.com/admin/authentication\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('stgapfsm2vtjjqrb1pc91g6dcm84dmvn', '176.202.10.165', 1724161708, '__ci_last_regenerate|i:1724161708;_prev_url|s:58:\"https://erp.alraedautomobile.com/admin/settings?group=info\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('su6mgvuem7ukfcf583h4qseme2vl8qgf', '176.202.10.165', 1724249265, '__ci_last_regenerate|i:1724249263;_prev_url|s:38:\"https://erp.alraedautomobile.com/admin\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tlfbf3522vjk3niev49uqgm4kir49no9', '68.66.220.30', 1724389208, '__ci_last_regenerate|i:1724389207;_prev_url|s:43:\"https://erp.alraedautomobile.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('u3kdkt3adj67ps8u2p2eru6sgt4iop4n', '176.202.10.165', 1724225677, '__ci_last_regenerate|i:1724225677;_prev_url|s:59:\"https://erp.alraedautomobile.com/admin/estimates/estimate/2\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('u4u2lb3bfisqko3bittsh8jskt3f8c6d', '64.15.129.104', 1724147518, '__ci_last_regenerate|i:1724147518;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ub8u30ppol6ph8avtmlunljr4grrl3k6', '176.202.10.165', 1724163612, '__ci_last_regenerate|i:1724163612;_prev_url|s:46:\"https://erp.alraedautomobile.com/admin/modules\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"d6f40605d1ea422b575b70cf0010bd32\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:43:\"/home/alraed/erp.alraedautomobile.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-chf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-czhf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cjhf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:5:\"-cJhf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:18:\"application/x-gzip\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:19:\"application/x-bzip2\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:16:\"application/x-xz\";a:5:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";s:7:\"getsize\";a:4:{s:4:\"argc\";s:4:\"-xvf\";s:6:\"toSpec\";s:17:\"--to-stdout|wc -c\";s:5:\"regex\";s:48:\"/^.+(?:\\r\\n|\\n|\\r)[^\\r\\n0-9]*([0-9]+)[^\\r\\n]*$/s\";s:7:\"replace\";s:2:\"$1\";}}s:15:\"application/zip\";a:5:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";s:7:\"getsize\";a:3:{s:4:\"argc\";s:5:\"-Z -t\";s:5:\"regex\";s:21:\"/^.+?,\\s?([0-9]+).+$/\";s:7:\"replace\";s:2:\"$1\";}}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:0:{}s:7:\"subdirs\";a:1:{s:50:\"/home/alraed/erp.alraedautomobile.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1724161982;}elFinderNetVolumes|a:0:{}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ue14cal2dj7ff03c3a0l1sdm2sikcrg6', '34.105.219.249', 1724140209, '__ci_last_regenerate|i:1724140209;red_url|s:67:\"https://erp.alraedautomobile.com/admin/modules/activate/theme_style\";_prev_url|s:53:\"https://erp.alraedautomobile.com/admin/authentication\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ufts1518sgb0unbuijgt7aae7qa0pbtn', '176.202.10.165', 1724160143, '__ci_last_regenerate|i:1724160143;_prev_url|s:57:\"https://erp.alraedautomobile.com/admin/settings?group=pdf\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;message-warning|s:20:\"No file was uploaded\";__ci_vars|a:2:{s:15:\"message-warning\";s:3:\"old\";s:15:\"message-success\";s:3:\"old\";}message-success|s:16:\"Settings Updated\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('uhom2mmrlniv3bjtb8h3jjt04g4l9ktn', '104.164.173.195', 1724192168, '__ci_last_regenerate|i:1724192165;red_url|s:33:\"https://erp.alraedautomobile.com/\";_prev_url|s:63:\"https://erp.alraedautomobile.com/authentication/forgot_password\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('uiu1i3dgvgtqo8771ajph3n6edq864jn', '2a03:b0c0:3:d0::d1a:1', 1724145178, '__ci_last_regenerate|i:1724145178;is_mobile|b:1;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('uplp8b25uigk88eikri2ko064qoabtd9', '2001:861:3007:42a0:9cca:edda:9dea:87b7', 1724228331, '__ci_last_regenerate|i:1724228331;is_mobile|b:1;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v3uagd25d6ict1lp1u5p10sa36gio6qm', '223.96.253.157', 1724146937, '__ci_last_regenerate|i:1724146937;_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v9bmn75nfutptt79k98bfg3eq0jmqt65', '212.70.108.7', 1724153260, '__ci_last_regenerate|i:1724153260;_prev_url|s:45:\"https://erp.alraedautomobile.com/admin/backup\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vgk3nbel326s1tv181ekni6v4ro6tkdg', '161.123.42.61', 1724220496, '__ci_last_regenerate|i:1724220496;is_mobile|b:1;_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vhc3ppkjlqd7170hmbacpgf28u9foqli', '107.172.166.241', 1724145405, '__ci_last_regenerate|i:1724145405;is_mobile|b:1;red_url|s:33:\"https://erp.alraedautomobile.com/\";_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vjk7e3kg4hnusl575vngu0m3f4b9rd25', '34.105.219.249', 1724139815, '__ci_last_regenerate|i:1724139815;_prev_url|s:53:\"https://erp.alraedautomobile.com/admin/authentication\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vln4jsm8kt17oqiuufldm1pbb1f89pq1', '103.206.130.90', 1724146940, '__ci_last_regenerate|i:1724146940;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vo33l2h01ntttvacjtsjgr22f774dlfe', '176.202.10.165', 1724162469, '__ci_last_regenerate|i:1724162469;_prev_url|s:48:\"https://erp.alraedautomobile.com/admin/estimates\";staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vp6kp5ib3n89r083279omnsd8ebv8epu', '52.81.78.71', 1724293951, '__ci_last_regenerate|i:1724293951;red_url|s:33:\"https://erp.alraedautomobile.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vstha3iq68qq910seg5uljth0pqmh9jo', '106.75.17.115', 1724294023, '__ci_last_regenerate|i:1724294023;_prev_url|s:53:\"https://erp.alraedautomobile.com/authentication/login\";');


#
# TABLE STRUCTURE FOR: tblshared_customer_files
#

DROP TABLE IF EXISTS `tblshared_customer_files`;

CREATE TABLE `tblshared_customer_files` (
  `file_id` int NOT NULL,
  `contact_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblspam_filters
#

DROP TABLE IF EXISTS `tblspam_filters`;

CREATE TABLE `tblspam_filters` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `rel_type` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblstaff
#

DROP TABLE IF EXISTS `tblstaff`;

CREATE TABLE `tblstaff` (
  `staffid` int NOT NULL AUTO_INCREMENT,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `firstname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `facebook` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `linkedin` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `phonenumber` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `skype` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `datecreated` datetime NOT NULL,
  `profile_image` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_ip` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_activity` datetime DEFAULT NULL,
  `last_password_change` datetime DEFAULT NULL,
  `new_pass_key` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `new_pass_key_requested` datetime DEFAULT NULL,
  `admin` int NOT NULL DEFAULT '0',
  `role` int DEFAULT NULL,
  `active` int NOT NULL DEFAULT '1',
  `default_language` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `direction` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `media_path_slug` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_not_staff` int NOT NULL DEFAULT '0',
  `hourly_rate` decimal(15,2) NOT NULL DEFAULT '0.00',
  `two_factor_auth_enabled` tinyint(1) DEFAULT '0',
  `two_factor_auth_code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `two_factor_auth_code_requested` datetime DEFAULT NULL,
  `email_signature` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `google_auth_secret` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`staffid`),
  KEY `firstname` (`firstname`),
  KEY `lastname` (`lastname`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tblstaff` (`staffid`, `email`, `firstname`, `lastname`, `facebook`, `linkedin`, `phonenumber`, `skype`, `password`, `datecreated`, `profile_image`, `last_ip`, `last_login`, `last_activity`, `last_password_change`, `new_pass_key`, `new_pass_key_requested`, `admin`, `role`, `active`, `default_language`, `direction`, `media_path_slug`, `is_not_staff`, `hourly_rate`, `two_factor_auth_enabled`, `two_factor_auth_code`, `two_factor_auth_code_requested`, `email_signature`, `google_auth_secret`) VALUES (1, 'alraedautomobile@dotswebsolution.com', 'Alraed', 'Automobile', NULL, NULL, NULL, NULL, '$2a$08$1tYGQ6AKGy2Kj4058POJtOsV9gSwrTTiH/pyCr5IoMFQ/ExD7FbdS', '2024-08-20 03:41:48', NULL, '176.202.10.165', '2024-08-21 10:26:34', '2024-08-21 17:07:45', NULL, NULL, NULL, 1, NULL, 1, NULL, NULL, NULL, 0, '0.00', 0, NULL, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: tblstaff_departments
#

DROP TABLE IF EXISTS `tblstaff_departments`;

CREATE TABLE `tblstaff_departments` (
  `staffdepartmentid` int NOT NULL AUTO_INCREMENT,
  `staffid` int NOT NULL,
  `departmentid` int NOT NULL,
  PRIMARY KEY (`staffdepartmentid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblstaff_permissions
#

DROP TABLE IF EXISTS `tblstaff_permissions`;

CREATE TABLE `tblstaff_permissions` (
  `staff_id` int NOT NULL,
  `feature` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `capability` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblsubscriptions
#

DROP TABLE IF EXISTS `tblsubscriptions`;

CREATE TABLE `tblsubscriptions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `description_in_item` tinyint(1) NOT NULL DEFAULT '0',
  `clientid` int NOT NULL,
  `date` date DEFAULT NULL,
  `terms` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `currency` int NOT NULL,
  `tax_id` int NOT NULL DEFAULT '0',
  `stripe_tax_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax_id_2` int NOT NULL DEFAULT '0',
  `stripe_tax_id_2` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stripe_plan_id` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `stripe_subscription_id` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `next_billing_cycle` bigint DEFAULT NULL,
  `ends_at` bigint DEFAULT NULL,
  `status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` int NOT NULL DEFAULT '1',
  `project_id` int NOT NULL DEFAULT '0',
  `hash` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `created_from` int NOT NULL,
  `date_subscribed` datetime DEFAULT NULL,
  `in_test_environment` int DEFAULT NULL,
  `last_sent_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `currency` (`currency`),
  KEY `tax_id` (`tax_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tbltaggables
#

DROP TABLE IF EXISTS `tbltaggables`;

CREATE TABLE `tbltaggables` (
  `rel_id` int NOT NULL,
  `rel_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tag_id` int NOT NULL,
  `tag_order` int NOT NULL DEFAULT '0',
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tbltags
#

DROP TABLE IF EXISTS `tbltags`;

CREATE TABLE `tbltags` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tbltask_assigned
#

DROP TABLE IF EXISTS `tbltask_assigned`;

CREATE TABLE `tbltask_assigned` (
  `id` int NOT NULL AUTO_INCREMENT,
  `staffid` int NOT NULL,
  `taskid` int NOT NULL,
  `assigned_from` int NOT NULL DEFAULT '0',
  `is_assigned_from_contact` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `taskid` (`taskid`),
  KEY `staffid` (`staffid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tbltask_checklist_items
#

DROP TABLE IF EXISTS `tbltask_checklist_items`;

CREATE TABLE `tbltask_checklist_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `taskid` int NOT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `finished` int NOT NULL DEFAULT '0',
  `dateadded` datetime NOT NULL,
  `addedfrom` int NOT NULL,
  `finished_from` int DEFAULT '0',
  `list_order` int NOT NULL DEFAULT '0',
  `assigned` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `taskid` (`taskid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tbltask_comments
#

DROP TABLE IF EXISTS `tbltask_comments`;

CREATE TABLE `tbltask_comments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `content` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `taskid` int NOT NULL,
  `staffid` int NOT NULL,
  `contact_id` int NOT NULL DEFAULT '0',
  `file_id` int NOT NULL DEFAULT '0',
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `file_id` (`file_id`),
  KEY `taskid` (`taskid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tbltask_followers
#

DROP TABLE IF EXISTS `tbltask_followers`;

CREATE TABLE `tbltask_followers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `staffid` int NOT NULL,
  `taskid` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tbltasks
#

DROP TABLE IF EXISTS `tbltasks`;

CREATE TABLE `tbltasks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `priority` int DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `startdate` date NOT NULL,
  `duedate` date DEFAULT NULL,
  `datefinished` datetime DEFAULT NULL,
  `addedfrom` int NOT NULL,
  `is_added_from_contact` tinyint(1) NOT NULL DEFAULT '0',
  `status` int NOT NULL DEFAULT '0',
  `recurring_type` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `repeat_every` int DEFAULT NULL,
  `recurring` int NOT NULL DEFAULT '0',
  `is_recurring_from` int DEFAULT NULL,
  `cycles` int NOT NULL DEFAULT '0',
  `total_cycles` int NOT NULL DEFAULT '0',
  `custom_recurring` tinyint(1) NOT NULL DEFAULT '0',
  `last_recurring_date` date DEFAULT NULL,
  `rel_id` int DEFAULT NULL,
  `rel_type` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT '0',
  `billable` tinyint(1) NOT NULL DEFAULT '0',
  `billed` tinyint(1) NOT NULL DEFAULT '0',
  `invoice_id` int NOT NULL DEFAULT '0',
  `hourly_rate` decimal(15,2) NOT NULL DEFAULT '0.00',
  `milestone` int DEFAULT '0',
  `kanban_order` int DEFAULT '1',
  `milestone_order` int NOT NULL DEFAULT '0',
  `visible_to_client` tinyint(1) NOT NULL DEFAULT '0',
  `deadline_notified` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `milestone` (`milestone`),
  KEY `kanban_order` (`kanban_order`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tbltasks_checklist_templates
#

DROP TABLE IF EXISTS `tbltasks_checklist_templates`;

CREATE TABLE `tbltasks_checklist_templates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tbltaskstimers
#

DROP TABLE IF EXISTS `tbltaskstimers`;

CREATE TABLE `tbltaskstimers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `task_id` int NOT NULL,
  `start_time` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `end_time` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `staff_id` int NOT NULL,
  `hourly_rate` decimal(15,2) NOT NULL DEFAULT '0.00',
  `note` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `task_id` (`task_id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tbltaxes
#

DROP TABLE IF EXISTS `tbltaxes`;

CREATE TABLE `tbltaxes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `taxrate` decimal(15,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tbltemplates
#

DROP TABLE IF EXISTS `tbltemplates`;

CREATE TABLE `tbltemplates` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `addedfrom` int NOT NULL,
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblticket_attachments
#

DROP TABLE IF EXISTS `tblticket_attachments`;

CREATE TABLE `tblticket_attachments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ticketid` int NOT NULL,
  `replyid` int DEFAULT NULL,
  `file_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `filetype` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblticket_replies
#

DROP TABLE IF EXISTS `tblticket_replies`;

CREATE TABLE `tblticket_replies` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ticketid` int NOT NULL,
  `userid` int DEFAULT NULL,
  `contactid` int NOT NULL DEFAULT '0',
  `name` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `email` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `date` datetime NOT NULL,
  `message` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `attachment` int DEFAULT NULL,
  `admin` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tbltickets
#

DROP TABLE IF EXISTS `tbltickets`;

CREATE TABLE `tbltickets` (
  `ticketid` int NOT NULL AUTO_INCREMENT,
  `adminreplying` int NOT NULL DEFAULT '0',
  `userid` int NOT NULL,
  `contactid` int NOT NULL DEFAULT '0',
  `merged_ticket_id` int DEFAULT NULL,
  `email` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `name` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `department` int NOT NULL,
  `priority` int NOT NULL,
  `status` int NOT NULL,
  `service` int DEFAULT NULL,
  `ticketkey` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `admin` int DEFAULT NULL,
  `date` datetime NOT NULL,
  `project_id` int NOT NULL DEFAULT '0',
  `lastreply` datetime DEFAULT NULL,
  `clientread` int NOT NULL DEFAULT '0',
  `adminread` int NOT NULL DEFAULT '0',
  `assigned` int NOT NULL DEFAULT '0',
  `staff_id_replying` int DEFAULT NULL,
  `cc` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ticketid`),
  KEY `service` (`service`),
  KEY `department` (`department`),
  KEY `status` (`status`),
  KEY `userid` (`userid`),
  KEY `priority` (`priority`),
  KEY `project_id` (`project_id`),
  KEY `contactid` (`contactid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tbltickets_pipe_log
#

DROP TABLE IF EXISTS `tbltickets_pipe_log`;

CREATE TABLE `tbltickets_pipe_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `email_to` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tbltickets_predefined_replies
#

DROP TABLE IF EXISTS `tbltickets_predefined_replies`;

CREATE TABLE `tbltickets_predefined_replies` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tbltickets_priorities
#

DROP TABLE IF EXISTS `tbltickets_priorities`;

CREATE TABLE `tbltickets_priorities` (
  `priorityid` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`priorityid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tbltickets_priorities` (`priorityid`, `name`) VALUES (1, 'Low');
INSERT INTO `tbltickets_priorities` (`priorityid`, `name`) VALUES (2, 'Medium');
INSERT INTO `tbltickets_priorities` (`priorityid`, `name`) VALUES (3, 'High');


#
# TABLE STRUCTURE FOR: tbltickets_status
#

DROP TABLE IF EXISTS `tbltickets_status`;

CREATE TABLE `tbltickets_status` (
  `ticketstatusid` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `isdefault` int NOT NULL DEFAULT '0',
  `statuscolor` varchar(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `statusorder` int DEFAULT NULL,
  PRIMARY KEY (`ticketstatusid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tbltickets_status` (`ticketstatusid`, `name`, `isdefault`, `statuscolor`, `statusorder`) VALUES (1, 'Open', 1, '#ff2d42', 1);
INSERT INTO `tbltickets_status` (`ticketstatusid`, `name`, `isdefault`, `statuscolor`, `statusorder`) VALUES (2, 'In progress', 1, '#22c55e', 2);
INSERT INTO `tbltickets_status` (`ticketstatusid`, `name`, `isdefault`, `statuscolor`, `statusorder`) VALUES (3, 'Answered', 1, '#2563eb', 3);
INSERT INTO `tbltickets_status` (`ticketstatusid`, `name`, `isdefault`, `statuscolor`, `statusorder`) VALUES (4, 'On Hold', 1, '#64748b', 4);
INSERT INTO `tbltickets_status` (`ticketstatusid`, `name`, `isdefault`, `statuscolor`, `statusorder`) VALUES (5, 'Closed', 1, '#03a9f4', 5);


#
# TABLE STRUCTURE FOR: tbltodos
#

DROP TABLE IF EXISTS `tbltodos`;

CREATE TABLE `tbltodos` (
  `todoid` int NOT NULL AUTO_INCREMENT,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `staffid` int NOT NULL,
  `dateadded` datetime NOT NULL,
  `finished` tinyint(1) NOT NULL,
  `datefinished` datetime DEFAULT NULL,
  `item_order` int DEFAULT NULL,
  PRIMARY KEY (`todoid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tbltracked_mails
#

DROP TABLE IF EXISTS `tbltracked_mails`;

CREATE TABLE `tbltracked_mails` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uid` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `rel_id` int NOT NULL,
  `rel_type` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` datetime NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `opened` tinyint(1) NOT NULL DEFAULT '0',
  `date_opened` datetime DEFAULT NULL,
  `subject` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tbltwocheckout_log
#

DROP TABLE IF EXISTS `tbltwocheckout_log`;

CREATE TABLE `tbltwocheckout_log` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `reference` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `invoice_id` int NOT NULL,
  `amount` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `attempt_reference` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_id` (`invoice_id`),
  CONSTRAINT `tbltwocheckout_log_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `tblinvoices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tbluser_auto_login
#

DROP TABLE IF EXISTS `tbluser_auto_login`;

CREATE TABLE `tbluser_auto_login` (
  `key_id` char(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int NOT NULL,
  `user_agent` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_ip` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_login` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `staff` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tbluser_auto_login` (`key_id`, `user_id`, `user_agent`, `last_ip`, `last_login`, `staff`) VALUES ('b5669bdced1e5fef965eeadd99d85b59', 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', '212.70.108.7', '2024-08-20 03:43:35', 1);
INSERT INTO `tbluser_auto_login` (`key_id`, `user_id`, `user_agent`, `last_ip`, `last_login`, `staff`) VALUES ('6c9d299ce5a8a07fe2ff6e74e801e23b', 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', '176.202.10.165', '2024-08-21 03:26:34', 1);


#
# TABLE STRUCTURE FOR: tbluser_meta
#

DROP TABLE IF EXISTS `tbluser_meta`;

CREATE TABLE `tbluser_meta` (
  `umeta_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `staff_id` bigint unsigned NOT NULL DEFAULT '0',
  `client_id` bigint unsigned NOT NULL DEFAULT '0',
  `contact_id` bigint unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`umeta_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tbluser_meta` (`umeta_id`, `staff_id`, `client_id`, `contact_id`, `meta_key`, `meta_value`) VALUES ('1', '1', '0', '0', 'dashboard_widgets_visibility', NULL);
INSERT INTO `tbluser_meta` (`umeta_id`, `staff_id`, `client_id`, `contact_id`, `meta_key`, `meta_value`) VALUES ('2', '1', '0', '0', 'dashboard_widgets_order', 'a:8:{s:6:\"top-12\";a:1:{i:0;s:16:\"widget-top_stats\";}s:13:\"middle-left-6\";a:0:{}s:14:\"middle-right-6\";a:0:{}s:6:\"left-8\";a:7:{i:0;s:23:\"widget-finance_overview\";i:1;s:21:\"widget-payments_chart\";i:2;s:16:\"widget-user_data\";i:3;s:22:\"widget-upcoming_events\";i:4;s:15:\"widget-calendar\";i:5;s:25:\"widget-contracts_expiring\";i:6;s:21:\"widget-tickets_report\";}s:7:\"right-4\";a:5:{i:0;s:12:\"widget-todos\";i:1;s:18:\"widget-leads_chart\";i:2;s:21:\"widget-projects_chart\";i:3;s:20:\"widget-tickets_chart\";i:4;s:24:\"widget-projects_activity\";}s:13:\"bottom-left-4\";a:0:{}s:15:\"bottom-middle-4\";a:0:{}s:14:\"bottom-right-4\";a:0:{}}');
INSERT INTO `tbluser_meta` (`umeta_id`, `staff_id`, `client_id`, `contact_id`, `meta_key`, `meta_value`) VALUES ('4', '1', '0', '0', 'recent_searches', '[\"disco\",\"dis\"]');


#
# TABLE STRUCTURE FOR: tblvault
#

DROP TABLE IF EXISTS `tblvault`;

CREATE TABLE `tblvault` (
  `id` int NOT NULL AUTO_INCREMENT,
  `customer_id` int NOT NULL,
  `server_address` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `port` int DEFAULT NULL,
  `username` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `creator` int NOT NULL,
  `creator_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `visibility` tinyint(1) NOT NULL DEFAULT '1',
  `share_in_projects` tinyint(1) NOT NULL DEFAULT '0',
  `last_updated` datetime DEFAULT NULL,
  `last_updated_from` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblviews_tracking
#

DROP TABLE IF EXISTS `tblviews_tracking`;

CREATE TABLE `tblviews_tracking` (
  `id` int NOT NULL AUTO_INCREMENT,
  `rel_id` int NOT NULL,
  `rel_type` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` datetime NOT NULL,
  `view_ip` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblweb_to_lead
#

DROP TABLE IF EXISTS `tblweb_to_lead`;

CREATE TABLE `tblweb_to_lead` (
  `id` int NOT NULL AUTO_INCREMENT,
  `form_key` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `lead_source` int NOT NULL,
  `lead_status` int NOT NULL,
  `notify_lead_imported` int NOT NULL DEFAULT '1',
  `notify_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notify_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `responsible` int NOT NULL DEFAULT '0',
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `form_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `recaptcha` int NOT NULL DEFAULT '0',
  `submit_btn_name` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `submit_btn_text_color` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '#ffffff',
  `submit_btn_bg_color` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '#84c529',
  `success_submit_msg` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `submit_action` int DEFAULT '0',
  `lead_name_prefix` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `submit_redirect_url` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `language` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `allow_duplicate` int NOT NULL DEFAULT '1',
  `mark_public` int NOT NULL DEFAULT '0',
  `track_duplicate_field` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `track_duplicate_field_and` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `create_task_on_duplicate` int NOT NULL DEFAULT '0',
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

